# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Cell 1
"""
Module Name: Data Transformation

Overview:
    This module executes configured transformation SQL to convert source data
    into the target common data model. It resolves table aliases, writes
    transformation outputs to intermediate or target schemas, and records
    execution details in the execution log.

Inputs:
    Databricks widgets:
        * env
        * source_name
        * dataset_name
        * refresh
        * athena_refresh
        * transformation_id
        * run_id

Outputs:
    * Intermediate and target transformation tables.
    * Execution log records for the transformation run.

Configuration files:
    * source_schema.yaml
    * target_schema.yaml
    * transformation.yaml
    * env_params.yaml
"""

import os
import sys
import traceback

try:
    # For .py files
    current_path = os.path.abspath(__file__)
except NameError:
    # For Databricks notebooks
    current_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

    if not current_path.startswith("/Workspace"):
        current_path = "/Workspace" + current_path

project_root = current_path.split("/script/")[0]

code_path = project_root + "/script/code"
utilities_path = project_root + "/script/utilities"

if code_path not in sys.path:
    sys.path.append(code_path)

if utilities_path not in sys.path:
    sys.path.append(utilities_path)


from helper import (
    parse_transformation_ids,
    replace_aliases,
    save_transformation_table,
    create_schema_if_not_exists
)
from databricks.sdk.runtime import dbutils
# sys.path.append("/Workspace/Shared/rwpl-cd/common-data-model/script/utilities")

from common_constants import *
from execution_logger import ExecutionLogger
from logger_utility import Logger
from yaml_utility import YamlUtility


# -----------------------------------------------------------------------------
# Databricks widgets
# -----------------------------------------------------------------------------

ENV = dbutils.widgets.get(WIDGET_ENV)
source_name = dbutils.widgets.get(WIDGET_SOURCE_NAME)
dataset_name = dbutils.widgets.get(WIDGET_DATASET_NAME)
refresh = dbutils.widgets.get(WIDGET_REFRESH)
athena_refresh = dbutils.widgets.get(WIDGET_ATHENA_REFRESH)
transformation_id = dbutils.widgets.get(WIDGET_TRANSFORMATION_ID)
run_id = dbutils.widgets.get(WIDGET_RUN_ID)

# ENV = "dev"
# source_name = "marketscan"
# dataset_name = "commercial"
# refresh = "26q1"
# athena_refresh = "26q2"
# transformation_id = "66"
# run_id = "t_id_4"

data_pipeline_identifier = f"{source_name}_{dataset_name}_{refresh}"

# -----------------------------------------------------------------------------
# Logger setup
# -----------------------------------------------------------------------------
logger = Logger(
    __name__,
    LOGGER_LOC.format(
        pipeline=data_pipeline_identifier,
        step=TRANSFORMATION_STEP,
    ),
)


class Transformation:
    """
    Execute configured SQL transformations for a pipeline.

    Responsibilities:
        * Load source, target, and transformation configuration from YAML.
        * Filter transformations based on the requested transformation IDs.
        * Resolve SQL aliases to fully qualified source, prerequisite,
          intermediate, or target tables.
        * Execute transformation queries and persist their output tables.
        * Optimize persisted tables when configured in transformation YAML.
    """

    def __init__(
        self,
        data_pipeline_identifier,
        source_name,
        dataset_name,
        refresh,
        athena_refresh,
        transformation_id,
    ):
        """
        Initialize the transformation runner and load configuration.

        Args:
            data_pipeline_identifier: Unique pipeline execution identifier.
            source_name: Source system name.
            dataset_name: Dataset name within the source system.
            refresh: Refresh partition or batch identifier.
            athena_refresh: Athena prerequisite schema refresh identifier.
            transformation_id: Optional single ID, comma-separated IDs, or
                all/empty value indicating which transformations to run.
        """
        self.spark = spark
        self.data_pipeline_identifier = data_pipeline_identifier
        self.source_name = source_name
        self.dataset_name = dataset_name
        self.refresh = refresh
        self.athena_refresh = athena_refresh
        self.logger = logger
        self.transformation_ids = parse_transformation_ids(transformation_id)

        try:
            self.logger.info(
                f"Loading configurations for pipeline={data_pipeline_identifier}"
            )

            # Load environment parameters.
            self.env_config = YamlUtility(
                env=ENV,
                conf_file=ENV_PARAMS_YAML,
            ).yaml_configuration

            # Load source schema configuration.
            source_yaml = YamlUtility(
                conf_file=SOURCE_SCHEMA_YAML,
            ).yaml_configuration


            self.source_config = source_yaml[self.source_name][self.dataset_name]
            self.source_data_catalog = self.source_config.get(
                VAR_SRC_DATA_CATALOG
            )

            self.source_data_db = self.source_config[VAR_SRC_DATA_DB].replace(
                REFRESH_TOKEN,
                self.refresh,
            )

            self.prereq_data_catalog = self.source_config.get(
                VAR_PREREQ_DATA_CATALOG
            )
            self.prereq_data_db = self.source_config[VAR_PREREQ_DATA_DB].replace(
                ATHENA_REFRESH_TOKEN,
                self.athena_refresh,
            )
            self.prereq_table_list = self.source_config[VAR_PREREQ_TABLE_LIST]

            # Prerequisite lookup configuration
            self.prereq_lookup_data_catalog = self.source_config.get(
                VAR_PREREQ_LOOKUP_DATA_CATALOG
            )

            prereq_lookup_db_template = self.source_config.get(
                VAR_PREREQ_LOOKUP_DATA_DB
            )
            self.prereq_lookup_data_db = (
                prereq_lookup_db_template
                .replace(SOURCE_TOKEN, self.source_name)
                .replace(DATASET_TOKEN, self.dataset_name)
                .replace(REFRESH_TOKEN, self.refresh)
                if prereq_lookup_db_template
                else None
            )

            self.prereq_lookup_table_list = self.source_config.get(
                VAR_PREREQ_LOOKUP_TABLE_LIST,
                [],
            )

            self.reference_data_list = self.source_config.get(
                VAR_REFERENCE_DATA_LIST,
                [],
            )

            # Load target schema configuration.
            target_yaml = YamlUtility(
                conf_file=TARGET_SCHEMA_YAML,
            ).yaml_configuration

            target_source_config = target_yaml[self.source_name]
            target_data = target_source_config[self.dataset_name]

            self.qc_data_catalog = target_data.get(
                VAR_QC_TABLE_CATALOG
            )
            self.output_qc_db = (
                target_data[VAR_QC_OUTPUT_DB]
                .replace(SOURCE_TOKEN, self.source_name)
                .replace(DATASET_TOKEN, self.dataset_name)
                .replace(REFRESH_TOKEN, self.refresh)
            )
            self.intermediate_data_catalog = target_data.get(
                VAR_INTERMEDIATE_DATA_CATALOG
            )
            self.intermediate_data_db = (
                target_data[VAR_INTERMEDIATE_DATA_DB]
                .replace(SOURCE_TOKEN, self.source_name)
                .replace(DATASET_TOKEN, self.dataset_name)
                .replace(REFRESH_TOKEN, self.refresh)
            )
            self.target_table_list = target_data[VAR_TARGET_TABLE_LIST]

            # Load transformation configuration.
            transformation_yaml = YamlUtility(
                conf_file=TRANSFORMATION_YAML,
            ).yaml_configuration

            self.transformation_config = transformation_yaml[self.source_name]
            self.transformation_list = self.transformation_config[self.dataset_name][
                VAR_TRANSFORMATION_LIST
            ]

            self.logger.info("All configurations loaded successfully.")

        except Exception:
            self.logger.error(
                f"Failed to initialize Transformation: {traceback.format_exc()}"
            )
            raise

    def get_transformation_details(self):
        """
        Return the subset of transformations requested for this run.

        Returns:
            list[dict]: Transformation configuration records selected for the
                current execution.

        Raises:
            ValueError: If one or more requested transformation IDs do not exist
                in the transformation YAML.
        """
        if self.transformation_ids is None:
            return self.transformation_list

        available_ids = {
            item[VAR_TRANSFORMATION_ID] for item in self.transformation_list
        }
        missing_ids = set(self.transformation_ids) - available_ids

        if missing_ids:
            raise ValueError(
                f"Transformation IDs not found in YAML: {sorted(missing_ids)}. "
                f"Available IDs: {sorted(available_ids)}"
            )

        # Preserve the order in which the user passed the IDs (e.g. "71,20"),
        # so dependent transformations run after their prerequisites.
        transformation_by_id = {
            item[VAR_TRANSFORMATION_ID]: item for item in self.transformation_list
        }
        ordered_ids = list(dict.fromkeys(self.transformation_ids))  # de-dup, keep order
        return [transformation_by_id[tid] for tid in ordered_ids]

    def get_target_table(self, target_table_id):
        """
        Find the target table configuration for a target table ID.

        Args:
            target_table_id: Target table identifier from transformation YAML.

        Returns:
            dict: Target table configuration record.

        Raises:
            ValueError: If the target table ID does not exist in the target
                schema YAML.
        """
        try:
            return next(
                table
                for table in self.target_table_list
                if table[VAR_TARGET_TABLE_ID] == target_table_id
            )
        except StopIteration as exc:
            raise ValueError(
                f"Target table ID not found in target schema YAML: {target_table_id}"
            ) from exc

    def perform_transformation(self):
        """
        Execute each selected transformation only when its target table is marked
        as required in target_schema.yaml.

        For every selected transformation:
            1. Resolve the corresponding target table.
            2. Read the target table's is_required value.
            3. Skip the transformation when is_required is not true.
            4. Execute and save the transformation when required.
            5. Optimize the written table when optimize_query is configured.

        Returns:
            list[dict]:
                Summary of completed and skipped transformations.
        """
        results = []
        transformation_details = self.get_transformation_details()

        self.logger.info(
            f"Total transformations selected: {len(transformation_details)}"
        )

        for transformation_detail in transformation_details:
            current_transformation_id = transformation_detail[
                VAR_TRANSFORMATION_ID
            ]

            target_table_id = transformation_detail[
                VAR_MAPPING_TARGET_TABLE_ID
            ]

            target_table = self.get_target_table(target_table_id)

            target_table_name = target_table[
                VAR_TARGET_TABLE_NAME
            ]

            target_table_type = target_table[
                VAR_TARGET_TABLE_TYPE
            ]

            # Check is_required for this transformation's target table.
            is_required = target_table.get(VAR_IS_REQUIRED, False)

            if is_required is not True:
                self.logger.info(
                    f"Skipping transformation_id={current_transformation_id}, "
                    f"target_table_id={target_table_id}, "
                    f"target_table={target_table_name}, "
                    f"is_required={is_required}"
                )

                results.append(
                    {
                        TransformationResultKey.TRANSFORMATION_ID: current_transformation_id,
                        TransformationResultKey.TARGET_TABLE_ID: target_table_id,
                        TransformationResultKey.TARGET_TABLE_NAME: target_table_name,
                        TransformationResultKey.STATUS: Status.SKIPPED,
                        TransformationResultKey.REASON: REASON_TABLE_NOT_REQUIRED,
                        TransformationResultKey.IS_REQUIRED: is_required,
                    }
                )

                # Continue to the next transformation ID.
                continue

            self.logger.info(
                f"Starting transformation_id={current_transformation_id}, "
                f"target_table_id={target_table_id}, "
                f"target_table={target_table_name}, "
                f"is_required={is_required}"
            )

            query = transformation_detail[
                VAR_TRANSFORMATION_QUERY
            ]

            query = replace_aliases(
                query=query,

                source_table_list=self.source_config[
                    VAR_SRC_TABLE_LIST
                ],
                source_data_catalog=self.source_data_catalog,
                source_data_db=self.source_data_db,

                prereq_table_list=self.prereq_table_list,
                prereq_data_catalog=self.prereq_data_catalog,
                prereq_data_db=self.prereq_data_db,

                prereq_lookup_table_list=self.prereq_lookup_table_list,
                prereq_lookup_data_catalog=self.prereq_lookup_data_catalog,
                prereq_lookup_data_db=self.prereq_lookup_data_db,

                reference_data_list=self.reference_data_list,

                target_table_list=self.target_table_list,
                qc_data_catalog=self.qc_data_catalog,
                qc_data_db=self.output_qc_db,

                intermediate_data_catalog=self.intermediate_data_catalog,
                intermediate_data_db=self.intermediate_data_db,

                logger=self.logger,
            )

            self.logger.info(
                f"Executing query for "
                f"transformation_id={current_transformation_id}, "
                f"target_table={target_table_name}"
            )

            df = self.spark.sql(query)

            full_table_name, row_count = save_transformation_table(
                spark=self.spark,
                df=df,
                table_name=target_table_name,
                table_type=target_table_type,
                intermediate_data_catalog=self.intermediate_data_catalog,
                intermediate_data_db=self.intermediate_data_db,
                qc_data_catalog=self.qc_data_catalog,
                qc_data_db=self.output_qc_db,
                logger=self.logger,
            )

            # Optimize the newly written table when an optimize query is
            # configured for this transformation.
            optimize_query = transformation_detail.get(VAR_OPTIMIZE_QUERY)

            if optimize_query and optimize_query.strip():
                optimize_query = replace_aliases(
                    query=optimize_query,
                    target_table_list=self.target_table_list,
                    qc_data_catalog=self.qc_data_catalog,
                    qc_data_db=self.output_qc_db,
                    intermediate_data_catalog=self.intermediate_data_catalog,
                    intermediate_data_db=self.intermediate_data_db,
                    logger=self.logger,
                )

                self.logger.info(
                    f"Executing optimize query for "
                    f"transformation_id={current_transformation_id}, "
                    f"target_table={target_table_name}"
                )

                self.spark.sql(optimize_query)

                self.logger.info(
                    f"Optimize completed for "
                    f"transformation_id={current_transformation_id}, "
                    f"target_table={target_table_name}"
                )

            result = {
                TransformationResultKey.TRANSFORMATION_ID: current_transformation_id,
                TransformationResultKey.TARGET_TABLE_ID: target_table_id,
                TransformationResultKey.TARGET_TABLE_NAME: target_table_name,
                TransformationResultKey.FULL_TABLE_NAME: full_table_name,
                TransformationResultKey.ROW_COUNT: row_count,
                TransformationResultKey.STATUS: Status.COMPLETE,
                TransformationResultKey.IS_REQUIRED: is_required,
            }

            results.append(result)

            self.logger.info(
                f"Completed transformation_id={current_transformation_id}, "
                f"target_table_id={target_table_id}, "
                f"target_table={target_table_name}, "
                f"full_table_name={full_table_name}"
            )

        return results

# -----------------------------------------------------------------------------
# Entry point
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    step_name = f"{TRANSFORMATION_STEP}_{transformation_id}"

    # Initialize execution logger.
    try:
        target_config = YamlUtility(
            conf_file=TARGET_SCHEMA_YAML,
        ).yaml_configuration

        target_data = target_config[source_name][dataset_name]

        env_config = YamlUtility(
            env=ENV,
            conf_file=ENV_PARAMS_YAML,
        ).yaml_configuration

        storage_account = env_config.get(VAR_STORAGE_ACCOUNT)

        qc_catalog = target_data.get(VAR_QC_TABLE_CATALOG)
        qc_db = (
            target_data[VAR_QC_OUTPUT_DB]
            .replace(SOURCE_TOKEN, source_name)
            .replace(DATASET_TOKEN, dataset_name)
            .replace(REFRESH_TOKEN, refresh)
        )

        intermediate_catalog = target_data.get(VAR_INTERMEDIATE_DATA_CATALOG)
        intermediate_db = (
            target_data[VAR_INTERMEDIATE_DATA_DB]
            .replace(SOURCE_TOKEN, source_name)
            .replace(DATASET_TOKEN, dataset_name)
            .replace(REFRESH_TOKEN, refresh)
        )

        qc_location = target_data.get(VAR_QC_OUTPUT_LOCATION)
        if qc_location:
            qc_location = (
                qc_location
                .replace(SOURCE_TOKEN, source_name)
                .replace(DATASET_TOKEN, dataset_name)
                .replace(REFRESH_TOKEN, refresh)
                .replace(STORAGE_ACCOUNT_TOKEN, storage_account)
            )

        intermediate_location = target_data.get(VAR_INTERMEDIATE_DATA_LOCATION)
        if intermediate_location:
            intermediate_location = (
                intermediate_location
                .replace(SOURCE_TOKEN, source_name)
                .replace(DATASET_TOKEN, dataset_name)
                .replace(REFRESH_TOKEN, refresh)
                .replace(STORAGE_ACCOUNT_TOKEN, storage_account)
            )

        create_schema_if_not_exists(
            spark=spark,
            catalog=qc_catalog,
            schema_name=qc_db,
            managed_location=qc_location,
            logger=logger,
        )

        create_schema_if_not_exists(
            spark=spark,
            catalog=intermediate_catalog,
            schema_name=intermediate_db,
            managed_location=intermediate_location,
            logger=logger,
        )

        execution_logger = ExecutionLogger(
            database=f"{intermediate_catalog}.{intermediate_db}",
            table=VAR_LOG_TABLE_NAME,
            spark=spark,
        )
        execution_logger.terminate_current_execution(run_id)  
        execution_log_id = execution_logger.create_new_log(
            run_id=run_id,
            pipeline_name=data_pipeline_identifier,
            step_name=step_name,
            status=Status.IN_PROGRESS,
        )

        logger.info(
            f"Execution log created: id={execution_log_id} | step={step_name}"
        )

    except Exception:
        logger.error(
            f"Failed to initialize execution logger: {traceback.format_exc()}"
        )
        raise

    try:
        logger.info(
            f"Starting transformation pipeline={data_pipeline_identifier} | "
            f"transformation_id={transformation_id}"
        )

        transformation = Transformation(
            data_pipeline_identifier=data_pipeline_identifier,
            source_name=source_name,
            dataset_name=dataset_name,
            refresh=refresh,
            athena_refresh=athena_refresh,
            transformation_id=transformation_id,
        )

        results = transformation.perform_transformation()
        
        execution_logger.update_log(
            id=execution_log_id,
            status=Status.COMPLETE,
            output=f"Transformations completed: {results}",
        )
        execution_logger.terminate_current_execution(run_id)  
        logger.info(f"Transformations completed successfully: {results}")

    except Exception as exc:
        error_msg = traceback.format_exc()

        logger.error(f"Transformation failed: {error_msg}")

        execution_logger.update_log(
            id=execution_log_id,
            status=Status.FAILED,
            error=str(exc),
        )

        execution_logger.terminate_current_execution(run_id)
        logger.info("Pipeline terminated.")
        raise