"""
Module Name: Email Utility
 
Overview:
    This module provides shared helpers for building and sending pipeline email
    notifications. It renders the HTML email body, generates CSV attachments
    from the execution log and the achilles/dqd/custom QC result tables, and
    sends the final email through SMTP.
 
Used by:
    * email_notifier.py
"""
 
import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
 
from jinja2 import Template
 
from common_constants import *
 
 
# -----------------------------------------------------------------------------
# Email HTML template
# -----------------------------------------------------------------------------
EMAIL_TEMPLATE = """
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
    <meta name="Generator" content="Microsoft Word 15">
    <style>
      .email_body {
        width: 900px;
        border-collapse: collapse;
        border: solid black 1px;
        margin: 10px;
      }
      .email_header {
        width: 100%;
        border: solid windowtext 1px;
        border-right: solid black 1px;
        padding: 0px 5px 0px 5px;
        height: 60px;
        color: #f36633;
        font-size: 30px;
        text-align: center;
      }
      .section_header {
        width: 100%;
        border-top: none;
        border-left: solid windowtext 1px;
        border-bottom: solid windowtext 1px;
        border-right: solid black 1px;
        background: #f36633;
        padding: 3px 6px 3px 6px;
        height: 16px;
        color: #ffffff;
        text-align: center;
      }
      .section_attribute_text {
        width: 50%;
        border-top: none;
        border-left: solid windowtext 1px;
        border-bottom: none;
        border-right: solid black 1px;
        padding: 10px 6px 10px 6px;
        height: 12px;
        color: #000000;
        font-size: 15px;
      }
      .section_attribute_text_footer {
        width: 50%;
        border-top: none;
        border-left: solid windowtext 1px;
        border-bottom: none;
        border-right: solid black 1px;
        padding: 10px 6px 10px 6px;
        height: 12px;
        color: #f36633;
        font-size: 15px;
      }
    </style>
  </head>
  <body
    lang="EN-US"
    link="#0563C1"
    vlink="#954F72"
    style="tab-interval: 0.5in; word-wrap: break-word"
  >
    <div>
      <table class="email_body">
        <tbody>
          <tr>
            <td nowrap="" class="email_header">
              <p><b>RWD OMOP</b></p>
            </td>
          </tr>
          <tr><td class="section_attribute_text"></td></tr>
          <tr>
            <td class="section_header"><p><b>Speed Read</b></p></td>
          </tr>
          <tr>
            <td class="section_attribute_text">
              RWD OMOP pipeline {{ status }} for {{ data_pipeline_identifier }}
            </td>
          </tr>
          <tr><td class="section_attribute_text"></td></tr>
          <tr>
            <td class="section_header"><p><b>Details</b></p></td>
          </tr>
          <tr>
            <td class="section_attribute_text">
              <p>Hello Users,</p>
              <p>
                Data pipeline to create RWD OMOP Tables of
                {{ data_pipeline_identifier }} is {{ status }}.<br>
                Please find additional details below.
              </p>
              <p><b>Run Environment:</b> {{ env }}</p>
              <p><b>Pipeline Run ID:</b> {{ run_id }}</p>
              <p><b>Pipeline Name:</b> {{ pipeline_name }}</p>
              <p><b>Start Time:</b> {{ trigger_time }}</p>
              <p><b>Completion Time:</b> {{ completion_time }}</p>
              <p>Please find the execution log and available QC results attached.</p>
              {% if achilles_result_table %}
              <p>
                <b>Detailed Achilles Results:</b><br>
                The Achilles distribution summary
                (<i>achilles_results_dist</i>) is attached for a quick review.
                <br>
                For the complete detailed Achilles results for this refresh,
                please query the following table directly in Databricks:
                <br><b>{{ achilles_result_table }}</b>
              </p>
              {% endif %}
            </td>
          </tr>
          <tr><td class="section_attribute_text"></td></tr>
          <tr>
            <td class="section_attribute_text_footer">
              <b>Thanks and Regards,<br>RWD Empower Team</b>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </body>
</html>
"""
 
 
# -----------------------------------------------------------------------------
# CSV generation helpers
# -----------------------------------------------------------------------------
def _sql_to_csv(spark, sql_query, label):
    """
    Execute a SQL query and return the result as a CSV string.
 
    Args:
        spark: Active Spark session.
        sql_query: SQL statement to execute.
        label: Human-readable label used in log/print messages.
 
    Returns:
        str | None: CSV string, or None when no records found or on error.
    """
    try:
        print(f"Querying {label}:")
        print(sql_query)
        df = spark.sql(sql_query)
 
        # Materialize once to pandas, then check emptiness. Using
        # df.count() before df.toPandas() would execute the query twice.
        pandas_df = df.toPandas()

        if pandas_df.empty:
            print(f"No records found for {label}.")
            return None

        csv_string = pandas_df.to_csv(index=False)
        return csv_string
    except Exception as exc:
        print(f"Failed to generate {label} CSV: {str(exc)}")
        return None
 
def get_log_csv(spark, catalog, intermediate_data_db, run_id):
    """
    Generate a CSV string from the execution log for the current pipeline run.
 
    Filters by run_id. The execution log is cumulative across runs, so this
    scoping is required to return only rows belonging to the current ADF
    master pipeline run.
 
    Args:
        spark: Active Spark session.
        catalog: Catalog containing the execution log table.
        intermediate_data_db: Database containing the execution log table.
        run_id: ADF master pipeline run ID for the current run.
 
    Returns:
        str | None: CSV string for the execution log, or None when no
        records are found or generation fails.
    """
    log_table = f"{catalog}.{intermediate_data_db}.{VAR_LOG_TABLE_NAME}"
 
    safe_run_id = str(run_id).replace("'", "''")
 
    sql_query = f"""
        SELECT
            id,
            run_id,
            pipeline_name,
            step_name,
            step_status,
            start_datetime,
            end_datetime,
            output,
            error
        FROM {log_table}
        WHERE run_id = '{safe_run_id}'
        ORDER BY id
    """
    return _sql_to_csv(spark, sql_query, "execution_log")
 
 
# def get_achilles_result_csv(spark, catalog, output_qc_db):
#     """
#     Generate a CSV string from the achilles_result table.
 
#     This table is dropped and recreated fresh on every pipeline run so no
#     pipeline_name filter is needed — it always contains only the current
#     run's data.
 
#     Args:
#         spark: Active Spark session.
#         catalog: Catalog containing the QC result table.
#         output_qc_db: Database containing the QC result table.
 
#     Returns:
#         str | None: CSV string, or None when no records found or on error.
#     """
#     table = f"{catalog}.{output_qc_db}.{VAR_QC_ACHILLES_RESULT}"
#     return _sql_to_csv(spark, f"SELECT * FROM {table}", "achilles_result")
 
 
def get_achilles_result_dist_csv(spark, catalog, output_qc_db):
    """
    Generate a CSV string from the achilles_result_dist table.
 
    This table is dropped and recreated fresh on every pipeline run so no
    pipeline_name filter is needed — it always contains only the current
    run's data.
 
    Args:
        spark: Active Spark session.
        catalog: Catalog containing the QC result table.
        output_qc_db: Database containing the QC result table.
 
    Returns:
        str | None: CSV string, or None when no records found or on error.
    """
    table = f"{catalog}.{output_qc_db}.{VAR_QC_ACHILLES_RESULT_DIST}"
    return _sql_to_csv(spark, f"SELECT * FROM {table}", "achilles_result_dist")
 
 
def get_dqd_csv(spark, catalog, output_qc_db):
    """
    Generate a CSV string from the DQD QC result table (VAR_QC_TBL_DQD).
 
    This table is dropped and recreated fresh on every pipeline run so no
    pipeline_name filter is needed — it always contains only the current
    run's data.
 
    Args:
        spark: Active Spark session.
        catalog: Catalog containing the QC result table.
        output_qc_db: Database containing the QC result table.
 
    Returns:
        str | None: CSV string, or None when no records found or on error.
    """
    table = f"{catalog}.{output_qc_db}.{VAR_QC_TBL_DQD}"
    return _sql_to_csv(spark, f"SELECT * FROM {table}", "dqd")
 
 
def get_custom_csv(spark, catalog, output_qc_db):
    """
    Generate a CSV string from the custom QC result table (VAR_QC_TBL_CUSTOM).
 
    This table is dropped and recreated fresh on every pipeline run so no
    pipeline_name filter is needed — it always contains only the current
    run's data.
 
    Args:
        spark: Active Spark session.
        catalog: Catalog containing the QC result table.
        output_qc_db: Database containing the QC result table.
 
    Returns:
        str | None: CSV string, or None when no records found or on error.
    """
    table = f"{catalog}.{output_qc_db}.{VAR_QC_TBL_CUSTOM}"
    return _sql_to_csv(spark, f"SELECT * FROM {table}", "custom")
 
 
 
# -----------------------------------------------------------------------------
# Email attachment helper
# -----------------------------------------------------------------------------
def attach_csv(msg, csv_string, filename):
    """
    Attach a CSV string to a multipart email message.
 
    Args:
        msg: Multipart email message.
        csv_string: CSV content to attach.
        filename: Attachment file name.
    """
    attachment = MIMEBase("application", "octet-stream")
    attachment.set_payload(csv_string.encode("utf-8"))
    encoders.encode_base64(attachment)
    attachment.add_header(
        "Content-Disposition",
        f"attachment; filename={filename}",
    )
    msg.attach(attachment)
    print(f"Attached: {filename}")
 
 
# -----------------------------------------------------------------------------
# Email sender
# -----------------------------------------------------------------------------
def send_email(
    status,
    data_pipeline_identifier,
    env,
    pipeline_name,
    run_id,
    trigger_time,
    completion_time,
    sender_email,
    receiver_email,
    log_csv=None,
    achilles_result_csv=None,
    achilles_result_dist_csv=None,
    achilles_result_table=None,
    dqd_csv=None,
    custom_csv=None,
):
    """
    Render and send the pipeline status email with up to 5 CSV attachments.
 
    Every CSV parameter is optional — if a table was empty or generation
    failed (e.g. achilles was not run this time), that attachment is simply
    skipped rather than failing the whole email.
 
    Args:
        status: Final pipeline status string shown in subject and body.
        data_pipeline_identifier: Unique pipeline run identifier.
        env: Run environment name.
        pipeline_name: Pipeline display name shown in the email body.
        run_id: ADF pipeline run ID shown in the email body.
        trigger_time: Pipeline start timestamp shown in the email body.
        completion_time: Pipeline completion timestamp shown in the email body.
        sender_email: Sender email address.
        receiver_email: Comma-separated list of receiver email addresses.
        log_csv: Optional execution log CSV content.
        achilles_result_csv: Optional achilles_result table CSV content.
        achilles_result_dist_csv: Optional achilles_result_dist table CSV content.
        achilles_result_table: Fully qualified Achilles result table for detailed review.
        dqd_csv: Optional DQD QC result CSV content.
        custom_csv: Optional custom QC result CSV content.
    """
    receiver_list = [
        email.strip()
        for email in receiver_email.split(",")
        if email.strip()
    ]
 
   
 
    # Render HTML body.
    html_body = Template(EMAIL_TEMPLATE).render(
        status=status,
        data_pipeline_identifier=data_pipeline_identifier,
        env=env,
        pipeline_name=pipeline_name,
        run_id=run_id,
        trigger_time=trigger_time,
        completion_time=completion_time,
        achilles_result_table=achilles_result_table,
    )
 
    # Build email message.
    msg = MIMEMultipart("mixed")
    msg["Subject"] = f"[RWD OMOP Pipeline] {data_pipeline_identifier} - {status}"
    msg["From"] = sender_email
    msg["To"] = ", ".join(receiver_list)
 
    msg.attach(MIMEText(html_body, "html"))
 
    # 1. Execution log.
    if log_csv:
        attach_csv(msg, log_csv, f"execution_log_{data_pipeline_identifier}.csv")
 
    # 2. Achilles result dist.
    if achilles_result_dist_csv:
        attach_csv(msg, achilles_result_dist_csv, f"achilles_result_dist_{data_pipeline_identifier}.csv")
 
    # 3. DQD QC results.
    if dqd_csv:
        attach_csv(msg, dqd_csv, f"dqd_qc_results_{data_pipeline_identifier}.csv")
 
    # 4. Custom QC results.
    if custom_csv:
        attach_csv(msg, custom_csv, f"custom_qc_results_{data_pipeline_identifier}.csv")
 
 
 
    # Send via SMTP.
    try:
        with smtplib.SMTP("internal-smtp.gsk.com", 25) as server:
            server.sendmail(sender_email, receiver_list, msg.as_string())
        print("Email sent successfully.")
    except Exception as exc:
        print(f"Email sending failed: {str(exc)}")