import time
import traceback


class ExecutionLogger:
    """
    Manage execution log records for pipeline runs.
    """

    def __init__(self, database, table, spark):
        self.database = database
        self.table = table
        self.spark = spark
        self.create_table_if_not_exists()

    def create_table_if_not_exists(self):
        create_table_query = f"""
            CREATE TABLE IF NOT EXISTS {self.database}.{self.table} (
                id BIGINT GENERATED ALWAYS AS IDENTITY,
                run_id STRING,
                pipeline_name STRING,
                step_name STRING,
                step_status STRING,
                start_datetime TIMESTAMP,
                end_datetime TIMESTAMP,
                output STRING,
                error STRING,
                is_current_run BOOLEAN
            )
            TBLPROPERTIES (delta.enableChangeDataFeed = true)
        """
        self.spark.sql(create_table_query)

    def execute_query(self, query):
        retries_remaining = 10

        while retries_remaining > 0:
            try:
                print(query)
                return self.spark.sql(query)
            except Exception:
                traceback.print_exc()
                time.sleep(5)
                retries_remaining -= 1

        raise Exception("Error while logging execution logs")

    def create_new_log(self, run_id, pipeline_name, step_name, status):
        safe_run_id = str(run_id).replace("'", "''")
        safe_pipeline_name = str(pipeline_name).replace("'", "''")
        safe_step_name = str(step_name).replace("'", "''")
        safe_status = str(status).replace("'", "''")

        self.execute_query(
            f"""
            INSERT INTO {self.database}.{self.table}
            (
                run_id,
                pipeline_name,
                step_name,
                step_status,
                start_datetime,
                is_current_run
            )
            VALUES (
                '{safe_run_id}',
                '{safe_pipeline_name}',
                '{safe_step_name}',
                '{safe_status}',
                current_timestamp(),
                true
            )
            """
        )

        return self.execute_query(
            f"""
            SELECT id
            FROM {self.database}.{self.table}
            WHERE run_id = '{safe_run_id}'
              AND pipeline_name = '{safe_pipeline_name}'
              AND step_name = '{safe_step_name}'
            ORDER BY id DESC
            LIMIT 1
            """
        ).head()[0]

    def update_log(self, id, status, output=None, error=None, is_running=False):
        safe_status = str(status).replace("'", "''")

        query = f"""
            UPDATE {self.database}.{self.table}
            SET step_status = '{safe_status}'
        """

        if not is_running:
            safe_output = (output or "-").strip().replace("'", "''")
            safe_error = (error or "-").strip().replace("'", "''")

            query += f"""
                , end_datetime = current_timestamp()
                , output = '{safe_output}'
                , error = '{safe_error}'
            """

        query += f"""
            WHERE id = {id}
        """
        self.execute_query(query)

    def get_current_execution_data(self, run_id):
        safe_run_id = str(run_id).replace("'", "''")

        return self.execute_query(
            f"""
            SELECT *
            FROM {self.database}.{self.table}
            WHERE run_id = '{safe_run_id}'
            ORDER BY id
            """
        )

    def terminate_current_execution(self, run_id):
        safe_run_id = str(run_id).replace("'", "''")

        self.execute_query(
            f"""
            UPDATE {self.database}.{self.table}
            SET is_current_run = false
            WHERE run_id = '{safe_run_id}'
            """
        )