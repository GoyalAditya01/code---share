"""
Module Name: YAML Utility

Overview:
    This module provides a helper class for loading YAML configuration files
    from the common data model configuration directory and retrieving nested
    configuration values using a key hierarchy.
"""

import os
from functools import reduce

import yaml


class YamlUtility:
    """
    Load YAML configuration files and expose nested configuration access.

    Responsibilities:
        * Resolve environment-specific and global configuration paths.
        * Load YAML content into memory.
        * Return nested configuration values from a hierarchy of keys.
    """

    def __init__(self, env=None, conf_file=None, conf=None):
        """
        Initialize the YAML utility and load the requested configuration file.

        Args:
            env: Optional environment name used for environment-specific config.
            conf_file: YAML file name to load.
            conf: Reserved optional parameter for future use.
        """
        self.yaml_configuration = None

        try:
            utilities_path = os.path.dirname(os.path.abspath(__file__))
            script_path = os.path.dirname(utilities_path)
            repo_base_path = os.path.dirname(script_path)

            base_path = os.path.join(repo_base_path, "configuration")
            env_path = None

            if env is not None and conf_file is not None:
                env_path = os.path.join(base_path, "env", env, conf_file)
            elif conf_file is not None:
                env_path = os.path.join(base_path, "global", conf_file)

            print(env_path)

            if env_path is None:
                raise ValueError("A valid conf_file must be provided.")

            with open(env_path) as stream:
                self.yaml_configuration = yaml.safe_load(stream)

        except yaml.YAMLError as exc:
            print(exc)
        except FileNotFoundError as exc:
            print(f"Config file not found: {exc}")
        except Exception as exc:
            print(f"Unexpected error: {exc}")

    def get_configuration(self, conf_hierarchy):
        """
        Return a configuration value from a nested YAML hierarchy.

        Args:
            conf_hierarchy: List of keys used to traverse the YAML structure.
                Example: ['marketscan_commercial_26q1', 'source_data_db']

        Returns:
            Any: Value stored at the requested hierarchy level, or None if the
            lookup fails.
        """
        try:
            return reduce(
                lambda dictionary, key: dictionary[key],
                conf_hierarchy,
                self.yaml_configuration,
            )
        except KeyError as exc:
            print(f"Key not found in configuration: {exc}")
        except TypeError as exc:
            print(f"Invalid configuration hierarchy: {exc}")
        except Exception as exc:
            print(f"Unexpected error: {exc}")
