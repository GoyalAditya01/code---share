-- Databricks notebook source
-- MAGIC %md
-- MAGIC P01

-- COMMAND ----------


WITH counts AS (
    SELECT
        (SELECT COUNT(DISTINCT person_id)
         FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.person
        ) AS omop_count,

        (SELECT COUNT(*)
         FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.patient_med_validation
        ) AS cdp_count
)

SELECT
    'Patient' AS table_name,

    'Reconcile CDP Patient count against distinct CDM PERSON count.'
        AS check_description,

    'PERSON' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC P02

-- COMMAND ----------


WITH counts AS (
    SELECT
        (SELECT COUNT(DISTINCT person_id)
         FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.death
        ) AS omop_count,

        (SELECT COUNT(DISTINCT person_id)
         FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.patient_med_validation
         WHERE death_flag = TRUE
        ) AS cdp_count
)

SELECT
    'Patient' AS table_name,

    'Reconcile deceased patients (death_flag = TRUE) against distinct CDM DEATH records.'
        AS check_description,

    'DEATH' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC P03

-- COMMAND ----------


WITH duplicate_check AS (
    SELECT
        person_id,
        COUNT(*) AS record_count

    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.patient_med_validation

    GROUP BY person_id

    HAVING COUNT(*) > 1
)

SELECT
    'Patient' AS table_name,

    'Check that person_id is unique in the CDP Patient table.'
        AS check_description,

    '' AS source_table_name,

    '' AS source_attribute_name,

    'Zero duplicate person_id values' AS expected_result,

    COALESCE(SUM(record_count - 1), 0) AS failed_record_count,

    CASE
        WHEN COALESCE(SUM(record_count - 1), 0) = 0
        THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM duplicate_check;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC P04

-- COMMAND ----------


WITH null_check AS (
    SELECT
        COUNT(*) - COUNT(person_id) AS failed_record_count

    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.patient_med_validation
)

SELECT
    'Patient' AS table_name,

    'Check for NULL values in person_id.'
        AS check_description,

    '' AS source_table_name,

    'person_id' AS source_attribute_name,

    'Zero NULL values in person_id' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM null_check;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC P05

-- COMMAND ----------


WITH validation AS (
    SELECT
        COUNT(*) AS failed_record_count

    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.patient_med_validation

    WHERE
        (death_flag = TRUE AND death_date IS NULL)

        OR (death_flag = FALSE AND death_date IS NOT NULL)

        OR death_flag IS NULL
)

SELECT
    'Patient' AS table_name,

    'Validate death_flag and death_date consistency: date populated when TRUE and NULL when FALSE.'
        AS check_description,

    '' AS source_table_name,

    '' AS source_attribute_name,

    'Zero records violating the condition' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E01

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.condition_occurrence co

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = co.condition_occurrence_id
               AND UPPER(c.cost_domain_id) = 'CONDITION'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'CONDITION'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = CONDITION against CDM CONDITION_OCCURRENCE.'
        AS check_description,

    'CONDITION_OCCURRENCE' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E02

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.DRUG_EXPOSURE do

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = do.drug_Exposure_id
               AND UPPER(c.cost_domain_id) = 'DRUG'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'DRUG'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = DRUG against CDM DRUG_EXPOSURE.'
        AS check_description,

    'DRUG_EXPOSURE' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E03

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.procedure_occurrence po

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = po.procedure_occurrence_id
               AND UPPER(c.cost_domain_id) = 'PROCEDURE'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'PROCEDURE'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = PROCEDURE against CDM PROCEDURE_OCCURRENCE.'
        AS check_description,

    'PROCEDURE_OCCURRENCE' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E04

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.device_exposure de

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = de.device_exposure_id
               AND UPPER(c.cost_domain_id) = 'DEVICE'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'DEVICE'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = DEVICE against CDM DEVICE_EXPOSURE.'
        AS check_description,

    'DEVICE_EXPOSURE' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E05

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.measurement mst

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = mst.measurement_id
               AND UPPER(c.cost_domain_id) = 'MEASUREMENT'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'MEASUREMENT'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = MEASUREMENT against CDM MEASUREMENT.'
        AS check_description,

    'MEASUREMENT' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E06

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.observation obs

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = obs.observation_id
               AND UPPER(c.cost_domain_id) = 'OBSERVATION'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'OBSERVATION'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = OBSERVATION against CDM OBSERVATION.'
        AS check_description,

    'OBSERVATION' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E07

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.visit_occurrence ve

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = ve.visit_occurrence_id
               AND UPPER(c.cost_domain_id) = 'VISIT'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'VISIT'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = VISIT against CDM VISIT_OCCURRENCE.'
        AS check_description,

    'VISIT_OCCURRENCE' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E08

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.specimen spc

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = spc.specimen_id
               AND UPPER(c.cost_domain_id) = 'SPECIMEN'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'SPECIMEN'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = SPECIMEN against CDM SPECIMEN.'
        AS check_description,

    'SPECIMEN' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E09

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.visit_Detail vd

            LEFT JOIN dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost c
                ON c.cost_event_id = vd.visit_detail_id
               AND UPPER(c.cost_domain_id) = 'VISIT_DETAIL'
        ) AS omop_count,

        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
            WHERE event_type = 'VISIT_DETAIL'
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event rows where event_type = VISIT_DETAIL against CDM VISIT_DETAIL.'
        AS check_description,

    'VISIT_DETAIL' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E10

-- COMMAND ----------


WITH counts AS (
    SELECT
        (
            SELECT COUNT(*)
            FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.cost
            WHERE UPPER(cost_domain_id) IN (
                'CONDITION', 'DRUG', 'PROCEDURE',
                'DEVICE', 'MEASUREMENT', 'OBSERVATION',
                'VISIT', 'SPECIMEN', 'VISIT_DETAIL'
            )
        ) AS omop_count,

        (
            SELECT COUNT(cost_id)
            FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
        ) AS cdp_count
)

SELECT
    'Event' AS table_name,

    'Reconcile CDP Event records with populated cost_id against eligible CDM COST records.'
        AS check_description,

    'COST' AS source_table_name,

    '' AS source_attribute_name,

    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E11

-- COMMAND ----------


WITH counts AS (
    SELECT
        (SELECT COUNT(*)
         FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
        ) AS total_count,

        (SELECT COUNT(*)
         FROM (
             SELECT DISTINCT *
             FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
         )
        ) AS distinct_count
)

SELECT
    'Event' AS table_name,

    'Identify fully duplicated Event rows using the complete row and defined grain (event_type, event_id, cost_id).'
        AS check_description,

    '' AS source_table_name,

    '' AS source_attribute_name,

    'Zero fully duplicated rows' AS expected_result,

    total_count - distinct_count AS failed_record_count,

    CASE
        WHEN total_count = distinct_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E12

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
    WHERE event_id IS NULL
)

SELECT
    'Event' AS table_name,
    'Check for NULL values in event_id. Applicability: All event domains.'
        AS check_description,
    '' AS source_table_name,
    'event_id' AS source_attribute_name,
    'Zero applicable NULL values in event_id' AS expected_result,
    failed_record_count,
    CASE WHEN failed_record_count = 0 THEN 'PASS' ELSE 'FAIL' END AS check_status
FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E13

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
    WHERE person_id IS NULL
)

SELECT
    'Event' AS table_name,
    'Check for NULL values in person_id. Applicability: All event domains.'
        AS check_description,
    '' AS source_table_name,
    'person_id' AS source_attribute_name,
    'Zero applicable NULL values in person_id' AS expected_result,
    failed_record_count,
    CASE WHEN failed_record_count = 0 THEN 'PASS' ELSE 'FAIL' END AS check_status
FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E14

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
    WHERE event_type IS NULL
)

SELECT
    'Event' AS table_name,
    'Check for NULL values in event_type. Applicability: All event domains.'
        AS check_description,
    '' AS source_table_name,
    'event_type' AS source_attribute_name,
    'Zero applicable NULL values in event_type' AS expected_result,
    failed_record_count,
    CASE WHEN failed_record_count = 0 THEN 'PASS' ELSE 'FAIL' END AS check_status
FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E15

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
    WHERE event_concept_id IS NULL
)

SELECT
    'Event' AS table_name,
    'Check for NULL values in event_concept_id. Applicability: All event domains.'
        AS check_description,
    '' AS source_table_name,
    'event_concept_id' AS source_attribute_name,
    'Zero applicable NULL values in event_concept_id' AS expected_result,
    failed_record_count,
    CASE WHEN failed_record_count = 0 THEN 'PASS' ELSE 'FAIL' END AS check_status
FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E16

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
    WHERE event_type IN (
        'CONDITION',
        'DRUG',
        'PROCEDURE',
        'DEVICE',
        'OBSERVATION',
        'SPECIMEN'
    )
    AND event_start_date IS NULL
)

SELECT
    'Event' AS table_name,
    'Check for NULL values in event_start_date. Applicability: Condition Occurrence, Drug Exposure, Procedure Occurrence, Device Exposure, Observation and Specimen.'
        AS check_description,
    '' AS source_table_name,
    'event_start_date' AS source_attribute_name,
    'Zero applicable NULL values in event_start_date' AS expected_result,
    failed_record_count,
    CASE WHEN failed_record_count = 0 THEN 'PASS' ELSE 'FAIL' END AS check_status
FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E17

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
    WHERE event_type = 'DRUG'
      AND event_end_date IS NULL
)

SELECT
    'Event' AS table_name,
    'Check for NULL values in event_end_date. Applicability: Drug Exposure.'
        AS check_description,
    '' AS source_table_name,
    'event_end_date' AS source_attribute_name,
    'Zero applicable NULL values in event_end_date' AS expected_result,
    failed_record_count,
    CASE WHEN failed_record_count = 0 THEN 'PASS' ELSE 'FAIL' END AS check_status
FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC E18

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM (
        SELECT DISTINCT person_id
        FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_med_validation
    ) e

    LEFT ANTI JOIN (
        SELECT DISTINCT person_id
        FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.patient_med_validation
    ) p
        ON e.person_id = p.person_id
)

SELECT
    'Event' AS table_name,

    'Validate that every person_id in the CDP Event table exists in the CDP Patient table.'
        AS check_description,

    'Patient' AS source_table_name,

    'person_id' AS source_attribute_name,

    'Zero unmatched person_id values' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PPP01

-- COMMAND ----------


WITH counts AS (
    SELECT
        (SELECT COUNT(*)
         FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.payer_plan_period
        ) AS omop_count,

        (SELECT COUNT(*)
         FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_payer_plan_period_med_validation
        ) AS cdp_count
)

SELECT
    'Payer Plan Period' AS table_name,
    'Reconcile CDP Payer Plan Period row count against CDM PAYER_PLAN_PERIOD row count.'
        AS check_description,
    'PAYER_PLAN_PERIOD' AS source_table_name,
    '' AS source_attribute_name,
    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PPP02

-- COMMAND ----------


WITH counts AS (
    SELECT
        (SELECT COUNT(*)
         FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_payer_plan_period_med_validation
        ) AS total_count,

        (SELECT COUNT(*)
         FROM (
             SELECT DISTINCT *
             FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_payer_plan_period_med_validation
         ) d
        ) AS distinct_count
)

SELECT
    'Payer Plan Period' AS table_name,
    'Identify repeated rows in the CDP Payer Plan Period table.'
        AS check_description,
    '' AS source_table_name,
    '' AS source_attribute_name,
    'Zero duplicate rows' AS expected_result,

    total_count - distinct_count AS failed_record_count,

    CASE
        WHEN total_count = distinct_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PPP03

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_payer_plan_period_med_validation
    WHERE payer_plan_period_id IS NULL
)

SELECT
    'Payer Plan Period' AS table_name,
    'Check for NULL values in payer_plan_period_id.'
        AS check_description,
    '' AS source_table_name,
    'payer_plan_period_id' AS source_attribute_name,
    'Zero NULL values in payer_plan_period_id' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PPP04

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_payer_plan_period_med_validation
    WHERE person_id IS NULL
)

SELECT
    'Payer Plan Period' AS table_name,
    'Check for NULL values in person_id.'
        AS check_description,
    '' AS source_table_name,
    'person_id' AS source_attribute_name,
    'Zero NULL values in person_id' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PPP05

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_payer_plan_period_med_validation
    WHERE payer_plan_period_start_date IS NULL
)

SELECT
    'Payer Plan Period' AS table_name,
    'Check for NULL values in payer_plan_period_start_date.'
        AS check_description,
    '' AS source_table_name,
    'payer_plan_period_start_date' AS source_attribute_name,
    'Zero NULL values in payer_plan_period_start_date' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PPP06

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_payer_plan_period_med_validation
    WHERE payer_plan_period_end_date IS NULL
)

SELECT
    'Payer Plan Period' AS table_name,
    'Check for NULL values in payer_plan_period_end_date.'
        AS check_description,
    '' AS source_table_name,
    'payer_plan_period_end_date' AS source_attribute_name,
    'Zero NULL values in payer_plan_period_end_date' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PL01

-- COMMAND ----------


WITH counts AS (
    SELECT
        (SELECT COUNT(*)
         FROM dvmt_rwpl.marketscan_medicare_omop_26q1_qc.custom_location
        ) AS omop_count,

        (SELECT COUNT(*)
         FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_patient_location_med_validation
        ) AS cdp_count
)

SELECT
    'Patient Location' AS table_name,
    'Reconcile CDP Patient Location row count against CDM CUSTOM_LOCATION row count (one row per CUSTOM_LOCATION record).'
        AS check_description,
    'CUSTOM_LOCATION' AS source_table_name,
    '' AS source_attribute_name,
    'Counts match' AS expected_result,

    ABS(omop_count - cdp_count) AS failed_record_count,

    CASE
        WHEN omop_count = cdp_count THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM counts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PL02

-- COMMAND ----------


WITH duplicate_check AS (
    SELECT
        person_id,
        claim_id,
        COUNT(*) AS record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_patient_location_med_validation
    GROUP BY person_id, claim_id
    HAVING COUNT(*) > 1
),

validation AS (
    SELECT
        COALESCE(SUM(record_count - 1), 0) AS failed_record_count
    FROM duplicate_check
)

SELECT
    'Patient Location' AS table_name,
    'Identify repeated patient_id + claim_id combinations in the CDP Patient Location table.'
        AS check_description,
    '' AS source_table_name,
    '' AS source_attribute_name,
    'Zero duplicate patient_id + claim_id combinations' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PL03

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_patient_location_med_validation
    WHERE person_id IS NULL
)

SELECT
    'Patient Location' AS table_name,
    'Check for NULL values in patient_id.' AS check_description,
    '' AS source_table_name,
    'patient_id' AS source_attribute_name,
    'Zero NULL values in patient_id' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PL04

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_patient_location_med_validation
    WHERE claim_id IS NULL
)

SELECT
    'Patient Location' AS table_name,
    'Check for NULL values in claim_id.' AS check_description,
    '' AS source_table_name,
    'claim_id' AS source_attribute_name,
    'Zero NULL values in claim_id' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PL05

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_patient_location_med_validation
    WHERE location_id IS NULL
)

SELECT
    'Patient Location' AS table_name,
    'Check for NULL values in location_id.' AS check_description,
    '' AS source_table_name,
    'location_id' AS source_attribute_name,
    'Zero NULL values in location_id' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC PL06

-- COMMAND ----------


WITH validation AS (
    SELECT COUNT(*) AS failed_record_count
    FROM (
        SELECT DISTINCT person_id
        FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_patient_location_med_validation
    ) e

    LEFT ANTI JOIN (
        SELECT DISTINCT person_id
        FROM dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.patient_med_validation
    ) p
        ON e.person_id = p.person_id)

SELECT
    'Patient Location' AS table_name,
    'Validate that every CDP patient_location.person_id resolves to a record in CDP Patient table.'
        AS check_description,
    'PATIENT' AS source_table_name,
    'person_id' AS source_attribute_name,
    'Zero unmatched person_id values' AS expected_result,

    failed_record_count,

    CASE
        WHEN failed_record_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS check_status

FROM validation;