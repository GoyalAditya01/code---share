# Databricks notebook source
# DBTITLE 1,About
# MAGIC %md
# MAGIC # CDP – derived table checks (test only, writes nothing)
# MAGIC 1. **Excel reader** – the product config Excel and edited copies (rows inserted, bad values, missing parts) in `/tmp`.
# MAGIC 2. **Event / cost rule** on a slice of patients of the static tables:
# MAGIC    cost not selected → one row per (event_id, event_type); cost selected → one row per (event_id, event_type, cost_id), nothing removed.
# MAGIC 3. **Long table** – domains stacked, row counts per domain.

# COMMAND ----------

# DBTITLE 1,Install openpyxl
# MAGIC %pip install openpyxl

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("config_file_path", "/Volumes/dvmt_rwpl/cdp_test/config_files/product1_config.xlsx", "Product config Excel")
dbutils.widgets.text("cdp_schema", "dvmt_rwpl.cdp_test", "Static CDP tables schema")
dbutils.widgets.text("person_slice", "person_id % 1000 = 7", "Patient slice (SQL filter)")

CONFIG_FILE = dbutils.widgets.get("config_file_path").strip()
CDP = dbutils.widgets.get("cdp_schema").strip()
SLICE = dbutils.widgets.get("person_slice").strip()
assert CONFIG_FILE, "Set config_file_path"

# COMMAND ----------

# DBTITLE 1,Imports
import os, sys, importlib, shutil
CODE_DIR = os.path.abspath(os.path.join(os.getcwd(), "..", "script", "code"))
UTILITIES_DIR = os.path.abspath(os.path.join(os.getcwd(), "..", "script", "utilities"))
for p in (CODE_DIR, UTILITIES_DIR):
    if p not in sys.path:
        sys.path.insert(0, p)
import common_constants as C
import product_config_reader as R
import helper as H
from yaml_utility import YamlUtility
for m in (C, R, H):
    importlib.reload(m)

from openpyxl import load_workbook
from pyspark.sql import functions as F

DOMAINS = H.attribute_domains(YamlUtility(conf_file=C.ATTRIBUTE_GROUPING_YAML).get_configuration([C.VAR_DOMAIN, C.VAR_DOMAIN_LIST]))
DERIVED_CFG = YamlUtility(conf_file=C.DERIVED_VARIABLE_YAML).yaml_configuration
RULES = H.event_settings(DERIVED_CFG[C.VAR_EVENT_RULES])
SETTINGS = H.table_settings(DERIVED_CFG[C.VAR_DERIVED_TABLE])
RESULTS = []

def record(name, ok, detail=""):
    RESULTS.append((name, bool(ok), str(detail)[:500]))
    print(("PASS " if ok else "FAIL ") + name, detail)

# COMMAND ----------

# DBTITLE 1,Excel helpers (edited copies in /tmp)
WORK = "/tmp/cdp_derived_tests"
os.makedirs(WORK, exist_ok=True)

def find_cell(ws, text):
    """First cell whose text starts with `text` (case-insensitive)."""
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is not None and str(cell.value).strip().lower().startswith(text.lower()):
                return cell
    raise KeyError(text)

def header_col(ws, marker, header):
    """Column number of `header` in the header row under section `marker`."""
    m = find_cell(ws, f"[{marker}]")
    for r in range(m.row + 1, m.row + 5):
        for cell in ws[r]:
            if cell.value is not None and R.normalize_header(cell.value) == header:
                return cell.column, r
    raise KeyError(header)

def set_include(ws, selected):
    """Include = Y for the selected domains, blank for the others."""
    col, hdr_row = header_col(ws, C.SECTION_EXPORT_COLUMNS, C.HDR_INCLUDE)
    name_col, _ = header_col(ws, C.SECTION_EXPORT_COLUMNS, C.HDR_OUTPUT_ATTRIBUTE_NAME)
    r, found = hdr_row + 1, set()
    while ws.cell(r, name_col).value:
        name = str(ws.cell(r, name_col).value).strip().lower()
        ws.cell(r, col).value = "Y" if name in selected else None
        found.add(name)
        r += 1
    missing = set(selected) - found
    assert not missing, f"[{C.SECTION_EXPORT_COLUMNS}] has no row for {sorted(missing)}"

def set_run_setting(ws, parameter, value):
    col, _ = header_col(ws, C.SECTION_RUN_SETTINGS, C.HDR_VALUE)
    ws.cell(find_cell(ws, parameter).row, col).value = value

def variant(name, edit):
    """Copy of the Excel with edit(ws) applied to the CDP Config sheet; returns its path."""
    path = f"{WORK}/{name}.xlsx"
    wb = load_workbook(CONFIG_FILE)
    ws = wb[C.CONFIG_SHEET_NAME] if C.CONFIG_SHEET_NAME in wb.sheetnames else wb.worksheets[0]
    edit(ws)
    wb.save(path)
    return path

def expect_error(name, path, text):
    try:
        R.read_product_config(path)
        record(name, False, "no error raised")
    except R.ProductConfigError as exc:
        record(name, any(text.lower() in e.lower() for e in exc.errors), exc.errors)

# COMMAND ----------

# DBTITLE 1,1. Excel reader
base = variant("base", lambda ws: set_include(ws, {"demographic", "condition"}))
cfg = R.read_product_config(base)
print(cfg.describe())
record("reader: selected domains", cfg.selected_domains == ["demographic", "condition"], cfg.selected_domains)
record("reader: run settings", cfg.dataset_name and cfg.refresh and cfg.run_mode in C.RUN_MODES, cfg.describe())
record("reader: derived variables read", len(cfg.derived_variables) > 0,
       [v[C.HDR_OUTPUT_ATTRIBUTE_NAME] for v in cfg.derived_variables])

def shifted(ws):
    set_include(ws, {"demographic", "condition"})
    for merged in list(ws.merged_cells.ranges):   # openpyxl does not move merged ranges on insert
        ws.unmerge_cells(str(merged))
    ws.insert_rows(1, 3)                       # everything moves down 3 rows
    ws.insert_rows(find_cell(ws, f"[{C.SECTION_EXPORT_COLUMNS}]").row, 2)   # blank rows between sections
cfg_shifted = R.read_product_config(variant("shifted", shifted))
record("reader: rows inserted -> same result",
       cfg_shifted.describe() == cfg.describe(), cfg_shifted.describe())

expect_error("reader: nothing selected", variant("none", lambda ws: set_include(ws, set())), "no domain has Include")
expect_error("reader: bad Include value",
             variant("bad_yn", lambda ws: (set_include(ws, {"demographic"}),
                                          ws.cell(find_cell(ws, "Location").row,
                                                  header_col(ws, C.SECTION_EXPORT_COLUMNS, C.HDR_INCLUDE)[0]).__setattr__("value", "Yes"))),
             "is not in the")
expect_error("reader: Update without table",
             variant("update_no_table", lambda ws: (set_include(ws, {"demographic"}),
                                                   set_run_setting(ws, "run_mode", "Update"),
                                                   set_run_setting(ws, "previous_derived_table_name", None))),
             "needs previous_derived_table_name")
expect_error("reader: dataset not in Admin list",
             variant("bad_dataset", lambda ws: (set_include(ws, {"demographic"}),
                                               set_run_setting(ws, "dataset_name", "Unknown DS"))),
             "dataset_name")
expect_error("reader: missing section",
             variant("no_section", lambda ws: (set_include(ws, {"demographic"}),
                                              find_cell(ws, f"[{C.SECTION_DERIVED_VARIABLES}]").__setattr__("value", "DERIVED"))),
             f"[{C.SECTION_DERIVED_VARIABLES}] not found")
expect_error("reader: missing header",
             variant("no_header", lambda ws: (set_include(ws, {"demographic"}),
                                             find_cell(ws, "Include").__setattr__("value", "Selected"))),
             "missing column")

# COMMAND ----------

# DBTITLE 1,2. Selection rules
try:
    H.selection_plan(["cost"], DOMAINS, RULES)
    record("plan: cost without event domain -> error", False, "no error")
except ValueError as exc:
    record("plan: cost without event domain -> error", "cost" in str(exc), exc)
p = H.selection_plan(["demographic", "condition", "procedure"], DOMAINS, RULES)
record("plan: no cost -> key (event_id, event_type)", p["event_key"] == ["event_id", "event_type"] and not p["cost_selected"], p)
record("plan: no cost -> no cost columns", "cost_id" not in [c.lower() for c in p["event_columns"]], p["event_columns"])
p = H.selection_plan(["condition", "cost"], DOMAINS, RULES)
record("plan: cost -> key (event_id, event_type, cost_id)", p["event_key"] == ["event_id", "event_type", "cost_id"], p)

# COMMAND ----------

# DBTITLE 1,3. Event / cost rule on the patient slice
event = spark.table(f"{CDP}.event").filter(SLICE)
dom = SETTINGS[C.VAR_DOMAIN_COLUMN]

# cost NOT selected: one row per (event_id, event_type)
plan = H.selection_plan(["condition", "procedure"], DOMAINS, RULES)
df, key = H.event_frame(event, plan, RULES, dom)
rows, distinct_keys = df.count(), df.select(*key).distinct().count()
expected = event.filter(F.col("event_type").isin("CONDITION", "PROCEDURE")).select("event_id", "event_type").distinct().count()
record("event: no cost -> unique (event_id, event_type)", rows == distinct_keys == expected,
       f"rows={rows} distinct={distinct_keys} expected={expected}")
record("event: no cost -> no cost columns", "cost_id" not in [c.lower() for c in df.columns], df.columns)
record("event: domain values", {r[0] for r in df.select(dom).distinct().collect()} <= {"condition", "procedure"})

# cost selected: nothing removed, (event_id, event_type, cost_id) unique
if "cost_id" in [c.lower() for c in event.columns]:
    plan = H.selection_plan(["condition", "cost"], DOMAINS, RULES)
    df, key = H.event_frame(event, plan, RULES, dom)
    rows, distinct_keys = df.count(), df.select(*key).distinct().count()
    expected = event.filter(F.col("event_type") == "CONDITION").count()
    record("event: cost -> all rows kept, key unique", rows == distinct_keys == expected,
           f"rows={rows} distinct={distinct_keys} expected={expected}")
else:
    record("event: cost -> all rows kept, key unique", False, f"{CDP}.event has no cost_id column (rebuild event)")

# COMMAND ----------

# DBTITLE 1,4. Long table (demographic + location + condition) on the slice
plan = H.selection_plan(["demographic", "location", "condition"], DOMAINS, RULES)
frames = []
for d in plan["other_domains"]:
    table = DOMAINS[d][0][1]
    frames.append((d, H.domain_frame(spark.table(f"{CDP}.{table}").filter(SLICE), d, [c for c, _ in DOMAINS[d]], dom)))
frames.append(("event", H.event_frame(event, plan, RULES, dom)[0]))
long = H.long_table(frames, dom, SETTINGS[C.VAR_LEAD_COLUMNS])
counts = {r[0]: r[1] for r in long.groupBy(dom).count().collect()}
expected = {
    "demographic": spark.table(f"{CDP}.patient").filter(SLICE).count(),
    "location": spark.table(f"{CDP}.patient_location").filter(SLICE).count(),
    "condition": event.filter(F.col("event_type") == "CONDITION").select("event_id", "event_type").distinct().count(),
}
record("long: rows per domain", all(counts.get(k, 0) == v for k, v in expected.items()), f"got={counts} expected={expected}")
record("long: column order", long.columns[:2] == [dom, "person_id"], long.columns[:5])
display(long.limit(20))

# COMMAND ----------

# DBTITLE 1,Summary
display(spark.createDataFrame(RESULTS, "check string, passed boolean, detail string"))
print("ALL PASSED" if all(r[1] for r in RESULTS) else "FAILURES FOUND")
shutil.rmtree(WORK, ignore_errors=True)