# Databricks notebook source
# DBTITLE 1,About
# MAGIC %md
# MAGIC # STTM SQL (source) vs CDP tables
# MAGIC Runs the **SQL Query** shared in `CDM CDP/Core_Data_Product_STTM (1).xlsx` (one per sheet: Patient, Payer Plan Period, Patient_Location, Event column J) against the source OMOP schema, and compares the result with the CDP tables built by `transformation_mapping` (`EXCEPT ALL` both ways = exact match, duplicates included).
# MAGIC
# MAGIC The STTM SQL has a few typos; the fixes below are the only changes made (each one is asserted, so the notebook stops if the STTM text changes):
# MAGIC
# MAGIC | Table | Fix |
# MAGIC | --- | --- |
# MAGIC | patient | missing comma after `death_cause`; `JOINdvmt` -> `JOIN dvmt`; `dt.death_type_concept_name` -> `dt.concept_name` |
# MAGIC | payer_plan_period | `LEFT JOIN 'Event'!J6plc` (Excel cell reference) -> `LEFT JOIN ...INTD_CONCEPT plc` |
# MAGIC | patient_location | placeholder `rwd_omop_<dataset>_<refresh>.` -> source schema |
# MAGIC | event | alias `asc` -> `asc_concept` (the column list already uses `asc_concept`) |
# MAGIC
# MAGIC Event is compared on a patient slice (full event is ~51 billion rows).

# COMMAND ----------

# DBTITLE 1,Install openpyxl
# MAGIC %pip install openpyxl

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("sttm_path", "/Workspace/Users/dhanush.x.r@viivhealthcare.com/CDM CDP/Core_Data_Product_STTM (1).xlsx", "STTM Excel")
dbutils.widgets.text("source_schema", "dvmt_rwpl.marketscan_commercial_omop_26q1_qc", "Source OMOP schema")
dbutils.widgets.text("int_schema", "dvmt_rwpl.marketscan_commercial_omop_26q1_int", "Schema with INTD_CONCEPT")
dbutils.widgets.text("cdp_schema", "dvmt_rwpl.cdp_test", "CDP tables schema")
dbutils.widgets.text("event_slice", "person_id % 1000 = 7", "Event patient slice (SQL filter)")

STTM = dbutils.widgets.get("sttm_path").strip()
SRC = dbutils.widgets.get("source_schema").strip()
INT = dbutils.widgets.get("int_schema").strip()
CDP = dbutils.widgets.get("cdp_schema").strip()
EVENT_SLICE = dbutils.widgets.get("event_slice").strip()

# COMMAND ----------

# DBTITLE 1,Read the STTM SQL and apply the typo fixes
from openpyxl import load_workbook

wb = load_workbook(STTM, data_only=True)

def sttm_sql(sheet, column):
    """SQL Query cell of a sheet: the cell in `column` under the 'SQL Query' header."""
    ws = wb[sheet]
    for row in ws.iter_rows():
        for c in row:
            if c.column_letter == column and isinstance(c.value, str) and c.value.strip().lower() == "sql query":
                return ws[f"{column}{c.row + 1}"].value
    raise KeyError(f"{sheet}: no 'SQL Query' header in column {column}")

def fix(sql, subs):
    """Apply exact text fixes; stop if the STTM text no longer contains them."""
    for old, new in subs:
        assert old in sql, f"expected text not found in STTM SQL: {old!r}"
        sql = sql.replace(old, new)
    return sql.strip().rstrip(";")

SQL = {
    "patient": fix(sttm_sql("Patient", "I"), [
        ("AS death_cause\n", "AS death_cause,\n"),
        ("JOINdvmt", "JOIN dvmt"),
        ("dt.death_type_concept_name", "dt.concept_name"),
        ("dt. concept_id", "dt.concept_id")]),
    "payer_plan_period": fix(sttm_sql("Payer Plan Period", "I"), [
        ("'Event'!J6plc", f"{INT}.INTD_CONCEPT plc")]),
    "patient_location": fix(sttm_sql("Patient_Location", "I"), [
        ("rwd_omop_<dataset>_<refresh>.", f"{SRC}.")]),
    "event": fix(sttm_sql("Event", "J"), [
        ("INTD_CONCEPT asc ON", "INTD_CONCEPT asc_concept ON")]),
}
for t, q in SQL.items():
    print(f"{t}: {len(q):,} characters of SQL")

# COMMAND ----------

# DBTITLE 1,Show the SQL used per table
# Full text of each (fixed) STTM query, as run against the source
for t, q in SQL.items():
    print(f"\n{'=' * 30} {t} {'=' * 30}\n{q if t != 'event' else q[:3000] + chr(10) + '... (event SQL truncated in print; full text in SQL[\"event\"])'}")

# COMMAND ----------

# DBTITLE 1,Compare helper
RESULTS = []

def compare(table, where=None):
    """STTM SQL result vs CDP table: columns, row counts, EXCEPT ALL both ways (duplicates included)."""
    cdp = spark.table(f"{CDP}.{table}")
    src = spark.sql(SQL[table])
    if where:
        cdp, src = cdp.filter(where), src.filter(where)
    cols = cdp.columns
    src_cols = {c.lower() for c in src.columns}
    missing = [c for c in cols if c.lower() not in src_cols]
    extra = sorted(src_cols - {c.lower() for c in cols})
    if missing or extra:
        RESULTS.append((table, where or "full", None, None, None, None, False, f"columns differ: missing={missing} extra={extra}"))
        return
    src = src.select(*cols)
    n_src, n_cdp = src.count(), cdp.count()
    only_src = src.exceptAll(cdp).count()
    only_cdp = cdp.exceptAll(src).count()
    ok = n_src == n_cdp and only_src == 0 and only_cdp == 0
    RESULTS.append((table, where or "full", n_src, n_cdp, only_src, only_cdp, ok, "exact match" if ok else "DIFFERENCES"))
    print(f"{'PASS' if ok else 'FAIL'} {table} ({where or 'full'}): source={n_src:,} cdp={n_cdp:,} only_source={only_src:,} only_cdp={only_cdp:,}")

# COMMAND ----------

# DBTITLE 1,Patient
compare("patient")

# COMMAND ----------

# DBTITLE 1,Payer plan period
compare("payer_plan_period")

# COMMAND ----------

# DBTITLE 1,Patient location
compare("patient_location")

# COMMAND ----------

# DBTITLE 1,Event (patient slice)
compare("event", EVENT_SLICE)

# COMMAND ----------

# DBTITLE 1,Summary
display(spark.createDataFrame(RESULTS, "table string, scope string, source_rows long, cdp_rows long, only_in_source long, only_in_cdp long, passed boolean, detail string"))
print("ALL MATCH" if RESULTS and all(r[6] for r in RESULTS) else "DIFFERENCES FOUND")