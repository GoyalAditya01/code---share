# Databricks notebook source
# DBTITLE 1,Parameters
# Compares the CDP tables written by transformation_mapping (qc schema) with the reference tables.
# Test only: not part of the production flow.
dbutils.widgets.text("cdp_schema", "dvmt_rwpl.cdp_test", "Generated CDP schema")
dbutils.widgets.text("reference_schema", "dvmt_rwpl.marketscan_commercial_cdm_2026q1_int", "Reference schema")
dbutils.widgets.text("intd_reference", "dvmt_rwpl.marketscan_commercial_omop_26q1_int.intd_concept", "intd_concept reference")
dbutils.widgets.text("tables", "intd_concept,patient,payer_plan_period,patient_location,event", "Tables to validate")
dbutils.widgets.text("event_slice", "person_id % 1000 = 7", "Event exact-check slice")

CDP = dbutils.widgets.get("cdp_schema")
REF = dbutils.widgets.get("reference_schema")
INTD_REF = dbutils.widgets.get("intd_reference")
TABLES = [t.strip() for t in dbutils.widgets.get("tables").split(",") if t.strip()]
EVENT_SLICE = dbutils.widgets.get("event_slice")

# generated table -> reference table, and how it is checked
PAIRS = {
    "intd_concept":      (INTD_REF,                                "exact"),
    "patient":           (f"{REF}.patient_validation",              "exact"),
    "payer_plan_period": (f"{REF}.cdp_payer_plan_period_validation", "exact"),
    "patient_location":  (f"{REF}.cdp_patient_location_validation",  "exact"),
    "event":             (f"{REF}.cdp_event_validation",            "checksum+slice"),
}

# COMMAND ----------

# DBTITLE 1,Import helper
import os, sys, importlib
CODE_DIR = os.path.abspath(os.path.join(os.getcwd(), "..", "script", "code"))
UTILITIES_DIR = os.path.abspath(os.path.join(os.getcwd(), "..", "script", "utilities"))
for p in (CODE_DIR, UTILITIES_DIR):  # helper imports common_constants from utilities
    if p not in sys.path:
        sys.path.insert(0, p)
import common_constants
import helper
importlib.reload(common_constants)
importlib.reload(helper)
print("helper from", helper.__file__)

# COMMAND ----------

# DBTITLE 1,Exact checks: schema, row counts, EXCEPT ALL both ways
import time
RESULTS = []
for t in TABLES:
    ref_name, mode = PAIRS[t]
    if mode != "exact":
        continue
    t0 = time.time()
    r = helper.reconcile(spark.table(f"{CDP}.{t}"), spark.table(ref_name), t)
    r.update({"reference": ref_name, "check": "full EXCEPT ALL", "minutes": round((time.time() - t0) / 60, 1)})
    RESULTS.append(r)
    print(r)

# COMMAND ----------

# DBTITLE 1,Event: full-table checksum by event_type + exact slice
# The event tables are ~51B rows, so a full EXCEPT ALL is impractical.
# 1) Full-table checksum: row count + sum of a 64-bit row hash, per event_type, both tables.
# 2) Exact EXCEPT ALL in both directions on a fixed slice of patients.
if "event" in TABLES:
    ref_name, _ = PAIRS["event"]
    gen, ref, schema_report = helper.align_columns(spark.table(f"{CDP}.event"), spark.table(ref_name))
    print("schema:", schema_report)

    t0 = time.time()
    gen_sum = helper.checksum(gen, "event_type")
    ref_sum = helper.checksum(ref, "event_type")
    rows = []
    for et in sorted(set(gen_sum) | set(ref_sum), key=str):
        g, r = gen_sum.get(et, (0, None)), ref_sum.get(et, (0, None))
        rows.append((et, g[0], r[0], g[0] == r[0], g[1] == r[1]))
    display(spark.createDataFrame(rows, "event_type string, generated_rows long, reference_rows long, rows_match boolean, checksum_match boolean"))
    checksum_ok = all(x[3] and x[4] for x in rows)
    RESULTS.append({"table": "event", "reference": ref_name, "check": "full checksum by event_type",
                    "generated_rows": sum(x[1] for x in rows), "reference_rows": sum(x[2] for x in rows),
                    "exact_match": checksum_ok and not any(schema_report.values()),
                    "minutes": round((time.time() - t0) / 60, 1)})
    print(RESULTS[-1])

    t0 = time.time()
    r = helper.reconcile(spark.table(f"{CDP}.event").filter(EVENT_SLICE), spark.table(ref_name).filter(EVENT_SLICE), "event")
    r.update({"reference": ref_name, "check": f"EXCEPT ALL on slice ({EVENT_SLICE})", "minutes": round((time.time() - t0) / 60, 1)})
    RESULTS.append(r)
    print(r)

# COMMAND ----------

# DBTITLE 1,Summary
cols = ["table", "reference", "check", "generated_rows", "reference_rows",
        "generated_minus_reference", "reference_minus_generated", "exact_match", "minutes"]
summary = [tuple(str(r.get(c)) if r.get(c) is not None else None for c in cols) for r in RESULTS]
display(spark.createDataFrame(summary, ", ".join(f"{c} string" for c in cols)))
print("ALL MATCH" if all(r["exact_match"] for r in RESULTS) else "MISMATCHES FOUND")