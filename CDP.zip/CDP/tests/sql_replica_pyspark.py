# Databricks notebook source
# MAGIC %sql
# MAGIC select * from dvmt_rwpl.cdp_test.cdp_qc_result

# COMMAND ----------

# DBTITLE 1,About
# MAGIC %md
# MAGIC # CDP – PySpark replica of the STTM SQL
# MAGIC Plain PySpark DataFrame replica of each table's SQL query in `Core_Data_Product_STTM (1).xlsx` (and `CDP Main.txt` for intd_concept), same business logic, **no Spark SQL** (no `spark.sql`, `F.expr`, `selectExpr`, UDFs).
# MAGIC
# MAGIC * All joins are LEFT, exactly as in the SQL. Concept look-ups use `intd_concept` in every table (incl. event).
# MAGIC * Data types are the CASTs in each table's own SQL query.
# MAGIC * intd_concept is built from Athena (`concept` UNION ALL `concept_cpt4`) when `dvmt_rwre` is accessible; the look-ups in the other tables read `intd_concept_standin` (the copy the validated `cdp_test` tables were built from).
# MAGIC * Nothing is written: each replica is compared in memory with the validated tables in `baseline_schema`.

# COMMAND ----------

# DBTITLE 1,Parameters and helpers
from functools import reduce
from pyspark.sql import functions as F

dbutils.widgets.text("source_schema", "dvmt_rwpl.marketscan_commercial_omop_26q1_qc")
dbutils.widgets.text("athena_schema", "dvmt_rwre.rwd_reference_athena_26q2")
dbutils.widgets.text("intd_concept_standin", "dvmt_rwpl.cdp_test.intd_concept")
dbutils.widgets.text("baseline_schema", "dvmt_rwpl.cdp_test")
dbutils.widgets.dropdown("event_full_count", "true", ["true", "false"])

SRC = dbutils.widgets.get("source_schema")
ATHENA = dbutils.widgets.get("athena_schema")
STANDIN = dbutils.widgets.get("intd_concept_standin")
BASE = dbutils.widgets.get("baseline_schema")
EVENT_FULL_COUNT = dbutils.widgets.get("event_full_count") == "true"


def src(table):
    return spark.table(f"{SRC}.{table}")


concepts = spark.table(STANDIN).select("concept_id", "concept_name")


def lookup(df, key_col, name_col):
    """LEFT JOIN intd_concept ON concept_id = df.key_col  ->  adds name_col (= concept_name)."""
    k = f"__cid_{name_col}"
    c = concepts.select(F.col("concept_id").alias(k), F.col("concept_name").alias(name_col))
    return df.join(c, F.col(k) == F.col(key_col), "left").drop(k)


def project(df, cols):
    """Final SELECT: [(column, type, output_name), ...] -> CAST(column AS type) AS output_name."""
    return df.select(*[F.col(c).cast(t).alias(n) for c, t, n in cols])

# COMMAND ----------

# DBTITLE 1,intd_concept
# concept UNION ALL concept_cpt4 (CDP Main.txt)
def athena_branch(table, start_col, end_col):
    t = spark.table(f"{ATHENA}.{table}")
    return project(t, [
        ("concept_id", "int", "CONCEPT_ID"),
        ("concept_name", "string", "CONCEPT_NAME"),
        ("domain_id", "string", "DOMAIN_ID"),
        ("vocabulary_id", "string", "VOCABULARY_ID"),
        ("concept_class_id", "string", "CONCEPT_CLASS_ID"),
        ("standard_concept", "string", "STANDARD_CONCEPT"),
        ("concept_code", "string", "CONCEPT_CODE"),
        (start_col, "date", "VALID_START_DATE"),
        (end_col, "date", "VALID_END_DATE"),
        ("invalid_reason", "string", "INVALID_REASON"),
    ])

try:
    intd_concept = athena_branch("concept", "t_valid_start_date", "t_valid_end_date").unionByName(
        athena_branch("concept_cpt4", "valid_start_date", "valid_end_date"))
    INTD_STATUS = "built from Athena"
except Exception as e:
    intd_concept = None
    INTD_STATUS = f"not built: Athena not accessible ({type(e).__name__}: {str(e).splitlines()[0][:150]})"
print("intd_concept:", INTD_STATUS)

# COMMAND ----------

# DBTITLE 1,patient
person = src("person").select(
    "person_id", "person_source_value", "gender_concept_id", "year_of_birth", "month_of_birth",
    "day_of_birth", "race_concept_id", "ethnicity_concept_id")
death = src("death").select(
    F.col("person_id").alias("d_person_id"), F.col("death_date").alias("d_death_date"),
    F.col("cause_concept_id").alias("d_cause_concept_id"),
    F.col("death_type_concept_id").alias("d_death_type_concept_id"))

df = lookup(person, "gender_concept_id", "gc_name")
df = lookup(df, "race_concept_id", "rc_name")
df = lookup(df, "ethnicity_concept_id", "ec_name")
df = df.join(death, F.col("d_person_id") == F.col("person_id"), "left")
df = lookup(df, "d_cause_concept_id", "dc_name")
df = lookup(df, "d_death_type_concept_id", "dt_name")
# CASE WHEN d.person_id IS NOT NULL THEN TRUE ELSE FALSE END
df = df.withColumn("death_flag_", F.when(F.col("d_person_id").isNotNull(), F.lit(True)).otherwise(F.lit(False)))

patient = project(df, [
    ("person_id", "bigint", "person_id"),
    ("person_source_value", "string", "person_source_value"),
    ("gc_name", "string", "gender_concept_name"),
    ("year_of_birth", "int", "year_of_birth"),
    ("month_of_birth", "int", "month_of_birth"),
    ("day_of_birth", "int", "day_of_birth"),
    ("rc_name", "string", "race_concept_name"),
    ("ec_name", "string", "ethnicity_concept_name"),
    ("death_flag_", "boolean", "death_flag"),
    ("d_death_date", "date", "death_date"),
    ("dc_name", "string", "death_cause"),
    ("dt_name", "string", "death_type"),   # STTM typo dt.death_type_concept_name -> dt.concept_name
])

# COMMAND ----------

# DBTITLE 1,payer_plan_period
ppp = src("payer_plan_period").select(
    "payer_plan_period_id", "person_id", "payer_plan_period_start_date", "payer_plan_period_end_date",
    "payer_concept_id", "plan_concept_id", "sponsor_concept_id", "stop_reason_concept_id", "family_source_value")

df = lookup(ppp, "payer_concept_id", "pc_name")
df = lookup(df, "plan_concept_id", "plc_name")   # STTM cell reference 'Event'!J6 -> INTD_CONCEPT
df = lookup(df, "sponsor_concept_id", "spc_name")
df = lookup(df, "stop_reason_concept_id", "src_name")

payer_plan_period = project(df, [
    ("payer_plan_period_id", "bigint", "payer_plan_period_id"),
    ("person_id", "bigint", "person_id"),
    ("payer_plan_period_start_date", "date", "payer_plan_period_start_date"),
    ("payer_plan_period_end_date", "date", "payer_plan_period_end_date"),
    ("payer_concept_id", "bigint", "payer_concept_id"),
    ("pc_name", "string", "payer_concept_name"),
    ("plc_name", "string", "plan_concept_name"),
    ("spc_name", "string", "sponsor_concept_name"),
    ("src_name", "string", "stop_reason"),
    ("family_source_value", "string", "family_source_value"),
])

# COMMAND ----------

# DBTITLE 1,patient_location
cl = src("custom_location").select("person_id", "claim_id", "location_id")
loc = src("location").select(
    F.col("location_id").alias("l_location_id"), "address_1", "address_2", "city", "state", "zip",
    "county", "location_source_value", "country_concept_id", "latitude", "longitude")

df = cl.join(loc, F.col("location_id") == F.col("l_location_id"), "left")
df = lookup(df, "country_concept_id", "cc_name")

patient_location = project(df, [
    ("person_id", "bigint", "PERSON_ID"),
    ("claim_id", "string", "CLAIM_ID"),
    ("location_id", "bigint", "LOCATION_ID"),
    ("address_1", "string", "ADDRESS_1"),
    ("address_2", "string", "ADDRESS_2"),
    ("city", "string", "CITY"),
    ("state", "string", "STATE"),
    ("zip", "string", "ZIP"),
    ("county", "string", "COUNTY"),
    ("location_source_value", "string", "LOCATION_SOURCE_VALUE"),
    ("cc_name", "string", "COUNTRY_CONCEPT_NAME"),
    ("latitude", "float", "LATITUDE"),
    ("longitude", "float", "LONGITUDE"),
])

# COMMAND ----------

# DBTITLE 1,event
# clinical_events: 9 domain SELECTs combined with UNION ALL (columns a domain lacks are CAST(NULL AS <type>))
UNION_COLS = [
    ("event_id", "bigint"), ("person_id", "bigint"), ("event_type", "string"), ("event_start_date", "date"),
    ("event_end_date", "date"), ("event_concept_id", "int"), ("event_source_value", "string"),
    ("record_type_id", "int"), ("provider_id", "bigint"), ("visit_occurrence_id", "bigint"),
    ("visit_detail_id", "bigint"), ("care_site_id", "bigint"), ("preceding_visit_occurrence_id", "bigint"),
    ("quantity", "float"), ("stop_reason", "string"), ("value_as_number", "float"), ("value_as_string", "string"),
    ("value_concept_id", "int"), ("unit_concept_id", "int"), ("condition_status_id", "int"), ("days_supply", "int"),
    ("refills", "int"), ("sig", "string"), ("route_concept_id", "int"), ("dose_unit_source_value", "string"),
    ("modifier_concept_id", "int"), ("unique_device_id", "string"), ("operator_concept_id", "int"),
    ("range_low", "float"), ("range_high", "float"), ("qualifier_concept_id", "int"),
    ("anatomic_site_concept_id", "int"), ("disease_status_concept_id", "int"), ("admitted_from_concept_id", "int"),
    ("discharged_to_concept_id", "int"), ("measurement_event_id", "int"), ("meas_event_field_concept_id", "int"),
    ("observation_event_id", "int"), ("obs_event_field_concept_id", "int"), ("verbatim_end_date", "date"),
    ("lot_number", "string"), ("production_id", "string"),
]

# (source table, event_type constant, {union column: source column}); unlisted columns are NULL
BRANCHES = [
    ("visit_occurrence", "VISIT", {
        "event_id": "visit_occurrence_id", "person_id": "person_id", "event_start_date": "visit_start_date",
        "event_end_date": "visit_end_date", "event_concept_id": "visit_concept_id",
        "event_source_value": "visit_source_value", "record_type_id": "visit_type_concept_id",
        "provider_id": "provider_id", "visit_occurrence_id": "visit_occurrence_id", "care_site_id": "care_site_id",
        "preceding_visit_occurrence_id": "preceding_visit_occurrence_id",
        "admitted_from_concept_id": "admitted_from_concept_id", "discharged_to_concept_id": "discharged_to_concept_id"}),
    ("condition_occurrence", "CONDITION", {
        "event_id": "condition_occurrence_id", "person_id": "person_id", "event_start_date": "condition_start_date",
        "event_end_date": "condition_end_date", "event_concept_id": "condition_concept_id",
        "event_source_value": "condition_source_value", "record_type_id": "condition_type_concept_id",
        "provider_id": "provider_id", "visit_occurrence_id": "visit_occurrence_id", "visit_detail_id": "visit_detail_id",
        "stop_reason": "stop_reason", "condition_status_id": "condition_status_concept_id"}),
    ("procedure_occurrence", "PROCEDURE", {
        "event_id": "procedure_occurrence_id", "person_id": "person_id", "event_start_date": "procedure_date",
        "event_end_date": "procedure_end_date", "event_concept_id": "procedure_concept_id",
        "event_source_value": "procedure_source_value", "record_type_id": "procedure_type_concept_id",
        "provider_id": "provider_id", "visit_occurrence_id": "visit_occurrence_id", "visit_detail_id": "visit_detail_id",
        "quantity": "quantity", "modifier_concept_id": "modifier_concept_id"}),
    ("drug_exposure", "DRUG", {
        "event_id": "drug_exposure_id", "person_id": "person_id", "event_start_date": "drug_exposure_start_date",
        "event_end_date": "drug_exposure_end_date", "event_concept_id": "drug_concept_id",
        "event_source_value": "drug_source_value", "record_type_id": "drug_type_concept_id",
        "provider_id": "provider_id", "visit_occurrence_id": "visit_occurrence_id", "visit_detail_id": "visit_detail_id",
        "quantity": "quantity", "stop_reason": "stop_reason", "days_supply": "days_supply", "refills": "refills",
        "sig": "sig", "route_concept_id": "route_concept_id", "dose_unit_source_value": "dose_unit_source_value",
        "verbatim_end_date": "verbatim_end_date", "lot_number": "lot_number"}),
    ("device_exposure", "DEVICE", {
        "event_id": "device_exposure_id", "person_id": "person_id", "event_start_date": "device_exposure_start_date",
        "event_end_date": "device_exposure_end_date", "event_concept_id": "device_concept_id",
        "event_source_value": "device_source_value", "record_type_id": "device_type_concept_id",
        "provider_id": "provider_id", "visit_occurrence_id": "visit_occurrence_id", "visit_detail_id": "visit_detail_id",
        "quantity": "quantity", "unit_concept_id": "unit_concept_id", "unique_device_id": "unique_device_id",
        "production_id": "production_id"}),
    ("measurement", "MEASUREMENT", {
        "event_id": "measurement_id", "person_id": "person_id", "event_start_date": "measurement_date",
        "event_concept_id": "measurement_concept_id", "event_source_value": "measurement_source_value",
        "record_type_id": "measurement_type_concept_id", "provider_id": "provider_id",
        "visit_occurrence_id": "visit_occurrence_id", "visit_detail_id": "visit_detail_id",
        "value_as_number": "value_as_number", "value_concept_id": "value_as_concept_id",
        "unit_concept_id": "unit_concept_id", "operator_concept_id": "operator_concept_id", "range_low": "range_low",
        "range_high": "range_high", "measurement_event_id": "measurement_event_id",
        "meas_event_field_concept_id": "meas_event_field_concept_id"}),
    ("observation", "OBSERVATION", {
        "event_id": "observation_id", "person_id": "person_id", "event_start_date": "observation_date",
        "event_concept_id": "observation_concept_id", "event_source_value": "observation_source_value",
        "record_type_id": "observation_type_concept_id", "provider_id": "provider_id",
        "visit_occurrence_id": "visit_occurrence_id", "visit_detail_id": "visit_detail_id",
        "value_as_number": "value_as_number", "value_as_string": "value_as_string",
        "value_concept_id": "value_as_concept_id", "unit_concept_id": "unit_concept_id",
        "qualifier_concept_id": "qualifier_concept_id", "observation_event_id": "observation_event_id",
        "obs_event_field_concept_id": "obs_event_field_concept_id"}),
    ("specimen", "SPECIMEN", {
        "event_id": "specimen_id", "person_id": "person_id", "event_start_date": "specimen_date",
        "event_concept_id": "specimen_concept_id", "event_source_value": "specimen_source_value",
        "record_type_id": "specimen_type_concept_id", "quantity": "quantity", "unit_concept_id": "unit_concept_id",
        "anatomic_site_concept_id": "anatomic_site_concept_id",
        "disease_status_concept_id": "disease_status_concept_id"}),
    ("visit_detail", "VISIT_DETAIL", {
        "event_id": "visit_detail_id", "person_id": "person_id", "event_start_date": "visit_detail_start_date",
        "event_end_date": "visit_detail_end_date", "event_concept_id": "visit_detail_concept_id",
        "event_source_value": "visit_detail_source_value", "record_type_id": "visit_detail_type_concept_id",
        "provider_id": "provider_id", "visit_occurrence_id": "visit_occurrence_id", "visit_detail_id": "visit_detail_id",
        "care_site_id": "care_site_id", "admitted_from_concept_id": "admitted_from_concept_id",
        "discharged_to_concept_id": "discharged_to_concept_id"}),
]


def branch(table, event_type, mapping):
    cols = []
    for name, typ in UNION_COLS:
        if name == "event_type":
            c = F.lit(event_type)
        elif name in mapping:
            c = F.col(mapping[name])
        else:
            c = F.lit(None)
        cols.append(c.cast(typ).alias(name))
    return src(table).select(*cols)


VISIT_TYPES = ["VISIT", "VISIT_DETAIL"]
COST_AMOUNTS = ["total_charge", "total_cost", "total_paid", "amount_allowed", "paid_by_payer", "paid_by_patient",
                "paid_patient_copay", "paid_patient_coinsurance", "paid_patient_deductible", "paid_by_primary",
                "paid_ingredient_cost", "paid_dispensing_fee"]


def build_event(person_filter=None):
    """person_filter: optional Column on person_id, used only to validate a slice (not business logic)."""
    e = reduce(lambda a, b: a.unionByName(b), [branch(*b) for b in BRANCHES])
    if person_filter is not None:
        e = e.filter(person_filter)

    # enriched_events: LEFT JOIN visit_occurrence ON id + person AND event_type NOT IN (VISIT, VISIT_DETAIL)
    vo = src("visit_occurrence").select(
        F.col("visit_occurrence_id").alias("vo_visit_occurrence_id"), F.col("person_id").alias("vo_person_id"),
        F.col("care_site_id").alias("vo_care_site_id"))
    e = e.join(vo, (F.col("vo_visit_occurrence_id") == F.col("visit_occurrence_id"))
               & (F.col("vo_person_id") == F.col("person_id"))
               & (~F.col("event_type").isin(VISIT_TYPES)), "left")
    e = e.withColumn("enriched_care_site_id",
                     F.when(F.col("event_type").isin(VISIT_TYPES), F.col("care_site_id"))
                      .otherwise(F.col("vo_care_site_id")).cast("bigint"))

    # clinical_output: concept look-ups (all intd_concept)
    for key, name in [("event_concept_id", "ec_name"), ("record_type_id", "rtc_name"), ("value_concept_id", "vcc_name"),
                      ("unit_concept_id", "uc_name"), ("condition_status_id", "csc_name"), ("route_concept_id", "rc_name"),
                      ("modifier_concept_id", "mc_name"), ("operator_concept_id", "oc_name"),
                      ("qualifier_concept_id", "qc_name"), ("anatomic_site_concept_id", "asc_name"),
                      ("disease_status_concept_id", "dsc_name"), ("admitted_from_concept_id", "afc_name"),
                      ("discharged_to_concept_id", "dtc_name"), ("meas_event_field_concept_id", "mefc_name"),
                      ("obs_event_field_concept_id", "oefc_name")]:
        e = lookup(e, key, name)

    # provider -> specialty
    pr = src("provider").select(F.col("provider_id").alias("pr_provider_id"), F.col("npi").alias("pr_npi"),
                                F.col("specialty_concept_id").alias("pr_specialty_concept_id"))
    e = e.join(pr, F.col("pr_provider_id") == F.col("provider_id"), "left")
    e = lookup(e, "pr_specialty_concept_id", "spc_name")

    # care_site (on the enriched care_site_id) -> place of service
    cs = src("care_site").select(F.col("care_site_id").alias("cs_care_site_id"),
                                 F.col("place_of_service_concept_id").alias("cs_pos_concept_id"))
    e = e.join(cs, F.col("cs_care_site_id") == F.col("enriched_care_site_id"), "left")
    e = lookup(e, "cs_pos_concept_id", "pos_name")

    # cost: ON cost_event_id = event_id AND UPPER(cost_domain_id) = event_type (no aggregation)
    cst = src("cost").select(*[F.col(c).alias(f"cst_{c}") for c in
                               ["cost_event_id", "cost_domain_id", "cost_id", "currency_concept_id", "cost_type_concept_id",
                                "revenue_code_concept_id", "drg_concept_id"] + COST_AMOUNTS])
    e = e.join(cst, (F.col("cst_cost_event_id") == F.col("event_id"))
               & (F.upper(F.col("cst_cost_domain_id")) == F.col("event_type")), "left")
    for key, name in [("cst_currency_concept_id", "ccur_name"), ("cst_cost_type_concept_id", "cctype_name"),
                      ("cst_revenue_code_concept_id", "crev_name"), ("cst_drg_concept_id", "cdrg_name")]:
        e = lookup(e, key, name)

    return project(e, [
        ("event_id", "bigint", "event_id"), ("person_id", "bigint", "person_id"), ("event_type", "string", "event_type"),
        ("event_start_date", "date", "event_start_date"), ("event_end_date", "date", "event_end_date"),
        ("event_concept_id", "int", "event_concept_id"), ("ec_name", "string", "event_concept_name"),
        ("event_source_value", "string", "event_source_value"), ("rtc_name", "string", "record_type"),
        ("provider_id", "bigint", "provider_id"), ("visit_occurrence_id", "bigint", "visit_occurrence_id"),
        ("visit_detail_id", "bigint", "visit_detail_id"), ("enriched_care_site_id", "bigint", "care_site_id"),
        ("preceding_visit_occurrence_id", "bigint", "preceding_visit_occurrence_id"), ("quantity", "float", "quantity"),
        ("stop_reason", "string", "stop_reason"), ("value_as_number", "float", "value_as_number"),
        ("value_as_string", "string", "value_as_string"), ("vcc_name", "string", "value_as_concept_name"),
        ("uc_name", "string", "unit_concept_name"), ("csc_name", "string", "condition_status_concept_name"),
        ("days_supply", "int", "days_supply"), ("refills", "int", "refills"), ("sig", "string", "sig"),
        ("rc_name", "string", "route_concept_name"), ("dose_unit_source_value", "string", "dose_unit_source_value"),
        ("mc_name", "string", "modifier_concept_name"), ("unique_device_id", "string", "unique_device_id"),
        ("oc_name", "string", "operator_concept_name"), ("range_low", "float", "range_low"),
        ("range_high", "float", "range_high"), ("qc_name", "string", "qualifier_concept_name"),
        ("asc_name", "string", "anatomic_site_concept_name"), ("dsc_name", "string", "disease_status_concept_name"),
        ("afc_name", "string", "admitted_from_concept_name"), ("dtc_name", "string", "discharged_to_concept_name"),
        ("measurement_event_id", "int", "measurement_event_id"), ("mefc_name", "string", "meas_event_field_concept_name"),
        ("observation_event_id", "int", "observation_event_id"), ("oefc_name", "string", "obs_event_field_concept_name"),
        ("verbatim_end_date", "date", "verbatim_end_date"), ("lot_number", "string", "lot_number"),
        ("production_id", "string", "production_id"),
    ] + [(f"cst_{c}", "float", c) for c in COST_AMOUNTS] + [
        ("ccur_name", "string", "currency_concept_name"), ("cctype_name", "string", "cost_type_concept_name"),
        ("crev_name", "string", "revenue_code_concept_name"), ("cdrg_name", "string", "drg_concept_name"),
        ("cst_cost_id", "bigint", "cost_id"), ("pr_npi", "string", "NPI"),
        ("spc_name", "string", "Speciality_concept_name"), ("pos_name", "string", "place_of_service_concept_name"),
    ])


event = build_event()

# COMMAND ----------

# DBTITLE 1,Compare the 4 tables with cdp_test
def schema_of(df):
    return [(f.name, f.dataType.simpleString()) for f in df.schema]


def compare(name, gen, ref, check):
    r = {"table": name, "check": check, "schema_equal": schema_of(gen) == schema_of(ref)}
    if not r["schema_equal"]:
        r["schema_diff"] = [(g, b) for g, b in zip(schema_of(gen), schema_of(ref)) if g != b] or "column count differs"
        r["exact_match"] = False
        return r
    r["generated_rows"], r["reference_rows"] = gen.count(), ref.count()
    r["generated_minus_reference"] = gen.exceptAll(ref).count()
    r["reference_minus_generated"] = ref.exceptAll(gen).count()
    r["exact_match"] = r["generated_minus_reference"] == 0 and r["reference_minus_generated"] == 0
    return r


RESULTS = []
if intd_concept is not None:
    RESULTS.append(compare("intd_concept", intd_concept, spark.table(f"{BASE}.intd_concept"), "full exceptAll"))
else:
    RESULTS.append({"table": "intd_concept", "check": INTD_STATUS, "exact_match": None})
for name, gen in [("patient", patient), ("payer_plan_period", payer_plan_period), ("patient_location", patient_location)]:
    RESULTS.append(compare(name, gen, spark.table(f"{BASE}.{name}"), "full exceptAll"))
for r in RESULTS:
    print(r)

# COMMAND ----------

# DBTITLE 1,Compare event with cdp_test
# exact check on a slice (person_id % 1000 = 7) + full row count per event_type
slice_filter = (F.col("person_id") % 1000) == 7
event_slice = build_event(slice_filter)
base_event = spark.table(f"{BASE}.event")
r = compare("event", event_slice, base_event.filter(slice_filter), "exceptAll on slice person_id % 1000 = 7")
RESULTS.append(r)
print(r)

if EVENT_FULL_COUNT:
    gen_counts = {x["event_type"]: x["count"] for x in event.groupBy("event_type").count().collect()}
    ref_counts = {x["event_type"]: x["count"] for x in base_event.groupBy("event_type").count().collect()}
    counts = [{"event_type": t, "generated": gen_counts.get(t), "reference": ref_counts.get(t),
               "match": gen_counts.get(t) == ref_counts.get(t)} for t in sorted(set(gen_counts) | set(ref_counts))]
    for c in counts:
        print(c)
    RESULTS.append({"table": "event", "check": "full row count per event_type",
                    "generated_rows": sum(gen_counts.values()), "reference_rows": sum(ref_counts.values()),
                    "exact_match": all(c["match"] for c in counts)})
    print(RESULTS[-1])

# COMMAND ----------

# DBTITLE 1,Summary
import json
print(json.dumps(RESULTS, default=str, indent=1))
dbutils.notebook.exit(json.dumps(RESULTS, default=str))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dvmt_rwpl.marketscan_commercial_cdm_2026q1_int.cdp_event_validation minus select * from dvmt_rwpl.cdp_test.event