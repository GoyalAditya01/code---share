"""
Module Name: Logger Utility

Overview:
    Lightweight wrapper around Python's standard logging library to standardize
    file and console logging across CDP pipeline scripts.
"""

import logging
import os
from datetime import datetime


class Logger:
    """
    Configure and expose a standardized logger for pipeline scripts.

    Responsibilities:
        * Create or reuse a named Python logger.
        * Configure consistent log formatting.
        * Optionally write logs to a file path (strftime pattern allowed).
        * Always emit logs to the console.
        * Avoid duplicate handlers in long-lived Spark environments.
    """

    def __init__(self, name, log_file_path=None):
        """Create or reuse the logger `name` (INFO level, console + optional file).

        Args:
            name: logger name (e.g. the pipeline step).
            log_file_path: optional file path; strftime patterns are filled with the current time.
        """
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)

        # Avoid duplicate handlers in Spark environment.
        if not self.logger.handlers:
            formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")

            if log_file_path:
                resolved_log_file_path = datetime.now().strftime(log_file_path)
                log_dir = os.path.dirname(resolved_log_file_path)
                if log_dir and not os.path.exists(log_dir):
                    os.makedirs(log_dir)
                file_handler = logging.FileHandler(resolved_log_file_path)
                file_handler.setFormatter(formatter)
                self.logger.addHandler(file_handler)

            stream_handler = logging.StreamHandler()
            stream_handler.setFormatter(formatter)
            self.logger.addHandler(stream_handler)

    def info(self, msg):
        """Log an informational message."""
        self.logger.info(msg)

    def error(self, msg):
        """Log an error message."""
        self.logger.error(msg)

    def warning(self, msg):
        """Log a warning message."""
        self.logger.warning(msg)

    def debug(self, msg):
        """Log a debug message."""
        self.logger.debug(msg)
