"""
Module Name: YAML Utility

Overview:
    Load YAML configuration files from the CDP configuration directory and
    read nested values by a key hierarchy.

    YamlUtility(env="dev", conf_file=ENV_PARAMS_YAML)  -> configuration/env/dev/env_params.yaml
    YamlUtility(conf_file=MAPPING_YAML)                -> configuration/global/mapping.yaml

    Unlike a print-and-continue loader, every problem (missing file, empty file,
    bad YAML, missing key) raises, so a job fails before reading or writing data.
"""

import os
from functools import reduce

import yaml

import common_constants as C


class YamlUtility:
    """Load one YAML configuration file and expose nested configuration access."""

    def __init__(self, env=None, conf_file=None, config_path=None):
        """
        Args:
            env: Environment name (dev / uat / prod) for env-specific config;
                 None for global config.
            conf_file: YAML file name, e.g. common_constants.MAPPING_YAML.
            config_path: Optional configuration folder (default: the project's).
        """
        if not conf_file:
            raise ValueError("A valid conf_file must be provided.")
        base_path = config_path or C.CONFIG_PATH
        if env:
            self.path = os.path.join(base_path, C.CONFIG_ENV_DIR, env, conf_file)
        else:
            self.path = os.path.join(base_path, C.CONFIG_GLOBAL_DIR, conf_file)

        if not os.path.exists(self.path):
            raise FileNotFoundError(f"Config file not found: {self.path}")
        with open(self.path) as stream:
            self.yaml_configuration = yaml.safe_load(stream)
        if self.yaml_configuration is None:
            raise ValueError(f"Config file is empty: {self.path}")

    def get_configuration(self, conf_hierarchy):
        """
        Return a value from a nested YAML hierarchy, e.g. ['marketscan', 'commercial'].

        Raises:
            KeyError: naming the first key that is missing.
        """
        def step(node, key):
            """Return node[key]; raise KeyError naming the missing key."""
            if not isinstance(node, dict) or key not in node:
                raise KeyError(f"'{key}' not found under {conf_hierarchy} in {self.path}")
            return node[key]
        return reduce(step, conf_hierarchy, self.yaml_configuration)
