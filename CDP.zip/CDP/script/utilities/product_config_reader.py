"""
Module Name: Product Config Reader

Overview:
    Read the business user's product config Excel ("CDP Config" sheet + "Admin" sheet)
    into a ProductConfig. Plain Python (openpyxl), no Spark, so the config QC job can reuse it.

    The sheet has three sections, each starting with a title row whose first non-empty
    cell is a marker:  [RUN_SETTINGS]  [EXPORT_COLUMNS]  [DERIVED_VARIABLES]
    The row after the marker (first non-empty one) is the section's header row. Columns are
    found by header NAME, sections by MARKER, so inserted / moved rows and columns do not
    break the reader. A section ends at the next marker (blank rows are skipped).

    Checks (all problems are collected and raised together as ProductConfigError):
      * every section and its required headers are present, no section twice
      * run settings present; dataset_name / refresh / run_mode in the Admin lists
      * run_mode Update needs previous_derived_table_name
      * Include is blank, or a value of the Admin YesNo list; at least one domain selected
      * no output attribute / parameter listed twice
    [DERIVED_VARIABLES] values are read as text, not validated yet (logic pending).
"""

import re
from dataclasses import dataclass
from datetime import date, datetime

import common_constants as C


class ProductConfigError(ValueError):
    """The product config Excel has one or more problems (listed in .errors)."""

    def __init__(self, path, errors):
        self.errors = list(errors)
        super().__init__(f"Product config '{path}' has {len(self.errors)} problem(s):\n  - "
                         + "\n  - ".join(self.errors))


@dataclass
class ProductConfig:
    """Parsed product config.

    domains:           [{attribute, output_attribute_name, include (bool), row}] in sheet order
    derived_variables: [{output_attribute_name, attribute, parameters: {parameter: value}}]
                       in sheet order (every listed variable, filled or not)
    """
    path: str
    dataset_name: str
    refresh: str
    run_mode: str                      # C.RUN_MODE_NEW | C.RUN_MODE_UPDATE
    previous_derived_table_name: str   # "" for run_mode New
    run_settings: dict
    domains: list
    derived_variables: list

    @property
    def selected_domains(self):
        """Output attribute names of the domains with Include = Y, in sheet order."""
        return [d[C.HDR_OUTPUT_ATTRIBUTE_NAME] for d in self.domains if d[C.HDR_INCLUDE]]

    @property
    def requested_derived_variables(self):
        """Derived variables with at least one parameter Value filled."""
        return [v for v in self.derived_variables if any(v["parameters"].values())]

    def describe(self):
        """Short dict for logs."""
        return {
            C.RUN_SETTING_DATASET_NAME: self.dataset_name,
            C.RUN_SETTING_REFRESH: self.refresh,
            C.RUN_SETTING_RUN_MODE: self.run_mode,
            C.RUN_SETTING_PREVIOUS_TABLE: self.previous_derived_table_name,
            "selected_domains": self.selected_domains,
            "requested_derived_variables": {v[C.HDR_OUTPUT_ATTRIBUTE_NAME]: v["parameters"]
                                            for v in self.requested_derived_variables},
        }


# ─────────────────────────────────────────────
# CELL / NAME NORMALISATION
# ─────────────────────────────────────────────

def cell_text(value):
    """Excel cell value -> stripped text (dates as YYYY-MM-DD, whole floats without .0)."""
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def normalize_header(text):
    """'Include (Y/N)' -> 'include', 'Output Attribute Name' -> 'output_attribute_name',
    'race_value(s)' -> 'race_value', 'study_period (optional)' -> 'study_period'."""
    text = re.sub(r"\(.*?\)", "", cell_text(text)).strip().lower()
    return re.sub(r"[^a-z0-9]+", "_", text).strip("_")


def normalize_name(text):
    """Domain / output attribute name: stripped, lower case."""
    return cell_text(text).lower()


def lov_match(value, allowed):
    """The entry of `allowed` equal to value (case-insensitive), else None."""
    wanted = value.strip().lower()
    return next((a for a in allowed if a.strip().lower() == wanted), None)


# ─────────────────────────────────────────────
# WORKBOOK / SECTIONS
# ─────────────────────────────────────────────

def load_sheets(path):
    """{sheet title: [row tuples of cell text]} in workbook order."""
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise ImportError("openpyxl is needed to read the product config Excel "
                          "(add it to the job environment or run %pip install openpyxl)") from exc
    # not read_only: read-only mode trusts the sheet's stored dimensions, which some tools write
    # wrongly (rows silently missed); the config file is small.
    workbook = load_workbook(path, data_only=True)
    try:
        return {ws.title: [tuple(cell_text(v) for v in row) for row in ws.iter_rows(values_only=True)]
                for ws in workbook.worksheets}
    finally:
        workbook.close()


def find_sheet(sheets, name):
    """Rows of the sheet called `name` (case-insensitive), else None."""
    return next((rows for title, rows in sheets.items() if title.strip().lower() == name.lower()), None)


def find_markers(rows):
    """[(SECTION, row index)] for every row whose first non-empty cell is a [SECTION] marker."""
    markers = []
    for i, row in enumerate(rows):
        first = next((v for v in row if v), "")
        match = re.match(C.SECTION_MARKER_PATTERN, first)
        if match:
            markers.append((match.group(1).upper(), i))
    return markers


def section_records(rows, name, start, end, errors):
    """Records (dict by normalised header, plus 'row' = Excel row number) of one section.

    start: marker row index; end: next marker row index (or len(rows))."""
    header_index = next((i for i in range(start + 1, end) if any(rows[i])), None)
    if header_index is None:
        errors.append(f"[{name}]: no header row under the section title (row {start + 1})")
        return []
    header = {}
    for col, value in enumerate(rows[header_index]):
        key = normalize_header(value)
        if key and key not in header:
            header[key] = col
    missing = [h for h in C.SECTION_HEADERS[name] if h not in header]
    if missing:
        errors.append(f"[{name}]: header row {header_index + 1} is missing column(s) {missing}; "
                      f"found {list(header)}")
        return []
    records = []
    for i in range(header_index + 1, end):
        row = rows[i]
        if not any(row):
            continue
        record = {key: (row[col] if col < len(row) else "") for key, col in header.items()}
        record["row"] = i + 1
        records.append(record)
    return records


def read_sections(rows, errors):
    """{SECTION: records} for the required sections."""
    markers = find_markers(rows)
    names = [name for name, _ in markers]
    for name in sorted({n for n in names if names.count(n) > 1}):
        errors.append(f"[{name}] appears {names.count(name)} times")
    sections = {}
    for k, (name, start) in enumerate(markers):
        if name not in C.SECTION_HEADERS or name in sections:
            continue
        end = markers[k + 1][1] if k + 1 < len(markers) else len(rows)
        sections[name] = section_records(rows, name, start, end, errors)
    for name in C.REQUIRED_SECTIONS:
        if name not in names:
            errors.append(f"Section marker [{name}] not found")
    return sections


def read_lovs(rows, errors):
    """{field: [allowed values]} from the Admin sheet (header row with every ADMIN_LOV_HEADERS name;
    values below each header until its first blank cell)."""
    wanted = C.ADMIN_LOV_HEADERS
    for i, row in enumerate(rows):
        columns = {normalize_header(v): c for c, v in enumerate(row) if v}
        if all(h in columns for h in wanted.values()):
            lovs = {}
            for field, header in wanted.items():
                col, values = columns[header], []
                for below in rows[i + 1:]:
                    value = below[col] if col < len(below) else ""
                    if not value:
                        break
                    values.append(value)
                lovs[field] = values
            return lovs
    errors.append(f"{C.ADMIN_SHEET_NAME} sheet: no header row with {sorted(wanted.values())}")
    return {}


# ─────────────────────────────────────────────
# SECTION PARSERS
# ─────────────────────────────────────────────

def parse_run_settings(records, lovs, errors):
    """{parameter: value} plus validated dataset_name / refresh / run_mode / previous table."""
    settings = {}
    for r in records:
        parameter = normalize_header(r[C.HDR_PARAMETER])
        if not parameter:
            continue
        if parameter in settings:
            errors.append(f"[{C.SECTION_RUN_SETTINGS}] '{parameter}' is listed twice (row {r['row']})")
        settings[parameter] = r[C.HDR_VALUE].strip()
    for key in C.RUN_SETTING_KEYS:
        if key not in settings:
            errors.append(f"[{C.SECTION_RUN_SETTINGS}] parameter row '{key}' not found")

    def checked(key):
        value = settings.get(key, "")
        if key not in settings:
            return ""
        if not value:
            errors.append(f"[{C.SECTION_RUN_SETTINGS}] {key} has no Value")
            return ""
        allowed = lovs.get(key)
        if allowed is None:
            return value
        match = lov_match(value, allowed)
        if match is None:
            errors.append(f"[{C.SECTION_RUN_SETTINGS}] {key} '{value}' is not in the "
                          f"{C.ADMIN_SHEET_NAME} list {allowed}")
            return ""
        return match

    dataset_name = checked(C.RUN_SETTING_DATASET_NAME)
    refresh = checked(C.RUN_SETTING_REFRESH)
    run_mode = checked(C.RUN_SETTING_RUN_MODE).lower()
    if run_mode and run_mode not in C.RUN_MODES:
        errors.append(f"[{C.SECTION_RUN_SETTINGS}] run_mode '{run_mode}' must be one of {list(C.RUN_MODES)}")
    previous = settings.get(C.RUN_SETTING_PREVIOUS_TABLE, "")
    if run_mode == C.RUN_MODE_UPDATE and not previous:
        errors.append(f"[{C.SECTION_RUN_SETTINGS}] run_mode Update needs "
                      f"{C.RUN_SETTING_PREVIOUS_TABLE} (the existing derived table to update)")
    if run_mode == C.RUN_MODE_NEW:
        previous = ""          # only used by Update
    return settings, dataset_name, refresh, run_mode, previous


def parse_export_columns(records, lovs, errors):
    """[{attribute, output_attribute_name, include, row}]; blank Include = N."""
    allowed = lovs.get(C.HDR_INCLUDE)
    domains, seen = [], set()
    for r in records:
        name = normalize_name(r[C.HDR_OUTPUT_ATTRIBUTE_NAME])
        raw = r[C.HDR_INCLUDE].strip()
        if not name:
            if raw:
                errors.append(f"[{C.SECTION_EXPORT_COLUMNS}] row {r['row']}: Include '{raw}' "
                              f"without an Output Attribute Name")
            continue
        if name in seen:
            errors.append(f"[{C.SECTION_EXPORT_COLUMNS}] '{name}' is listed twice (row {r['row']})")
            continue
        seen.add(name)
        include = False
        if raw:
            match = lov_match(raw, allowed) if allowed is not None else raw
            if match is None:
                errors.append(f"[{C.SECTION_EXPORT_COLUMNS}] row {r['row']} ({name}): Include '{raw}' "
                              f"is not in the {C.ADMIN_SHEET_NAME} list {allowed}")
            else:
                include = match.strip().lower() == C.INCLUDE_YES
        domains.append({C.HDR_ATTRIBUTE: r[C.HDR_ATTRIBUTE], C.HDR_OUTPUT_ATTRIBUTE_NAME: name,
                        C.HDR_INCLUDE: include, "row": r["row"]})
    if domains and not any(d[C.HDR_INCLUDE] for d in domains):
        errors.append(f"[{C.SECTION_EXPORT_COLUMNS}] no domain has Include = Y")
    return domains


def parse_derived_variables(records, errors):
    """[{output_attribute_name, attribute, parameters: {parameter: value}}] in sheet order."""
    variables = {}
    for r in records:
        name = normalize_name(r[C.HDR_OUTPUT_ATTRIBUTE_NAME])
        parameter = normalize_header(r[C.HDR_PARAMETER])
        if not name or not parameter:
            continue
        variable = variables.setdefault(name, {C.HDR_OUTPUT_ATTRIBUTE_NAME: name,
                                               C.HDR_ATTRIBUTE: r[C.HDR_ATTRIBUTE], "parameters": {}})
        if parameter in variable["parameters"]:
            errors.append(f"[{C.SECTION_DERIVED_VARIABLES}] {name}.{parameter} is listed twice "
                          f"(row {r['row']})")
            continue
        variable["parameters"][parameter] = r[C.HDR_VALUE].strip()
    return list(variables.values())


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

def read_product_config(path):
    """Read and validate the product config Excel. Raises ProductConfigError listing every problem."""
    sheets = load_sheets(path)
    errors = []
    config_rows = find_sheet(sheets, C.CONFIG_SHEET_NAME)
    if config_rows is None:                       # fall back to the first sheet
        config_rows = next(iter(sheets.values()), [])
    admin_rows = find_sheet(sheets, C.ADMIN_SHEET_NAME)
    if admin_rows is None:
        errors.append(f"Sheet '{C.ADMIN_SHEET_NAME}' not found (lists of values)")
        lovs = {}
    else:
        lovs = read_lovs(admin_rows, errors)

    sections = read_sections(config_rows, errors)
    settings, dataset_name, refresh, run_mode, previous = parse_run_settings(
        sections.get(C.SECTION_RUN_SETTINGS, []), lovs, errors)
    domains = parse_export_columns(sections.get(C.SECTION_EXPORT_COLUMNS, []), lovs, errors)
    derived = parse_derived_variables(sections.get(C.SECTION_DERIVED_VARIABLES, []), errors)

    if errors:
        raise ProductConfigError(path, errors)
    return ProductConfig(path=path, dataset_name=dataset_name, refresh=refresh, run_mode=run_mode,
                         previous_derived_table_name=previous, run_settings=settings,
                         domains=domains, derived_variables=derived)
