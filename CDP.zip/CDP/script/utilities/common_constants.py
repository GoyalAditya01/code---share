"""
Module Name : Common Constants
Purpose     : Central definition of all CDP pipeline-wide constants (no logic).

Environment-specific values live in configuration/env/<env>/env_params.yaml, schema
names (same in every environment) in configuration/global/schemas.yaml, column mappings
in configuration/global/mapping.yaml, and run choices come from job parameters (widgets).
"""

import os

# -- Workspace Paths ------------------------------------------
# common_constants.py lives at: <project_root>/script/utilities/
UTILITIES_PATH = os.path.dirname(os.path.abspath(__file__))
SCRIPT_PATH = os.path.dirname(UTILITIES_PATH)
CODE_PATH = os.path.join(SCRIPT_PATH, "code")
REPO_BASE_PATH = os.path.dirname(SCRIPT_PATH)
CONFIG_PATH = os.path.join(REPO_BASE_PATH, "configuration")
CONFIG_GLOBAL_DIR = "global"
CONFIG_ENV_DIR = "env"

# -- YAML Config File Names -----------------------------------
ENV_PARAMS_YAML = "env_params.yaml"
SCHEMAS_YAML = "schemas.yaml"
MAPPING_YAML = "mapping.yaml"
ATTRIBUTE_GROUPING_YAML = "attribute_grouping.yaml"
DERIVED_VARIABLE_YAML = "derived_variable.yaml"
TARGET_DATA_QC_YAML = "target_data_qc.yaml"

# -- Env Params Keys (env/<env>/env_params.yaml) ---------------
VAR_ENVIRONMENT = "environment"
VAR_STORAGE_ACCOUNT = "storage_account"

# -- Schema Keys (global/schemas.yaml) -------------------------
VAR_PREREQUISITE = "prerequisite"          # Athena vocabulary block
VAR_SOURCES = "sources"                    # sources -> <source> -> <dataset> -> schemas

# prerequisite block
VAR_PREREQ_DATA_CATALOG = "prerequisite_data_catalog"
VAR_PREREQ_DATA_DB = "prerequisite_data_db"
VAR_PREREQ_TABLE_LIST = "prerequisite_table_list"

# sources -> <source> -> <dataset> block
VAR_SRC_DATA_CATALOG = "source_data_catalog"
VAR_SRC_DATA_DB = "source_data_db"
VAR_QC_TABLE_CATALOG = "qc_data_catalog"
VAR_QC_OUTPUT_DB = "qc_data_db"
VAR_QC_OUTPUT_LOCATION = "qc_data_loc"
VAR_TARGET_DATA_CATALOG = "target_data_catalog"
VAR_TARGET_DATA_DB = "target_data_db"
VAR_TARGET_DATA_LOCATION = "target_data_loc"
VAR_INT_DATA_CATALOG = "intermediate_data_catalog"
VAR_INT_DATA_DB = "intermediate_data_db"
VAR_INT_DATA_LOCATION = "intermediate_data_loc"

# -- Mapping Keys (mapping.yaml) -------------------------------
VAR_MAPPING_TABLES = "tables"
VAR_TABLE_TYPE = "table_type"          # per table: intermediate | target (reserved key, not a column)
VAR_TABLE_NAME = "table_name"          # per table item: table name
VAR_TABLE_COLUMNS = "columns"          # per table item: list of columns
VAR_COLUMN_NAME = "column_name"        # per column item: column name
VAR_COLUMN_SOURCE_LIST = "source_list"  # per column item: list of source items
VAR_COLUMN_TRANSFORMATION = "transformation"  # per column item: the transformation
TABLE_TYPE_INTERMEDIATE = "intermediate"
TABLE_TYPE_TARGET = "target"

# -- Resolved schema keys (fully qualified catalog.db, used by helper) --
SOURCE_SCHEMA = "source_schema"
PREREQ_SCHEMA = "prerequisite_schema"
QC_SCHEMA = "qc_schema"
TARGET_SCHEMA = "target_schema"
QC_LOCATION = "qc_location"          # managed location (None when not configured)
TARGET_LOCATION = "target_location"
INT_SCHEMA = "intermediate_schema"
INT_LOCATION = "intermediate_location"

# table_type -> (schema key, location key) the table is written to and read back from
TABLE_TYPE_OUTPUT = {
    TABLE_TYPE_TARGET: (QC_SCHEMA, QC_LOCATION),
    TABLE_TYPE_INTERMEDIATE: (INT_SCHEMA, INT_LOCATION),
}

# -- Schema placeholders ---------------------------------------
SOURCE_TOKEN = "{source}"
DATASET_TOKEN = "{dataset}"
REFRESH_TOKEN = "{refresh}"
ATHENA_REFRESH_TOKEN = "{athena_refresh}"
STORAGE_ACCOUNT_TOKEN = "{storage_account}"

# -- Databricks widget (job parameter) names -------------------
WIDGET_ENV = "env"
WIDGET_SOURCE = "source"
WIDGET_DATASET = "dataset"
WIDGET_REFRESH = "refresh"
WIDGET_ATHENA_REFRESH = "athena_refresh"
WIDGET_CDP_TABLE_NAME = "cdp_table_name"   # a table, a comma list, or "all"

# The only job parameters of transformation_mapping. All are required: blank = error.
TRANSFORMATION_MAPPING_WIDGETS = (
    WIDGET_ENV,
    WIDGET_SOURCE,
    WIDGET_DATASET,
    WIDGET_REFRESH,
    WIDGET_ATHENA_REFRESH,
    WIDGET_CDP_TABLE_NAME,
)
ALL_TABLES = "all"            # cdp_table_name = all -> every table in mapping.yaml
LIST_SEPARATOR = ","

# Run id for the execution log, read from the notebook context (job run), else interactive_<time>
CONTEXT_ATTRIBUTES_KEY = "attributes"
CONTEXT_RUN_ID_KEYS = ("rootRunId", "currentRunId")
INTERACTIVE_RUN_ID = "interactive_%Y%m%d_%H%M%S"

# -- Pipeline / step names -------------------------------------
CDP_PIPELINE_NAME = "RWD CDP Pipeline"
TRANSFORMATION_MAPPING_STEP = "transformation_mapping"
DERIVED_VARIABLE_STEP = "derived_variable"
DQ_CHECK_STEP = "data_quality_check"
PROMOTE_TARGET_TABLES_STEP = "promote_target_tables"
EMAIL_NOTIFIER_STEP = "email_notifier"

# -- Logger Config ---------------------------------------------
LOGGER_LOC = os.path.join(
    REPO_BASE_PATH,
    "logs",
    "{pipeline}_{step}__%Y-%m-%d_%H-%M-%S.log",
)

# -- Execution Log Config --------------------------------------
VAR_LOG_TABLE_NAME = "execution_log"

# job task value key read by downstream tasks (dbutils.jobs.taskValues.get)
TASK_VALUE_SUMMARY = "cdp_summary"

# -- Spark / Table Save Config ---------------------------------
VAR_OUTPUT_FORMAT = "delta"
VAR_WRITE_MODE = "overwrite"
VAR_WRITE_OPTIONS = {"overwriteSchema": "true"}

# -- Build internals (temporary column prefixes, never in output) --
SOURCE_PREFIX = "base__"
TARGET_PREFIX = "tgt__"


# -- Execution status values -----------------------------------
class Status:
    """Execution-log status values."""
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    FAILED = "failed"
    SKIPPED = "skipped"
    WARNING = "warning"


class TableStatus:
    """Per-table outcome in the run summary."""
    DEPENDENCY_REUSED = "dependency_reused"
    WRITTEN = "written"


class SummaryKey:
    """Keys of one run-summary record."""
    TABLE = "table"
    STATUS = "status"
    TARGET = "target"
    ROWS = "rows"


class ResultKey:
    """Keys of the notebook exit value / task value."""
    STATUS = "status"
    PIPELINE = "pipeline"
    RUN_ID = "run_id"
    SUMMARY = "summary"


# -- mapping.yaml vocabulary -----------------------------------
STEP_DIRECT = "direct"
STEP_UNION = "union"
STEP_JOIN = "join"
STEP_CASE = "case"
STEPS = (STEP_DIRECT, STEP_UNION, STEP_JOIN, STEP_CASE)   # required order
UNION_TYPE_KEY = "union_type"
UNION_TYPE_ALL = "all"

SOURCE_KEYS = {"source_table", "source_column", "type", "transformation"}
JOIN_REQUIRED = {"join_type", "left_table", "left_column", "right_table", "right_column"}
JOIN_TYPES = {"left", "inner", "right", "full", "left_semi", "left_anti"}
JOIN_KEY_ID = "join_key_id"            # join key item: pairs a left_column item with the right_column item of the same id
KEY_ITEM_KEYS = {JOIN_KEY_ID, "column_name", "function"}
KEY_FUNCTION_NONE = "none"
EVALUATE_KEYS = {"source_table", "source_column"}   # case evaluate / column result

# case block keys
CASE_EVALUATE = "evaluate"
CASE_CONDITIONS = "conditions"
CASE_CONDITION = "condition"
CASE_RESULT = "result"
CASE_DEFAULT = "default"
CONSTANT_KEY = "constant"


# =============================================================================
# Derived variable step (script/code/derived_variable.py)
# =============================================================================

# -- Job parameters (all required) ----------------------------
WIDGET_CONFIG_FILE_PATH = "config_file_path"   # product config Excel (Volume / Workspace path)
DERIVED_VARIABLE_WIDGETS = (WIDGET_ENV, WIDGET_CONFIG_FILE_PATH)
# The derived step reads CDP tables only (no Athena vocabulary): fills {athena_refresh}
# for helper.resolve_schemas; the prerequisite schema is never used here.
ATHENA_REFRESH_NOT_USED = "not_used"

# -- Product config Excel ---------------------------------------
CONFIG_SHEET_NAME = "CDP Config"      # falls back to the first sheet when not found
ADMIN_SHEET_NAME = "Admin"            # lists of values (dropdowns)
SECTION_MARKER_PATTERN = r"^\[([A-Za-z_]+)\]"   # first non-empty cell of a section's title row
SECTION_RUN_SETTINGS = "RUN_SETTINGS"
SECTION_EXPORT_COLUMNS = "EXPORT_COLUMNS"
SECTION_DERIVED_VARIABLES = "DERIVED_VARIABLES"
REQUIRED_SECTIONS = (SECTION_RUN_SETTINGS, SECTION_EXPORT_COLUMNS, SECTION_DERIVED_VARIABLES)

# header names after normalisation (lower case, "(...)" removed, non-alphanumerics -> "_")
HDR_PARAMETER = "parameter"
HDR_VALUE = "value"
HDR_ATTRIBUTE = "attribute"
HDR_OUTPUT_ATTRIBUTE_NAME = "output_attribute_name"
HDR_INCLUDE = "include"               # "Include (Y/N)"
SECTION_HEADERS = {                   # headers each section must have (any order / position)
    SECTION_RUN_SETTINGS: (HDR_PARAMETER, HDR_VALUE),
    SECTION_EXPORT_COLUMNS: (HDR_ATTRIBUTE, HDR_OUTPUT_ATTRIBUTE_NAME, HDR_INCLUDE),
    SECTION_DERIVED_VARIABLES: (HDR_ATTRIBUTE, HDR_OUTPUT_ATTRIBUTE_NAME, HDR_PARAMETER, HDR_VALUE),
}

# [RUN_SETTINGS] parameters
RUN_SETTING_DATASET_NAME = "dataset_name"
RUN_SETTING_REFRESH = "refresh"
RUN_SETTING_RUN_MODE = "run_mode"
RUN_SETTING_PREVIOUS_TABLE = "previous_derived_table_name"
RUN_SETTING_KEYS = (RUN_SETTING_DATASET_NAME, RUN_SETTING_REFRESH, RUN_SETTING_RUN_MODE,
                    RUN_SETTING_PREVIOUS_TABLE)

# Admin sheet: list header (normalised) validating each field
ADMIN_LOV_HEADERS = {
    RUN_SETTING_DATASET_NAME: "datasets",
    RUN_SETTING_REFRESH: "refresh",
    RUN_SETTING_RUN_MODE: "runmode",
    HDR_INCLUDE: "yesno",
}
RUN_MODE_NEW = "new"
RUN_MODE_UPDATE = "update"
RUN_MODES = (RUN_MODE_NEW, RUN_MODE_UPDATE)
INCLUDE_YES = "y"                     # blank Include = N

# -- attribute_grouping.yaml keys --------------------------------
VAR_DOMAIN = "domain"
VAR_DOMAIN_LIST = "domain_list"
VAR_DOMAIN_NAME = "domain_name"
VAR_COLUMN_LIST = "column_list"
VAR_CDP_SOURCE = "cdp_source"         # CDP table a column is read from

# -- derived_variable.yaml keys -----------------------------------
VAR_DATASET_LOOKUP = "dataset_lookup"           # Excel dataset_name -> schemas.yaml source / dataset
VAR_LOOKUP_DATASET_NAME = "dataset_name"
VAR_LOOKUP_SOURCE = "source"
VAR_LOOKUP_DATASET = "dataset"

VAR_DERIVED_TABLE = "derived_table"
VAR_NAME_TEMPLATE = "name_template"             # {source} {dataset} {refresh} {timestamp}
VAR_TIMESTAMP_FORMAT = "timestamp_format"
VAR_READ_SCHEMA = "read_schema"                 # resolved schema key the static tables are read from
VAR_WRITE_SCHEMA = "write_schema"               # resolved schema key the derived table is written to
VAR_DOMAIN_COLUMN = "domain_column"             # output column naming each row's domain
VAR_LEAD_COLUMNS = "lead_columns"               # columns placed right after the domain column

VAR_EVENT_RULES = "event_rules"
VAR_FILTER_COLUMN = "filter_column"             # event column filtered per event domain
VAR_EVENT_KEY = "event_key"                     # dedupe key when cost is not selected
VAR_COST_DOMAIN = "cost_domain"                 # domain holding the cost columns
VAR_COST_KEY = "cost_key"                       # added to event_key when cost is selected
VAR_DOMAIN_EVENT_TYPE = "domain_event_type"     # event domain -> event_type value

VAR_DERIVED_VARIABLES = "derived_variables"     # calculated-field definitions (filled later)


class DerivedSummaryKey:
    """Keys of the derived_variable run summary (execution log output / task value)."""
    CONFIG_FILE = "config_file"
    DATASET_NAME = "dataset_name"
    RUN_MODE = "run_mode"
    TABLE = "derived_table"
    ROWS = "rows"
    DOMAINS = "domains"
    COST_SELECTED = "cost_selected"
    EVENT_KEY = "event_key"
    DERIVED_APPLIED = "derived_variables_applied"
    DERIVED_SKIPPED = "derived_variables_skipped"


# =============================================================================
# Data quality check step (script/code/data_quality_check notebook)
# =============================================================================

# Job parameters: the same six as transformation_mapping (all required);
# cdp_table_name selects target tables (`all` = every table_type target table).
DATA_QUALITY_CHECK_WIDGETS = TRANSFORMATION_MAPPING_WIDGETS
QC_TABLE_TYPE = TABLE_TYPE_TARGET           # only target tables are QC'd

# -- target_data_qc.yaml keys -------------------------------------
# static_table_qc -> list of checks {table_name, check_name, check_type, check_description,
# expected_result, target?, source_list?, items}. The shown table_name is the CDP table name in
# title case (patient_location -> Patient Location).
# One item = one reference QC query = one result row; {placeholders} in a check are
# filled from its item. Keys shared with mapping.yaml reuse the mapping.yaml constants
# (VAR_TABLE_NAME, VAR_COLUMN_NAME, VAR_COLUMN_SOURCE_LIST, the join block, CASE_CONDITION).
VAR_STATIC_TABLE_QC = "static_table_qc"
VAR_CHECK_NAME = "check_name"               # unique name of a check
VAR_CHECK_TYPE = "check_type"
VAR_CHECK_DESCRIPTION = "check_description"
VAR_EXPECTED_RESULT = "expected_result"
VAR_TARGET = "target"                       # the CDP side of a check
VAR_ITEMS = "items"
VAR_CHECK_ID = "check_id"                   # item: reference QC id (P01, E01, ...)
VAR_SOURCE_TABLE = "source_table"           # as in mapping.yaml source items
VAR_SOURCE_COLUMN = "source_column"
VAR_COUNT = "count"                         # what a count side counts (COUNT_MODES)
VAR_COLUMN_LIST = "column_list"             # duplicate_check key; absent = the full row
VAR_FILTER = "filter"                       # list of condition items (AND)
VAR_JOIN = "join"                           # list of mapping.yaml join steps (+ optional filter)
VAR_FAIL_WHEN = "fail_when"                 # consistency_check: list of {all_of: [conditions]}
VAR_ALL_OF = "conditions"
VAR_FUNCTION = "function"                   # helper.KEY_FUNCTIONS name, as on join key items
VAR_FILTER_CONDITION = "condition"          # helper.OPERATORS name
VAR_FILTER_VALUE = "value"
VAR_SOURCE_TABLE_NAME = "source_table_name"         # optional item override of the shown text
VAR_SOURCE_ATTRIBUTE_NAME = "source_attribute_name" # optional item override of the shown text
QC_CHECK_REQUIRED = (VAR_TABLE_NAME, VAR_CHECK_NAME, VAR_CHECK_TYPE, VAR_CHECK_DESCRIPTION,
                     VAR_EXPECTED_RESULT, VAR_ITEMS)   # internal (normalized) check
QC_CHECK_OPTIONAL = (VAR_TARGET, VAR_COLUMN_SOURCE_LIST)

# -- target_data_qc.yaml entry layout (one entry per check_id) -------------------
# {check_id, check_name, check_description, check_type, target {table_name, ...}, source?,
#  check_ids?, expected_result?, source_table_name?, source_attribute_name?}; normalized by
# the QC loader into the internal check above.
# The YAML names only CDP tables / columns / values. A count_reconciliation has no source: its
# target.column_name is followed through mapping.yaml (CDM table / column, union branches, child
# joins keyed on that column, branch-key filters) and target.function counts both sides.
VAR_SOURCE = "source"                       # referential_integrity_check only (a CDP table)
VAR_CHECK_IDS = "check_ids"                 # union target column: {event_type: check_id}
VAR_WHERE = "where"                         # value from_mapping: which branches count
WHERE_SOURCE_COLUMN_NOT_NULL = "source_column_not_null"
QC_ENTRY_REQUIRED = ("check_id", "check_name", "check_description", "check_type", "target")
QC_ENTRY_OPTIONAL = ("source", "check_ids", "expected_result", "source_table_name",
                     "source_attribute_name")
QC_MAPPING_REF_KEYS = (VAR_TABLE_NAME, VAR_COLUMN_NAME)               # required in a value from_mapping
QC_VALUE_REF_KEYS = (VAR_TABLE_NAME, VAR_COLUMN_NAME, VAR_WHERE, "exclude")  # value from_mapping
QC_BRANCH_ID_SEPARATOR = "_"                # new branch id: <check_id>_<event_type>

# -- from_mapping: CDM-side facts read from mapping.yaml at run time ------------
# A source item, a join or a condition value may say `from_mapping: <CDP column of the check's
# table>`; the QC reads that column's mapping.yaml entry instead of naming CDM tables/columns.
# A union column expands the check to one item per branch (keyed by QC_BRANCH_COLUMN); a
# branch with no item gets the check-level check_id template (e.g. E_{event_type}).
VAR_FROM_MAPPING = "from_mapping"
VAR_EXCLUDE = "exclude"                     # value from_mapping: branch values to leave out
QC_BRANCH_COLUMN = "event_type"             # union branch key: the constant per branch in mapping.yaml
PLACEHOLDER_APPLICABILITY = "applicability" # {applicability}: branch tables of a value from_mapping
QC_VALUE_FROM_MAPPING_KEYS = (VAR_FROM_MAPPING, VAR_EXCLUDE)
QC_CHECK_TEMPLATE_KEYS = (VAR_CHECK_ID,)    # check-level keys consumed by the from_mapping expansion
JOIN_TYPE = "join_type"                     # mapping.yaml join step keys
JOIN_LEFT_TABLE = "left_table"
JOIN_LEFT_COLUMN = "left_column"
JOIN_RIGHT_TABLE = "right_table"
JOIN_RIGHT_COLUMN = "right_column"
CONDITION_EQUALS = "equals"                 # helper.OPERATORS names used by the expansion
CONDITION_IN_LIST = "in_list"
QC_ITEM_OVERRIDES = (VAR_SOURCE_TABLE_NAME, VAR_SOURCE_ATTRIBUTE_NAME)
CONDITION_KEYS = (VAR_COLUMN_NAME, VAR_FUNCTION, VAR_FILTER_CONDITION, VAR_FILTER_VALUE)

# -- count modes (count key) --------------------------------------
COUNT_ROWS = "rows"                         # COUNT(*)
COUNT_DISTINCT = "distinct"                 # COUNT(DISTINCT column)
COUNT_NON_NULL = "non_null"                 # COUNT(column)
COUNT_MODES = (COUNT_ROWS, COUNT_DISTINCT, COUNT_NON_NULL)

# -- Check types --------------------------------------------------
CHECK_COUNT_RECONCILIATION = "count_reconciliation"
CHECK_DUPLICATE = "duplicate_check"
CHECK_NULL = "null_check"
CHECK_REFERENTIAL = "referential_integrity_check"
CHECK_CONSISTENCY = "consistency_check"
QC_CHECK_TYPES = (CHECK_COUNT_RECONCILIATION, CHECK_DUPLICATE, CHECK_NULL, CHECK_REFERENTIAL,
                  CHECK_CONSISTENCY)
# target keys allowed / required per check type
QC_TARGET_KEYS = {
    CHECK_COUNT_RECONCILIATION: (VAR_COUNT, VAR_COLUMN_NAME, VAR_FILTER),
    CHECK_DUPLICATE: (VAR_COLUMN_LIST,),
    CHECK_NULL: (VAR_COLUMN_NAME, VAR_FILTER),
    CHECK_CONSISTENCY: (VAR_FAIL_WHEN,),
    CHECK_REFERENTIAL: (VAR_COLUMN_NAME,),
}
QC_TARGET_REQUIRED = {
    CHECK_COUNT_RECONCILIATION: (VAR_COUNT,),
    CHECK_DUPLICATE: (),
    CHECK_NULL: (VAR_COLUMN_NAME,),
    CHECK_CONSISTENCY: (VAR_FAIL_WHEN,),
    CHECK_REFERENTIAL: (VAR_COLUMN_NAME,),
}
# source_list (exactly one item) allowed / required keys per check type; no entry = no source_list
QC_SOURCE_KEYS = {
    CHECK_COUNT_RECONCILIATION: (VAR_SOURCE_TABLE, VAR_SOURCE_COLUMN, VAR_COUNT, VAR_FILTER, VAR_JOIN),
    CHECK_REFERENTIAL: (VAR_SOURCE_TABLE, VAR_SOURCE_COLUMN),
}
QC_SOURCE_REQUIRED = {
    CHECK_COUNT_RECONCILIATION: (VAR_SOURCE_TABLE, VAR_COUNT),
    CHECK_REFERENTIAL: (VAR_SOURCE_TABLE, VAR_SOURCE_COLUMN),
}
VALUE_OPERATORS = ("equals", "in_list")     # conditions that need a value

# -- target_data_qc.yaml entry keys per check type (target: table_name + these) --------
QC_ENTRY_TARGET_KEYS = {
    CHECK_COUNT_RECONCILIATION: (VAR_COLUMN_NAME, VAR_FUNCTION, VAR_FILTER),
    CHECK_DUPLICATE: (VAR_COLUMN_NAME,),            # one column, a list, or a comma string; absent = full row
    CHECK_NULL: (VAR_COLUMN_NAME, VAR_FILTER),
    CHECK_CONSISTENCY: (VAR_FAIL_WHEN,),
    CHECK_REFERENTIAL: (VAR_COLUMN_NAME,),
}
QC_ENTRY_TARGET_REQUIRED = {
    CHECK_COUNT_RECONCILIATION: (VAR_COLUMN_NAME,), CHECK_DUPLICATE: (), CHECK_NULL: (VAR_COLUMN_NAME,),
    CHECK_CONSISTENCY: (VAR_FAIL_WHEN,), CHECK_REFERENTIAL: (VAR_COLUMN_NAME,),
}
QC_ENTRY_SOURCE_KEYS = {        # only referential checks have a source: a CDP table and column
    CHECK_REFERENTIAL: (VAR_TABLE_NAME, VAR_COLUMN_NAME),
}
QC_ENTRY_SOURCE_REQUIRED = {
    CHECK_REFERENTIAL: (VAR_TABLE_NAME, VAR_COLUMN_NAME),
}
# expected_result when an entry gives none ({column_name} = the target column(s))
QC_EXPECTED_DEFAULT = {
    CHECK_COUNT_RECONCILIATION: "Counts match",
    CHECK_DUPLICATE: "Zero duplicate rows",
    CHECK_NULL: "Zero NULL values in {column_name}",
    CHECK_CONSISTENCY: "Zero records violating the condition",
    CHECK_REFERENTIAL: "Zero unmatched {column_name} values",
}
QC_EXPECTED_DUPLICATE_KEY = "Zero duplicate {column_name} values"          # one key column
QC_EXPECTED_DUPLICATE_KEYS = "Zero duplicate {column_name} combinations"   # several key columns
QC_KEY_JOINER = " + "

# -- QC result table (QC schema; one row per check_id, appended every run) -----
QC_RESULT_TABLE = "cdp_qc_result"
QC_RESULT_WRITE_MODE = "append"            # every run adds its rows (run_id, run_datetime)
TASK_VALUE_QC_SUMMARY = "cdp_qc_summary"    # job task value key of the QC summary


class QcStatus:
    """check_status of one QC result row (as in the reference QC SQL)."""
    PASS = "PASS"
    FAIL = "FAIL"


class QcColumn:
    """Columns of the QC result table: run columns + the reference QC SQL output columns."""
    RUN_ID = "run_id"
    RUN_DATETIME = "run_datetime"
    CHECK_ID = "check_id"
    TABLE_NAME = "table_name"
    CHECK_DESCRIPTION = "check_description"
    SOURCE_TABLE_NAME = "source_table_name"
    SOURCE_ATTRIBUTE_NAME = "source_attribute_name"
    EXPECTED_RESULT = "expected_result"
    FAILED_RECORD_COUNT = "failed_record_count"
    CHECK_STATUS = "check_status"


# column order of the QC result table (the last 7 = the reference query output)
QC_RESULT_COLUMNS = (QcColumn.RUN_ID, QcColumn.RUN_DATETIME, QcColumn.CHECK_ID, QcColumn.TABLE_NAME,
                     QcColumn.CHECK_DESCRIPTION, QcColumn.SOURCE_TABLE_NAME,
                     QcColumn.SOURCE_ATTRIBUTE_NAME, QcColumn.EXPECTED_RESULT,
                     QcColumn.FAILED_RECORD_COUNT, QcColumn.CHECK_STATUS)
