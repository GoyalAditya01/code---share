# Databricks notebook source
# DBTITLE 1,CDP Data quality check
# MAGIC %md
# MAGIC # CDP – Data quality check
# MAGIC Runs the QC checks on the CDP target tables written by `transformation_mapping` (qc schema). Run as a job task after transformation, or interactively (widgets).
# MAGIC
# MAGIC All parameters are required (same as transformation_mapping).
# MAGIC
# MAGIC | Job parameter | Meaning | Example |
# MAGIC | --- | --- | --- |
# MAGIC | env | dev / uat / prod | dev |
# MAGIC | source | marketscan / optum | marketscan |
# MAGIC | dataset | commercial / medicare / ses / dod | commercial |
# MAGIC | refresh | data refresh | 26q1 |
# MAGIC | athena_refresh | Athena vocabulary refresh | 26q2 |
# MAGIC | cdp_table_name | a target table, a comma list, or `all` (= every target table in mapping.yaml) | event |
# MAGIC
# MAGIC **Checks**
# MAGIC * Declared in `configuration/global/target_data_qc.yaml` (`static_table_qc` -> one entry per check: `check_id`, `check_name`, `check_description`, `check_type`, `target`, `source`, optional `check_ids`, `expected_result`, `source_table_name`, `source_attribute_name`; the shown table_name is the CDP table name in title case). Check types: count_reconciliation, duplicate_check, null_check, consistency_check, referential_integrity_check.
# MAGIC * The YAML names only CDP tables, columns and values. A count_reconciliation has only a `target` (`table_name`, `column_name`, `function`, `filter`): the source side is read from `mapping.yaml` through `target.column_name` and counted with the same `function` (patient.person_id -> person.person_id; patient.death_flag -> death.person_id; event.event_id -> one check per branch table with the join keyed on event_id, i.e. cost; event.cost_id -> cost restricted to the mapping.yaml event types). Only referential checks have a `source`, and it is a CDP table.
# MAGIC * The reference QC queries (`qc_reference/CDP_QC_Checks_Static`) are the source of truth: each check is one reference query (`check_id` P01 ... PL06) and gives one result row, computed as that query computes it.
# MAGIC * Result rows have the reference output columns (table_name, check_description, source_table_name, source_attribute_name, expected_result, failed_record_count, check_status PASS/FAIL) plus run_id, run_datetime and check_id; every run's rows are appended to `cdp_qc_result` (QC schema).
# MAGIC
# MAGIC Every check is logged in `execution_log` (intermediate schema). All checks run; the task fails at the end if any check failed. The QC functions are in the "QC functions" cell of this notebook; they reuse `helper.py` (check_join, key_expr, OPERATORS, KEY_FUNCTIONS, resolve_schemas).

# COMMAND ----------

# DBTITLE 1,Setup and imports
"""
Module Name: Data Quality Check (entry point)

Overview:
    Runs the QC checks of one source / dataset / refresh on the CDP target tables in the qc
    schema and records every check in the execution log. Fails the task at the end when any
    check failed, so failed tables are not promoted.

Inputs (job parameters, all required): env, source, dataset, refresh, athena_refresh, cdp_table_name
Configuration files: env/<env>/env_params.yaml, global/schemas.yaml, global/mapping.yaml,
                     global/target_data_qc.yaml
"""
import importlib
import json
import os
import sys
import traceback
from datetime import datetime

# Project root from this notebook's path ("/script/" is the only literal needed before
# common_constants can be imported).
try:
    current_path = os.path.abspath(__file__)          # .py file
except NameError:                                     # Databricks notebook
    current_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
    if not current_path.startswith("/Workspace"):
        current_path = "/Workspace" + current_path

project_root = current_path.split("/script/")[0]
for path in (f"{project_root}/script/code", f"{project_root}/script/utilities"):
    if path not in sys.path:
        sys.path.insert(0, path)

import common_constants as C
import execution_logger
import helper
import logger_utility
import yaml_utility
for module in (C, yaml_utility, logger_utility, execution_logger, helper):
    importlib.reload(module)

from execution_logger import ExecutionLogger
from logger_utility import Logger
from yaml_utility import YamlUtility

# COMMAND ----------

# DBTITLE 1,Job parameters
# -----------------------------------------------------------------------------
# Job parameters (all required)
# -----------------------------------------------------------------------------
existing_widgets = dbutils.widgets.getAll()
for name in C.DATA_QUALITY_CHECK_WIDGETS:
    if name not in existing_widgets:
        dbutils.widgets.text(name, "", name)
params = {name: (dbutils.widgets.get(name) or "").strip() for name in C.DATA_QUALITY_CHECK_WIDGETS}

missing = [name for name in C.DATA_QUALITY_CHECK_WIDGETS if not params[name]]
if missing:
    raise ValueError(f"Missing required job parameter(s): {missing}")

ENV = params[C.WIDGET_ENV]
source = params[C.WIDGET_SOURCE]
dataset = params[C.WIDGET_DATASET]
refresh = params[C.WIDGET_REFRESH]
athena_refresh = params[C.WIDGET_ATHENA_REFRESH]
cdp_table_name = params[C.WIDGET_CDP_TABLE_NAME]

# Run id for the execution log: the job run id, or interactive_<time> outside a job
context = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().safeToJson())
attributes = context.get(C.CONTEXT_ATTRIBUTES_KEY, {})
run_id = (next((attributes[key] for key in C.CONTEXT_RUN_ID_KEYS if attributes.get(key)), None)
          or datetime.now().strftime(C.INTERACTIVE_RUN_ID))

data_pipeline_identifier = f"{source}_{dataset}_{refresh}"

# -----------------------------------------------------------------------------
# Logger setup
# -----------------------------------------------------------------------------
logger = Logger(
    C.DQ_CHECK_STEP,
    C.LOGGER_LOC.format(pipeline=data_pipeline_identifier, step=C.DQ_CHECK_STEP),
)
logger.info(f"Parameters: {params} | run_id={run_id}")

# COMMAND ----------

# DBTITLE 1,QC functions
"""
QC functions: the static-table checks of target_data_qc.yaml, computed as the reference QC queries.

target_data_qc.yaml: static_table_qc -> list of checks {table_name, check_name, check_type,
check_description, expected_result, target?, source_list?, items}. Each item is one reference
query (check_id) and gives one result row; {placeholders} are filled from the item.
The source item, join block and condition items have the mapping.yaml shape.

Each CDP table is read in one aggregation pass for all its count / NULL / consistency values;
duplicate and referential checks and every source-side count add one pass each. PySpark DataFrame
API only; reuses helper (check_join, key_expr, OPERATORS, KEY_FUNCTIONS, output_schema_key).
"""
import copy
import string
from functools import reduce

from pyspark.sql import functions as F

ROWS = "__rows"


# -----------------------------------------------------------------------------
# Tables
# -----------------------------------------------------------------------------
def qc_tables(all_tables, cdp_table_name):
    """Target tables to check: `all` = every table_type target table in mapping.yaml, else a comma list."""
    targets = [t for t, spec in all_tables.items() if spec[C.VAR_TABLE_TYPE] == C.QC_TABLE_TYPE]
    if cdp_table_name == C.ALL_TABLES:
        return targets
    requested = [t.strip() for t in cdp_table_name.split(C.LIST_SEPARATOR) if t.strip()]
    unknown = [t for t in requested if t not in targets]
    if unknown:
        raise ValueError(f"cdp_table_name {unknown} are not target tables. Available: {targets}")
    return requested


def cdp_table(table, all_tables, schemas):
    """Fully qualified CDP table in its output schema (target -> qc schema)."""
    return f"{schemas[helper.output_schema_key(table, all_tables[table])]}.{table}"


def cdm_table(table, schemas, routing):
    """Fully qualified CDM table: the Athena schema for prerequisite tables, else the source schema."""
    return f"{schemas[routing.get(table, C.SOURCE_SCHEMA)]}.{table}"


def source_location(table, check_type, all_tables, schemas, routing):
    """A source / join table: the CDP table for a referential_integrity_check source, else the CDM
    table (a count source is always CDM, even when a CDP table has the same name)."""
    if check_type == C.CHECK_REFERENTIAL:
        return cdp_table(table, all_tables, schemas)
    return cdm_table(table, schemas, routing)


# -----------------------------------------------------------------------------
# Placeholders
# -----------------------------------------------------------------------------
def placeholders(value):
    """Names of every {placeholder} in a string, list or dict (nested)."""
    if isinstance(value, str):
        return {name for _, name, _, _ in string.Formatter().parse(value) if name}
    if isinstance(value, list):
        return set().union(*[placeholders(v) for v in value]) if value else set()
    if isinstance(value, dict):
        return set().union(*[placeholders(v) for v in value.values()]) if value else set()
    return set()


def fill(value, values, where):
    """Copy of value with every {placeholder} replaced from values (raise when one has no value)."""
    if isinstance(value, str):
        missing = placeholders(value) - set(values)
        if missing:
            raise ValueError(f"{where}: no value for placeholder(s) {sorted(missing)} in {value!r}")
        return value.format(**values) if placeholders(value) else value
    if isinstance(value, list):
        return [fill(v, values, where) for v in value]
    if isinstance(value, dict):
        return {k: fill(v, values, where) for k, v in value.items()}
    return value


# -----------------------------------------------------------------------------
# Validation (before anything runs)
# -----------------------------------------------------------------------------
def check_keys(where, block, allowed, required, what):
    """Raise unless block is a mapping with every required key and only allowed keys."""
    if not isinstance(block, dict):
        raise ValueError(f"{where}: {what} must be a mapping, got {block!r}")
    missing, unknown = set(required) - set(block), set(block) - set(allowed)
    if missing or unknown:
        raise ValueError(f"{where}: {what} allows {sorted(allowed)} and requires {sorted(required)}; "
                         f"missing {sorted(missing)}, unknown {sorted(unknown)}")


def check_columns(where, names, columns, table):
    """Raise unless every name is a column (case-insensitive) of `table` (a set of lower-case names)."""
    missing = [n for n in names if n.lower() not in columns]
    if missing:
        raise ValueError(f"{where}: column(s) {missing} not in {table}; available: {sorted(columns)}")


def check_conditions(where, items, key):
    """Validate a list of condition items {column_name, function?, condition, value?}; returns their columns."""
    if not isinstance(items, list) or not items:
        raise ValueError(f"{where}: '{key}' must be a non-empty list of conditions")
    for f in items:
        check_keys(where, f, C.CONDITION_KEYS, (C.VAR_COLUMN_NAME, C.VAR_FILTER_CONDITION), f"'{key}' condition")
        condition, function = f[C.VAR_FILTER_CONDITION], f.get(C.VAR_FUNCTION, C.KEY_FUNCTION_NONE)
        if condition not in helper.OPERATORS:
            raise ValueError(f"{where}: condition '{condition}' not in {sorted(helper.OPERATORS)}")
        if function not in helper.KEY_FUNCTIONS:
            raise ValueError(f"{where}: function '{function}' not in {sorted(helper.KEY_FUNCTIONS)}")
        if (condition in C.VALUE_OPERATORS) != (C.VAR_FILTER_VALUE in f):
            raise ValueError(f"{where}: '{C.VAR_FILTER_VALUE}' is required for {C.VALUE_OPERATORS} only; got {f!r}")
        if condition == "in_list" and not isinstance(f[C.VAR_FILTER_VALUE], list):
            raise ValueError(f"{where}: in_list needs a list value; got {f!r}")
    return [f[C.VAR_COLUMN_NAME] for f in items]


def check_count(where, side, column_key, what):
    """Validate the count mode of one side; distinct / non_null need a column."""
    if side[C.VAR_COUNT] not in C.COUNT_MODES:
        raise ValueError(f"{where}: {what} count '{side[C.VAR_COUNT]}' not in {C.COUNT_MODES}")
    if (side[C.VAR_COUNT] != C.COUNT_ROWS) != (column_key in side):
        raise ValueError(f"{where}: {what} '{column_key}' is required for count "
                         f"{C.COUNT_DISTINCT} / {C.COUNT_NON_NULL} only")


def check_qc_join(where, steps, source_table):
    """Validate a source item's join: mapping.yaml join steps (helper.check_join) + an optional right-table
    filter. Returns [(join with paired keys, right filter or [])]."""
    if not isinstance(steps, list) or not steps:
        raise ValueError(f"{where}: '{C.VAR_JOIN}' must be a non-empty list of join steps")
    out = []
    for step in steps:
        if not isinstance(step, dict):
            raise ValueError(f"{where}: each join step must be a mapping, got {step!r}")
        right_filter = step.get(C.VAR_FILTER, [])
        join = helper.check_join({k: v for k, v in step.items() if k != C.VAR_FILTER}, where)
        if join["left_table"] != source_table:
            raise ValueError(f"{where}: join left_table '{join['left_table']}' must be the source_table "
                             f"'{source_table}'")
        if right_filter:
            check_conditions(where, right_filter, f"{C.VAR_JOIN}.{C.VAR_FILTER}")
        out.append((join, right_filter))
    return out


def target_columns(target):
    """Every CDP column a target block names (column, key list, filter and fail_when columns)."""
    names = [target[C.VAR_COLUMN_NAME]] if C.VAR_COLUMN_NAME in target else []
    names += target.get(C.VAR_COLUMN_LIST, [])
    names += [f[C.VAR_COLUMN_NAME] for f in target.get(C.VAR_FILTER, [])]
    names += [f[C.VAR_COLUMN_NAME] for g in target.get(C.VAR_FAIL_WHEN, []) for f in g[C.VAR_ALL_OF]]
    return names


def shown_text(check_type, target, source, item):
    """(source_table_name, source_attribute_name) of a result row: the item overrides, else derived."""
    table = (source[C.VAR_SOURCE_TABLE].upper()
             if source and check_type in (C.CHECK_COUNT_RECONCILIATION, C.CHECK_REFERENTIAL) else "")
    attribute = (target.get(C.VAR_COLUMN_NAME, "")
                 if check_type in (C.CHECK_NULL, C.CHECK_REFERENTIAL) else "")
    return (item.get(C.VAR_SOURCE_TABLE_NAME, table), item.get(C.VAR_SOURCE_ATTRIBUTE_NAME, attribute))


def resolve_item(table, display_name, check, item, all_tables, where):
    """One item of a check, with its placeholders filled and validated. Returns a resolved check:
    {check_id, table, table_name, check_type, check_description, expected_result, target, source,
    joins, source_table_name, source_attribute_name}."""
    check_type = check[C.VAR_CHECK_TYPE]
    if not isinstance(item, dict) or not item.get(C.VAR_CHECK_ID):
        raise ValueError(f"{where}: each item needs a '{C.VAR_CHECK_ID}'; got {item!r}")
    where = f"{where} {item[C.VAR_CHECK_ID]}"
    values = {k: v for k, v in item.items() if k != C.VAR_CHECK_ID}
    used = placeholders({k: check.get(k) for k in (C.VAR_CHECK_DESCRIPTION, C.VAR_EXPECTED_RESULT,
                                                   C.VAR_TARGET, C.VAR_COLUMN_SOURCE_LIST)})
    unused = set(values) - used - set(C.QC_ITEM_OVERRIDES)
    if unused:
        raise ValueError(f"{where}: item key(s) {sorted(unused)} are not used by any {{placeholder}}")

    target = fill(check.get(C.VAR_TARGET, {}), values, where)
    check_keys(where, target, C.QC_TARGET_KEYS[check_type], C.QC_TARGET_REQUIRED[check_type], C.VAR_TARGET)
    if C.VAR_COUNT in target:
        check_count(where, target, C.VAR_COLUMN_NAME, C.VAR_TARGET)
    if C.VAR_FILTER in target:
        check_conditions(where, target[C.VAR_FILTER], C.VAR_FILTER)
    if C.VAR_FAIL_WHEN in target:
        groups = target[C.VAR_FAIL_WHEN]
        if not isinstance(groups, list) or not groups:
            raise ValueError(f"{where}: '{C.VAR_FAIL_WHEN}' must be a non-empty list of {{{C.VAR_ALL_OF}: [...]}}")
        for g in groups:
            check_keys(where, g, (C.VAR_ALL_OF,), (C.VAR_ALL_OF,), f"'{C.VAR_FAIL_WHEN}' group")
            check_conditions(where, g[C.VAR_ALL_OF], C.VAR_ALL_OF)
    if C.VAR_COLUMN_LIST in target and (not isinstance(target[C.VAR_COLUMN_LIST], list)
                                        or not target[C.VAR_COLUMN_LIST]):
        raise ValueError(f"{where}: '{C.VAR_COLUMN_LIST}' must be a non-empty list of columns")
    cdp_columns = {c.lower() for c in helper.table_columns(table, all_tables[table])}
    check_columns(where, target_columns(target), cdp_columns, table)

    source, joins = None, []
    if check_type in C.QC_SOURCE_KEYS:
        items = fill(check.get(C.VAR_COLUMN_SOURCE_LIST), values, where)
        if not isinstance(items, list) or len(items) != 1:
            raise ValueError(f"{where}: '{C.VAR_COLUMN_SOURCE_LIST}' must have exactly one source item")
        source = items[0]
        check_keys(where, source, C.QC_SOURCE_KEYS[check_type], C.QC_SOURCE_REQUIRED[check_type], "source item")
        if C.VAR_COUNT in source:
            check_count(where, source, C.VAR_SOURCE_COLUMN, "source item")
        if C.VAR_FILTER in source:
            check_conditions(where, source[C.VAR_FILTER], C.VAR_FILTER)
        if C.VAR_JOIN in source:
            joins = check_qc_join(where, source[C.VAR_JOIN], source[C.VAR_SOURCE_TABLE])
        if check_type == C.CHECK_REFERENTIAL:
            ref = source[C.VAR_SOURCE_TABLE]
            if ref not in all_tables:
                raise ValueError(f"{where}: referential source_table '{ref}' must be a CDP table in mapping.yaml")
            check_columns(where, [source[C.VAR_SOURCE_COLUMN]],
                          {c.lower() for c in helper.table_columns(ref, all_tables[ref])}, ref)
    elif C.VAR_COLUMN_SOURCE_LIST in check:
        raise ValueError(f"{where}: {check_type} takes no '{C.VAR_COLUMN_SOURCE_LIST}'")

    source_table_name, source_attribute_name = shown_text(check_type, target, source, item)
    shown = {**values, C.VAR_SOURCE_TABLE_NAME: source_table_name,
             C.VAR_SOURCE_ATTRIBUTE_NAME: source_attribute_name}
    return {C.VAR_CHECK_ID: item[C.VAR_CHECK_ID], C.VAR_CHECK_NAME: check[C.VAR_CHECK_NAME],
            "table": table, C.QcColumn.TABLE_NAME: display_name,
            C.VAR_CHECK_TYPE: check_type,
            C.VAR_CHECK_DESCRIPTION: fill(check[C.VAR_CHECK_DESCRIPTION], shown, where),
            C.VAR_EXPECTED_RESULT: fill(check[C.VAR_EXPECTED_RESULT], shown, where),
            C.VAR_TARGET: target, "source": source, "joins": joins,
            C.VAR_SOURCE_TABLE_NAME: source_table_name, C.VAR_SOURCE_ATTRIBUTE_NAME: source_attribute_name}


# -----------------------------------------------------------------------------
# from_mapping: CDM-side facts read from mapping.yaml at run time
# -----------------------------------------------------------------------------
def mapping_column(all_tables, table, column, where):
    """mapping.yaml entry of a CDP column (name matched case-insensitively).

    Returns:
        (source items, transformation dict); the transformation is {} for a direct column.
    """
    columns = helper.table_columns(table, all_tables[table])
    name = {c.lower(): c for c in columns}.get(str(column).lower())
    if name is None:
        raise ValueError(f"{where}: from_mapping column '{column}' is not in mapping.yaml table {table}")
    spec = columns[name]
    items = [s for s in spec if C.VAR_SOURCE_TABLE in s]
    rest = [s[C.VAR_COLUMN_TRANSFORMATION] for s in spec if C.VAR_SOURCE_TABLE not in s]
    transformation = rest[0] if rest and isinstance(rest[0], dict) else {}
    return items, transformation


def branch_values(all_tables, table, where):
    """{source_table: branch value}: the constant of each branch of the QC_BRANCH_COLUMN union."""
    items, transformation = mapping_column(all_tables, table, C.QC_BRANCH_COLUMN, where)
    if C.STEP_UNION not in transformation:
        raise ValueError(f"{where}: '{C.QC_BRANCH_COLUMN}' of {table} is not a union in mapping.yaml")
    values = {}
    for item in items:
        constant = item.get(C.VAR_COLUMN_TRANSFORMATION)
        if not isinstance(constant, dict) or C.CONSTANT_KEY not in constant:
            raise ValueError(f"{where}: branch {item[C.VAR_SOURCE_TABLE]} of '{C.QC_BRANCH_COLUMN}' has no constant")
        values[item[C.VAR_SOURCE_TABLE]] = constant[C.CONSTANT_KEY]
    return values


def mapping_branches(all_tables, table, column, where):
    """Union branches of a CDP column, in mapping.yaml order, paired with their branch value by source_table.

    Returns:
        [(branch value, source_table, source_column or None, maps a value)]; a branch maps a value
        when it has a source_column or a constant.
    """
    items, transformation = mapping_column(all_tables, table, column, where)
    if C.STEP_UNION not in transformation:
        raise ValueError(f"{where}: '{column}' of {table} is not a union column in mapping.yaml")
    values = branch_values(all_tables, table, where)
    branches = []
    for item in items:
        source_table = item[C.VAR_SOURCE_TABLE]
        if source_table not in values:
            raise ValueError(f"{where}: branch {source_table} of '{column}' has no '{C.QC_BRANCH_COLUMN}' branch")
        constant = item.get(C.VAR_COLUMN_TRANSFORMATION)
        maps = bool(item.get(C.VAR_SOURCE_COLUMN)) or (isinstance(constant, dict) and C.CONSTANT_KEY in constant)
        branches.append((values[source_table], source_table, item.get(C.VAR_SOURCE_COLUMN), maps))
    return branches


def mapping_source(all_tables, table, column, where):
    """The single CDM source (source_table, source_column) of a non-union CDP column.

    A case column gives its evaluate column (death_flag -> death.person_id).
    """
    items, transformation = mapping_column(all_tables, table, column, where)
    if C.STEP_UNION in transformation:
        raise ValueError(f"{where}: '{column}' is a union column; it expands per branch")
    evaluate = (transformation.get(C.STEP_CASE) or {}).get(C.CASE_EVALUATE)
    if evaluate:
        return evaluate[C.VAR_SOURCE_TABLE], evaluate[C.VAR_SOURCE_COLUMN]
    sources = list(dict.fromkeys((s[C.VAR_SOURCE_TABLE], s.get(C.VAR_SOURCE_COLUMN)) for s in items))
    if len(sources) != 1:
        raise ValueError(f"{where}: '{column}' has {len(sources)} sources in mapping.yaml; from_mapping needs one")
    return sources[0]


def branch_column(all_tables, table, column, source_table, where):
    """Source column that one union branch (source_table) maps to a CDP column."""
    for _, branch_table, source_column, _ in mapping_branches(all_tables, table, column, where):
        if branch_table == source_table and source_column:
            return source_column
    raise ValueError(f"{where}: branch {source_table} does not map '{column}' in mapping.yaml")


def mapping_join(all_tables, table, column, source_table, value, where):
    """mapping.yaml join of a CDP column, as QC join steps for one source table.

    A step whose left_table is the CDP table itself is re-based onto the branch: each left key
    becomes the column the branch maps to it, and a key on QC_BRANCH_COLUMN (a constant per
    branch) becomes an equals filter on its right key. Other steps are used as they are.
    """
    _, transformation = mapping_column(all_tables, table, column, where)
    steps = transformation.get(C.STEP_JOIN)
    if not steps:
        raise ValueError(f"{where}: '{column}' has no join in mapping.yaml")
    out = []
    for step in steps:
        if step[C.JOIN_LEFT_TABLE] != table:
            out.append(copy.deepcopy(step))
            continue
        if source_table is None or value is None:
            raise ValueError(f"{where}: the join of '{column}' starts from {table}; it needs a union branch")
        rights = {k[C.JOIN_KEY_ID]: k for k in step[C.JOIN_RIGHT_COLUMN]}
        left, right, conditions = [], [], []
        for key in step[C.JOIN_LEFT_COLUMN]:
            right_key = rights[key[C.JOIN_KEY_ID]]
            if key[C.VAR_COLUMN_NAME].lower() == C.QC_BRANCH_COLUMN:
                conditions.append({C.VAR_COLUMN_NAME: right_key[C.VAR_COLUMN_NAME],
                                   C.VAR_FUNCTION: right_key[C.VAR_FUNCTION],
                                   C.VAR_FILTER_CONDITION: C.CONDITION_EQUALS, C.VAR_FILTER_VALUE: value})
                continue
            name = branch_column(all_tables, table, key[C.VAR_COLUMN_NAME], source_table, where)
            left.append({**key, C.VAR_COLUMN_NAME: name})
            right.append(copy.deepcopy(right_key))
        rebased = {C.JOIN_TYPE: step[C.JOIN_TYPE], C.JOIN_LEFT_TABLE: source_table, C.JOIN_LEFT_COLUMN: left,
                   C.JOIN_RIGHT_TABLE: step[C.JOIN_RIGHT_TABLE], C.JOIN_RIGHT_COLUMN: right}
        if conditions:
            rebased[C.VAR_FILTER] = conditions
        out.append(rebased)
    return out


def applicability_text(tables):
    """Shown list of branch tables: 'A, B and C' in title case."""
    names = [display_name(t) for t in tables]
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


def resolve_conditions(conditions, all_tables, table, where, log):
    """Condition items with `value: {from_mapping: column, exclude?}` resolved to an in_list.

    The list holds the branch values of that union column whose branch maps a value, minus exclude.

    Returns:
        (conditions, [branch tables of every resolved list]).
    """
    out, tables = [], []
    for cond in conditions or []:
        spec = cond.get(C.VAR_FILTER_VALUE) if isinstance(cond, dict) else None
        if not (isinstance(spec, dict) and C.VAR_FROM_MAPPING in spec):
            out.append(cond)
            continue
        check_keys(where, spec, C.QC_VALUE_FROM_MAPPING_KEYS, (C.VAR_FROM_MAPPING,), "value from_mapping")
        exclude = spec.get(C.VAR_EXCLUDE) or []
        branches = mapping_branches(all_tables, table, spec[C.VAR_FROM_MAPPING], where)
        for value in sorted(set(exclude) - {b[0] for b in branches}):
            log(f"WARNING {where}: excluded {C.QC_BRANCH_COLUMN} {value} is not a mapping.yaml branch")
        keep = [b for b in branches if b[3] and b[0] not in exclude]
        if not keep:
            raise ValueError(f"{where}: from_mapping '{spec[C.VAR_FROM_MAPPING]}' leaves no {C.QC_BRANCH_COLUMN}")
        out.append({**cond, C.VAR_FILTER_CONDITION: C.CONDITION_IN_LIST, C.VAR_FILTER_VALUE: [b[0] for b in keep]})
        tables.append([b[1] for b in keep])
    return out, tables


def concrete_source(src, all_tables, table, source_table, source_column, value, where):
    """A from_mapping source item with its CDM table/column (and from_mapping join) filled in.

    The source column is kept only when the count needs it (distinct / non_null).
    """
    item = {C.VAR_SOURCE_TABLE: source_table}
    if src.get(C.VAR_COUNT) != C.COUNT_ROWS:
        item[C.VAR_SOURCE_COLUMN] = source_column
    item.update({k: copy.deepcopy(v) for k, v in src.items() if k not in (C.VAR_FROM_MAPPING, C.VAR_JOIN)})
    join = src.get(C.VAR_JOIN)
    if isinstance(join, dict) and C.VAR_FROM_MAPPING in join:
        check_keys(where, join, (C.VAR_FROM_MAPPING,), (C.VAR_FROM_MAPPING,), "join from_mapping")
        item[C.VAR_JOIN] = mapping_join(all_tables, table, join[C.VAR_FROM_MAPPING], source_table, value, where)
    elif join is not None:
        item[C.VAR_JOIN] = copy.deepcopy(join)
    return item


def expand_check(check, all_tables, where, log=print):
    """Resolve every from_mapping of a check against mapping.yaml.

    A source item on a union column expands to one item per branch: YAML items are matched on
    QC_BRANCH_COLUMN (removed branches are skipped with a warning) and a new branch gets an item
    from the check-level check_id template (with a warning).

    Returns:
        [(concrete check, item)] in YAML item order, then new branches in mapping.yaml order.
    """
    table = check[C.VAR_TABLE_NAME]
    base = {k: copy.deepcopy(v) for k, v in check.items() if k not in C.QC_CHECK_TEMPLATE_KEYS}
    applicable = []
    target = base.get(C.VAR_TARGET) or {}
    if target.get(C.VAR_FILTER):
        target[C.VAR_FILTER], found = resolve_conditions(target[C.VAR_FILTER], all_tables, table, where, log)
        applicable += found
    sources = base.get(C.VAR_COLUMN_SOURCE_LIST) or []
    src = sources[0] if len(sources) == 1 and isinstance(sources[0], dict) else None
    if src and src.get(C.VAR_FILTER):
        src[C.VAR_FILTER], found = resolve_conditions(src[C.VAR_FILTER], all_tables, table, where, log)
        applicable += found

    def with_source(source_table, source_column, value):
        """Copy of the check with its from_mapping source item made concrete."""
        concrete = copy.deepcopy(base)
        concrete[C.VAR_COLUMN_SOURCE_LIST] = [concrete_source(src, all_tables, table, source_table,
                                                              source_column, value, where)]
        return concrete

    items = list(check[C.VAR_ITEMS])
    if not src or C.VAR_FROM_MAPPING not in src:
        if src and isinstance(src.get(C.VAR_JOIN), dict):
            base = with_source(src.get(C.VAR_SOURCE_TABLE), src.get(C.VAR_SOURCE_COLUMN), None)
        pairs = [(base, item) for item in items]
    elif C.STEP_UNION not in mapping_column(all_tables, table, src[C.VAR_FROM_MAPPING], where)[1]:
        concrete = with_source(*mapping_source(all_tables, table, src[C.VAR_FROM_MAPPING], where), None)
        pairs = [(concrete, item) for item in items]
    else:
        branches = {b[0]: b for b in mapping_branches(all_tables, table, src[C.VAR_FROM_MAPPING], where) if b[3]}
        pairs, used = [], set()
        for item in items:
            value = item.get(C.QC_BRANCH_COLUMN)
            if value is None:
                raise ValueError(f"{where}: item {item.get(C.VAR_CHECK_ID)} needs '{C.QC_BRANCH_COLUMN}' (its branch)")
            if value not in branches:
                log(f"WARNING {where}: {item.get(C.VAR_CHECK_ID)} skipped, {C.QC_BRANCH_COLUMN} {value} "
                    f"is not a mapping.yaml branch")
                continue
            used.add(value)
            pairs.append((with_source(branches[value][1], branches[value][2], value), item))
        for value, (_, source_table, source_column, _) in branches.items():
            if value in used:
                continue
            template = check.get(C.VAR_CHECK_ID)
            if not template:
                raise ValueError(f"{where}: mapping.yaml branch {value} ({source_table}) has no item and the "
                                 f"check has no '{C.VAR_CHECK_ID}' template")
            item = {C.VAR_CHECK_ID: template.replace("{" + C.QC_BRANCH_COLUMN + "}", str(value)),
                    C.QC_BRANCH_COLUMN: value}
            log(f"WARNING {where}: new mapping.yaml branch {value} ({source_table}) checked as {item[C.VAR_CHECK_ID]}")
            pairs.append((with_source(source_table, source_column, value), item))

    if C.PLACEHOLDER_APPLICABILITY in placeholders([check[C.VAR_CHECK_DESCRIPTION], check[C.VAR_EXPECTED_RESULT]]):
        if len(applicable) != 1:
            raise ValueError(f"{where}: {{{C.PLACEHOLDER_APPLICABILITY}}} needs exactly one value from_mapping")
        text = applicability_text(applicable[0])
        pairs = [(c, {**item, C.PLACEHOLDER_APPLICABILITY: text}) for c, item in pairs]
    return pairs


# -----------------------------------------------------------------------------
# Entry layout: one target_data_qc.yaml entry per check_id -> internal check
# -----------------------------------------------------------------------------
def as_list(value):
    """A single block or a list of blocks, as a list (None -> [])."""
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def count_mode(side, where, what):
    """Count mode of a count side: function absent = rows, else distinct / non_null."""
    function = side.get(C.VAR_FUNCTION)
    if function is None:
        return C.COUNT_ROWS
    if function not in (C.COUNT_DISTINCT, C.COUNT_NON_NULL):
        raise ValueError(f"{where}: {what} function '{function}' not in {[C.COUNT_DISTINCT, C.COUNT_NON_NULL]}")
    return function


def mapping_ref(ref, allowed, table, where, what):
    """CDP column named by a from_mapping block {table_name, column_name, ...} of the check's table."""
    if not isinstance(ref, dict):
        raise ValueError(f"{where}: {what} must be a block with {list(C.QC_MAPPING_REF_KEYS)}")
    check_keys(where, ref, allowed, C.QC_MAPPING_REF_KEYS, what)
    if ref[C.VAR_TABLE_NAME] != table:
        raise ValueError(f"{where}: {what} table_name '{ref[C.VAR_TABLE_NAME]}' must be the target table '{table}'")
    return ref[C.VAR_COLUMN_NAME]


def normalize_conditions(conditions, table, where):
    """One condition or a list of conditions as a list; a `value: {from_mapping: {...}}` becomes the
    internal {from_mapping: column, exclude?} that resolve_conditions expands."""
    out = []
    for cond in as_list(conditions):
        value = cond.get(C.VAR_FILTER_VALUE) if isinstance(cond, dict) else None
        if isinstance(value, dict) and C.VAR_FROM_MAPPING in value:
            check_keys(where, value, (C.VAR_FROM_MAPPING,), (C.VAR_FROM_MAPPING,), "value")
            ref = value[C.VAR_FROM_MAPPING]
            column = mapping_ref(ref, C.QC_VALUE_REF_KEYS, table, where, "value from_mapping")
            if ref.get(C.VAR_WHERE, C.WHERE_SOURCE_COLUMN_NOT_NULL) != C.WHERE_SOURCE_COLUMN_NOT_NULL:
                raise ValueError(f"{where}: from_mapping where must be '{C.WHERE_SOURCE_COLUMN_NOT_NULL}'")
            spec = {C.VAR_FROM_MAPPING: column}
            if ref.get(C.VAR_EXCLUDE):
                spec[C.VAR_EXCLUDE] = list(ref[C.VAR_EXCLUDE])
            cond = {**cond, C.VAR_FILTER_VALUE: spec}
        out.append(cond)
    return out


def child_join_column(all_tables, table, column, where):
    """A CDP column whose mapping.yaml join attaches child rows to each row of a union column.

    A join from the CDP table whose left keys include the union column itself (event.event_id)
    adds rows per branch row (event -> cost); lookup joins keyed on other columns (provider_id,
    care_site_id, concept ids) do not. Returns None when there is no such join.
    """
    found = {}
    for name in helper.table_columns(table, all_tables[table]):
        for step in mapping_column(all_tables, table, name, where)[1].get(C.STEP_JOIN) or []:
            keys = {str(k[C.VAR_COLUMN_NAME]).lower() for k in step[C.JOIN_LEFT_COLUMN]}
            if step[C.JOIN_LEFT_TABLE] == table and column.lower() in keys:
                found.setdefault(step[C.JOIN_RIGHT_TABLE], name)
    if len(found) > 1:
        raise ValueError(f"{where}: {table}.{column} has child joins to {sorted(found)}; expected at most one")
    return next(iter(found.values()), None)


def branch_key_filter(all_tables, table, column, where):
    """Source filter of a join column: its join's right key on QC_BRANCH_COLUMN in the branch values.

    For event.cost_id (joined on event_type -> UPPER(cost_domain_id)) the source is restricted to
    cost rows whose domain is a mapping.yaml event type.
    """
    out = []
    for step in mapping_column(all_tables, table, column, where)[1].get(C.STEP_JOIN) or []:
        if step[C.JOIN_LEFT_TABLE] != table:
            continue
        rights = {k[C.JOIN_KEY_ID]: k for k in step[C.JOIN_RIGHT_COLUMN]}
        for key in step[C.JOIN_LEFT_COLUMN]:
            if str(key[C.VAR_COLUMN_NAME]).lower() == C.QC_BRANCH_COLUMN:
                right = rights[key[C.JOIN_KEY_ID]]
                out.append({C.VAR_COLUMN_NAME: right[C.VAR_COLUMN_NAME], C.VAR_FUNCTION: right[C.VAR_FUNCTION],
                            C.VAR_FILTER_CONDITION: C.CONDITION_IN_LIST,
                            C.VAR_FILTER_VALUE: {C.VAR_FROM_MAPPING: C.QC_BRANCH_COLUMN}})
    return out


def default_expected(check_type, columns):
    """Generated expected_result of a check type ({column_name} = the target column(s))."""
    if check_type == C.CHECK_DUPLICATE and columns:
        text = C.QC_EXPECTED_DUPLICATE_KEY if len(columns) == 1 else C.QC_EXPECTED_DUPLICATE_KEYS
    else:
        text = C.QC_EXPECTED_DEFAULT[check_type]
    return text.replace("{" + C.VAR_COLUMN_NAME + "}", C.QC_KEY_JOINER.join(columns))


def normalize_entry(entry, all_tables, n):
    """One target_data_qc.yaml entry (one check_id) as an internal check for expand_check / resolve_item.

    Entry: {check_id, check_name, check_description, check_type, target {table_name, ...}, source?,
    check_ids?, expected_result?, source_table_name?, source_attribute_name?}. The entry names only
    CDP tables / columns / values. A count_reconciliation has no source: target.column_name is
    followed through mapping.yaml (its CDM table / column; a case column gives its evaluate
    column) and target.function counts both sides. A union column runs once per branch as rows
    (check_ids: event_type -> check_id), with the child join keyed on that column; a join column
    is restricted to the branch values of its join's event_type key. A referential source is a
    CDP table {table_name, column_name}.
    """
    where = f"target_data_qc.yaml entry {n}"
    if not isinstance(entry, dict):
        raise ValueError(f"{where}: each entry must be a block; got {entry!r}")
    check_keys(where, entry, C.QC_ENTRY_REQUIRED + C.QC_ENTRY_OPTIONAL, C.QC_ENTRY_REQUIRED, "check")
    check_id, check_type = str(entry[C.VAR_CHECK_ID]), entry[C.VAR_CHECK_TYPE]
    where = f"target_data_qc.yaml {check_id}"
    if check_type not in C.QC_CHECK_TYPES:
        raise ValueError(f"{where}: check_type '{check_type}' not in {C.QC_CHECK_TYPES}")
    target = entry[C.VAR_TARGET]
    if not isinstance(target, dict):
        raise ValueError(f"{where}: '{C.VAR_TARGET}' must be a block")
    check_keys(where, target, (C.VAR_TABLE_NAME,) + C.QC_ENTRY_TARGET_KEYS[check_type],
               (C.VAR_TABLE_NAME,) + C.QC_ENTRY_TARGET_REQUIRED[check_type], C.VAR_TARGET)
    table = target[C.VAR_TABLE_NAME]
    if table not in all_tables or all_tables[table][C.VAR_TABLE_TYPE] != C.QC_TABLE_TYPE:
        raise ValueError(f"{where}: target table_name '{table}' is not a {C.QC_TABLE_TYPE} table in mapping.yaml")
    source = entry.get(C.VAR_SOURCE)
    if source is not None and not isinstance(source, dict):
        raise ValueError(f"{where}: '{C.VAR_SOURCE}' must be a block")
    union = (check_type == C.CHECK_COUNT_RECONCILIATION and bool(target.get(C.VAR_COLUMN_NAME))
             and C.STEP_UNION in mapping_column(all_tables, table, target[C.VAR_COLUMN_NAME], where)[1])
    if C.VAR_CHECK_IDS in entry and not union:
        raise ValueError(f"{where}: '{C.VAR_CHECK_IDS}' is only for a target column with union branches")

    column = target.get(C.VAR_COLUMN_NAME)
    tgt = {}
    if check_type == C.CHECK_COUNT_RECONCILIATION:
        tgt[C.VAR_COUNT] = count_mode(target, where, C.VAR_TARGET)
        conditions = normalize_conditions(target.get(C.VAR_FILTER), table, where)
        if union:
            if tgt[C.VAR_COUNT] != C.COUNT_ROWS:
                raise ValueError(f"{where}: a union column is counted per branch as rows (no function)")
            conditions = [{C.VAR_COLUMN_NAME: C.QC_BRANCH_COLUMN, C.VAR_FILTER_CONDITION: C.CONDITION_EQUALS,
                           C.VAR_FILTER_VALUE: "{" + C.QC_BRANCH_COLUMN + "}"}] + conditions
        elif tgt[C.VAR_COUNT] != C.COUNT_ROWS:
            tgt[C.VAR_COLUMN_NAME] = column
        if conditions:
            tgt[C.VAR_FILTER] = conditions
    elif check_type == C.CHECK_DUPLICATE:
        if column:
            tgt[C.VAR_COLUMN_LIST] = ([c.strip() for c in column.split(C.LIST_SEPARATOR) if c.strip()]
                                      if isinstance(column, str) else list(column))
    elif check_type == C.CHECK_NULL:
        tgt[C.VAR_COLUMN_NAME] = column
        conditions = normalize_conditions(target.get(C.VAR_FILTER), table, where)
        if conditions:
            tgt[C.VAR_FILTER] = conditions
    elif check_type == C.CHECK_CONSISTENCY:
        tgt[C.VAR_FAIL_WHEN] = target[C.VAR_FAIL_WHEN]
    else:
        tgt[C.VAR_COLUMN_NAME] = column

    source_list = None
    if check_type == C.CHECK_COUNT_RECONCILIATION:
        if source is not None:
            raise ValueError(f"{where}: count_reconciliation takes no '{C.VAR_SOURCE}'; it comes from mapping.yaml "
                             f"through target.column_name")
        item = {C.VAR_FROM_MAPPING: column, C.VAR_COUNT: tgt[C.VAR_COUNT]}
        if union:
            child = child_join_column(all_tables, table, column, where)
            if child:
                item[C.VAR_JOIN] = {C.VAR_FROM_MAPPING: child}
        else:
            conditions = branch_key_filter(all_tables, table, column, where)
            if conditions:
                item[C.VAR_FILTER] = conditions
        source_list = [item]
    elif check_type in C.QC_ENTRY_SOURCE_KEYS:
        if source is None:
            raise ValueError(f"{where}: {check_type} needs a '{C.VAR_SOURCE}'")
        check_keys(where, source, C.QC_ENTRY_SOURCE_KEYS[check_type], C.QC_ENTRY_SOURCE_REQUIRED[check_type],
                   C.VAR_SOURCE)
        source_list = [{C.VAR_SOURCE_TABLE: source[C.VAR_TABLE_NAME], C.VAR_SOURCE_COLUMN: source[C.VAR_COLUMN_NAME]}]
    elif source is not None:
        raise ValueError(f"{where}: {check_type} takes no '{C.VAR_SOURCE}'")

    columns = tgt.get(C.VAR_COLUMN_LIST) or ([tgt[C.VAR_COLUMN_NAME]] if tgt.get(C.VAR_COLUMN_NAME) else [])
    check = {C.VAR_TABLE_NAME: table, C.VAR_CHECK_NAME: entry[C.VAR_CHECK_NAME], C.VAR_CHECK_TYPE: check_type,
             C.VAR_CHECK_DESCRIPTION: entry[C.VAR_CHECK_DESCRIPTION],
             C.VAR_EXPECTED_RESULT: entry.get(C.VAR_EXPECTED_RESULT) or default_expected(check_type, columns),
             C.VAR_TARGET: tgt}
    if source_list:
        check[C.VAR_COLUMN_SOURCE_LIST] = source_list
    overrides = {k: entry[k] for k in C.QC_ITEM_OVERRIDES if k in entry}
    if union:
        check[C.VAR_CHECK_ID] = check_id + C.QC_BRANCH_ID_SEPARATOR + "{" + C.QC_BRANCH_COLUMN + "}"
        ids = entry.get(C.VAR_CHECK_IDS) or {}
        if not isinstance(ids, dict):
            raise ValueError(f"{where}: '{C.VAR_CHECK_IDS}' must map {C.QC_BRANCH_COLUMN} -> check_id")
        check[C.VAR_ITEMS] = [{C.VAR_CHECK_ID: str(i), C.QC_BRANCH_COLUMN: v, **overrides} for v, i in ids.items()]
    else:
        check[C.VAR_ITEMS] = [{C.VAR_CHECK_ID: check_id, **overrides}]
    return check


def display_name(table):
    """Shown table_name of a CDP table: its name in title case (patient_location -> Patient Location)."""
    return table.replace("_", " ").title()


def load_checks(raw, all_tables, log=print):
    """Validate target_data_qc.yaml `static_table_qc` (a list of checks) and expand every item.

    Args:
        raw: the static_table_qc list of entries (one per check_id).
        all_tables: mapping.yaml tables (helper.mapping_tables); from_mapping is resolved against it.
        log: where expansion warnings go (new / removed mapping.yaml branches).

    Returns:
        {CDP table: [resolved check, ...]}: one resolved check per item; tables and checks in YAML order.
    """
    if not isinstance(raw, list) or not raw:
        raise ValueError(f"target_data_qc.yaml: '{C.VAR_STATIC_TABLE_QC}' must be a non-empty list of checks")
    out, ids, names = {}, set(), set()
    for n, entry in enumerate(raw, start=1):
        check = normalize_entry(entry, all_tables, n)
        table, name = check[C.VAR_TABLE_NAME], check[C.VAR_CHECK_NAME]
        at = f"target_data_qc.yaml {entry[C.VAR_CHECK_ID]}"
        if name in names:
            raise ValueError(f"{at}: check_name '{name}' used twice")
        names.add(name)
        for concrete, item in expand_check(check, all_tables, at, log):
            resolved = resolve_item(table, display_name(table), concrete, item, all_tables, at)
            if resolved[C.VAR_CHECK_ID] in ids:
                raise ValueError(f"{at}: check_id {resolved[C.VAR_CHECK_ID]} used twice")
            ids.add(resolved[C.VAR_CHECK_ID])
            out.setdefault(table, []).append(resolved)
    return out


def source_tables(chk):
    """Every (table, [columns]) a resolved check reads besides its CDP table (source + join tables)."""
    src = chk["source"]
    if not src:
        return []
    columns = [src[C.VAR_SOURCE_COLUMN]] if C.VAR_SOURCE_COLUMN in src else []
    columns += [f[C.VAR_COLUMN_NAME] for f in src.get(C.VAR_FILTER, [])]
    out = []
    for join, right_filter in chk["joins"]:
        columns += [k if isinstance(k, str) else k["column"] for k in join["left_column"]]
        out.append((join["right_table"], [k if isinstance(k, str) else k["column"] for k in join["right_column"]]
                    + [f[C.VAR_COLUMN_NAME] for f in right_filter]))
    return [(src[C.VAR_SOURCE_TABLE], columns)] + out


def validate_references(spark, tables, all_tables, checks_by_table, schemas, routing):
    """Raise before any check runs when a CDP table, or a source / join table or column, is missing."""
    for table in tables:
        full = cdp_table(table, all_tables, schemas)
        if not spark.catalog.tableExists(full):
            raise ValueError(f"CDP table {full} does not exist; run transformation_mapping first")
        for chk in checks_by_table.get(table, []):
            for name, columns in source_tables(chk):
                full = source_location(name, chk[C.VAR_CHECK_TYPE], all_tables, schemas, routing)
                if not spark.catalog.tableExists(full):
                    raise ValueError(f"{chk[C.VAR_CHECK_ID]}: table {full} does not exist")
                check_columns(chk[C.VAR_CHECK_ID], columns, {c.lower() for c in spark.table(full).columns}, full)


# -----------------------------------------------------------------------------
# PySpark expressions
# -----------------------------------------------------------------------------
def condition_expr(f, colfn=F.col):
    """Boolean Column of one condition item (function applied to the column first)."""
    column = helper.KEY_FUNCTIONS[f.get(C.VAR_FUNCTION, C.KEY_FUNCTION_NONE)](colfn(f[C.VAR_COLUMN_NAME]))
    return helper.OPERATORS[f[C.VAR_FILTER_CONDITION]](column, f.get(C.VAR_FILTER_VALUE))


def all_expr(items, colfn=F.col):
    """AND of condition items (TRUE when there are none)."""
    return reduce(lambda a, b: a & b, [condition_expr(f, colfn) for f in items or []], F.lit(True))


def fail_expr(groups):
    """OR of fail_when groups (each an AND of its all_of conditions)."""
    return reduce(lambda a, b: a | b, [all_expr(g[C.VAR_ALL_OF]) for g in groups])


def count_expr(count, column, where, alias):
    """Aggregate of one count side on the rows where `where` holds: COUNT(*) | COUNT(DISTINCT c) | COUNT(c)."""
    if count == C.COUNT_ROWS:
        return F.count(F.when(where, F.lit(1))).alias(alias)
    if count == C.COUNT_DISTINCT:
        return F.countDistinct(F.when(where, F.col(column))).alias(alias)
    return F.count(F.when(where, F.col(column))).alias(alias)


def target_expr(chk):
    """Aggregate giving the CDP-side value of a count / null / consistency check, or None."""
    t, alias = chk[C.VAR_TARGET], chk[C.VAR_CHECK_ID]
    if chk[C.VAR_CHECK_TYPE] == C.CHECK_COUNT_RECONCILIATION:
        return count_expr(t[C.VAR_COUNT], t.get(C.VAR_COLUMN_NAME), all_expr(t.get(C.VAR_FILTER)), alias)
    if chk[C.VAR_CHECK_TYPE] == C.CHECK_NULL:
        rows = all_expr(t.get(C.VAR_FILTER)) & F.col(t[C.VAR_COLUMN_NAME]).isNull()
        return count_expr(C.COUNT_ROWS, None, rows, alias)
    if chk[C.VAR_CHECK_TYPE] == C.CHECK_CONSISTENCY:
        return count_expr(C.COUNT_ROWS, None, fail_expr(t[C.VAR_FAIL_WHEN]), alias)
    return None


# -----------------------------------------------------------------------------
# Counts that need their own pass
# -----------------------------------------------------------------------------
def duplicate_count(df, columns=None):
    """Extra rows: SUM(count - 1) over repeated keys, or COUNT(*) - COUNT(DISTINCT *) for full rows.

    Full rows are grouped on a 64-bit hash of every column first; only rows whose hash repeats are
    grouped on the real values, so the count is exact without shuffling every column of every row."""
    if columns:
        repeated = df.groupBy(*columns).agg(F.count(F.lit(1)).alias(ROWS)).where(F.col(ROWS) > 1)
    else:
        hashed = df.withColumn("__h", F.xxhash64(*[F.col(f"`{c}`") for c in df.columns]))
        candidates = (hashed.groupBy("__h").agg(F.count(F.lit(1)).alias(ROWS))
                      .where(F.col(ROWS) > 1).select("__h"))
        repeated = (hashed.join(candidates, on="__h", how="left_semi").drop("__h")
                    .groupBy(*[F.col(f"`{c}`") for c in df.columns])
                    .agg(F.count(F.lit(1)).alias(ROWS)).where(F.col(ROWS) > 1))
    return int(repeated.agg(F.sum(F.col(ROWS) - 1)).first()[0] or 0)


def orphan_count(df, column, source_df, source_column):
    """DISTINCT df.column values not in source_df.source_column (LEFT ANTI JOIN; a NULL never matches)."""
    left = df.select(F.col(column).alias("__k")).distinct()
    right = source_df.select(F.col(source_column).alias("__r")).distinct()
    return left.join(right, on=F.col("__k") == F.col("__r"), how="left_anti").count()


def source_count(spark, chk, all_tables, schemas, routing):
    """Source-side value of a count check: the source table (filtered), LEFT JOINed as configured,
    counted by its count mode."""
    src = chk["source"]
    df = spark.table(source_location(src[C.VAR_SOURCE_TABLE], chk[C.VAR_CHECK_TYPE], all_tables, schemas, routing))
    if C.VAR_FILTER in src:
        df = df.where(all_expr(src[C.VAR_FILTER]))
    for n, (join, right_filter) in enumerate(chk["joins"], start=1):
        alias = f"j{n}"
        right = spark.table(source_location(join["right_table"], chk[C.VAR_CHECK_TYPE], all_tables, schemas,
                                            routing))
        if right_filter:
            right = right.where(all_expr(right_filter))
        right = right.select([F.col(f"`{c}`").alias(f"{alias}__{c}") for c in right.columns])
        cond = reduce(lambda a, b: a & b, [
            helper.key_expr(lk, F.col, chk[C.VAR_CHECK_ID])
            == helper.key_expr(rk, lambda c, a=alias: F.col(f"`{a}__{c}`"), chk[C.VAR_CHECK_ID])
            for lk, rk in zip(join["left_column"], join["right_column"])])
        df = df.join(right, on=cond, how=join["join_type"])
    return df.agg(count_expr(src[C.VAR_COUNT], src.get(C.VAR_SOURCE_COLUMN), F.lit(True), ROWS)).first()[0]


# -----------------------------------------------------------------------------
# Results
# -----------------------------------------------------------------------------
def result(chk, failed, cdp_value=None, source_value=None):
    """One result row (reference query layout + check_id), plus check_type and the compared values."""
    return {C.QcColumn.CHECK_ID: chk[C.VAR_CHECK_ID], C.QcColumn.TABLE_NAME: chk[C.QcColumn.TABLE_NAME],
            C.QcColumn.CHECK_DESCRIPTION: chk[C.VAR_CHECK_DESCRIPTION],
            C.QcColumn.SOURCE_TABLE_NAME: chk[C.VAR_SOURCE_TABLE_NAME],
            C.QcColumn.SOURCE_ATTRIBUTE_NAME: chk[C.VAR_SOURCE_ATTRIBUTE_NAME],
            C.QcColumn.EXPECTED_RESULT: chk[C.VAR_EXPECTED_RESULT],
            C.QcColumn.FAILED_RECORD_COUNT: int(failed),
            C.QcColumn.CHECK_STATUS: C.QcStatus.PASS if failed == 0 else C.QcStatus.FAIL,
            C.VAR_CHECK_NAME: chk[C.VAR_CHECK_NAME], C.VAR_CHECK_TYPE: chk[C.VAR_CHECK_TYPE],
            "cdp_value": cdp_value, "source_value": source_value}


def run_table(spark, table, checks, all_tables, schemas, routing, log=print):
    """Run every resolved check of one CDP table; returns its result rows in check order.

    One aggregation pass over the CDP table gives every count / null / consistency value; duplicate,
    referential and source-side counts run on their own.
    """
    df = spark.table(cdp_table(table, all_tables, schemas))
    exprs = [e for e in (target_expr(c) for c in checks) if e is not None]
    values = df.agg(*exprs).first().asDict() if exprs else {}
    log(f"[{table}] one pass: {len(exprs)} values")
    rows = []
    for chk in checks:
        check_type, cid = chk[C.VAR_CHECK_TYPE], chk[C.VAR_CHECK_ID]
        if check_type == C.CHECK_COUNT_RECONCILIATION:
            src = source_count(spark, chk, all_tables, schemas, routing)
            rows.append(result(chk, abs(src - values[cid]), values[cid], src))
        elif check_type in (C.CHECK_NULL, C.CHECK_CONSISTENCY):
            rows.append(result(chk, values[cid], values[cid]))
        elif check_type == C.CHECK_DUPLICATE:
            rows.append(result(chk, duplicate_count(df, chk[C.VAR_TARGET].get(C.VAR_COLUMN_LIST))))
        elif check_type == C.CHECK_REFERENTIAL:
            src = chk["source"]
            source_df = spark.table(source_location(src[C.VAR_SOURCE_TABLE], check_type, all_tables, schemas,
                                                    routing))
            rows.append(result(chk, orphan_count(df, chk[C.VAR_TARGET][C.VAR_COLUMN_NAME], source_df,
                                                 src[C.VAR_SOURCE_COLUMN])))
        r = rows[-1]
        log(f"[{table}] {cid} {r[C.QcColumn.CHECK_STATUS]} failed_record_count={r[C.QcColumn.FAILED_RECORD_COUNT]}")
    return rows


# COMMAND ----------

# DBTITLE 1,Load configuration and checks
# -----------------------------------------------------------------------------
# Configuration: schemas, mapping.yaml tables, target_data_qc.yaml static_table_qc checks
# (validated and expanded to one check per item here, before anything runs)
# -----------------------------------------------------------------------------
try:
    env_params = YamlUtility(env=ENV, conf_file=C.ENV_PARAMS_YAML)
    schema_config = YamlUtility(conf_file=C.SCHEMAS_YAML).yaml_configuration
    all_tables = helper.mapping_tables(
        YamlUtility(conf_file=C.MAPPING_YAML).get_configuration([C.VAR_MAPPING_TABLES]))
    checks_by_table = load_checks(
        YamlUtility(conf_file=C.TARGET_DATA_QC_YAML).get_configuration([C.VAR_STATIC_TABLE_QC]), all_tables, logger.info)
    schemas = helper.resolve_schemas(schema_config, source, dataset, refresh, athena_refresh,
                                     env_params.get_configuration([C.VAR_STORAGE_ACCOUNT]))
    routing = helper.prerequisite_routing(schema_config)
    tables = qc_tables(all_tables, cdp_table_name)
    validate_references(spark, tables, all_tables, checks_by_table, schemas, routing)
except Exception:
    logger.error(f"Failed to load the QC configuration: {traceback.format_exc()}")
    raise

for key, schema in schemas.items():
    logger.info(f"{key:<20}= {schema}")
logger.info(f"Tables to check: {tables} | checks: "
            f"{ {t: [c[C.VAR_CHECK_ID] for c in checks_by_table.get(t, [])] for t in tables} }")

# COMMAND ----------

# DBTITLE 1,Run checks (entry point)
# -----------------------------------------------------------------------------
# Entry point: every table is checked (a failing table does not stop the others);
# one execution-log row per check: step data_quality_check_<table>_<check_id>. All result
# rows (one per reference query) are unioned and appended to the QC result table.
# -----------------------------------------------------------------------------
int_schema = schemas[C.INT_SCHEMA]
helper.create_schema_if_not_exists(spark, int_schema, schemas[C.INT_LOCATION], logger.info)
execution_log = ExecutionLogger(database=int_schema, table=C.VAR_LOG_TABLE_NAME, spark=spark)
execution_log.terminate_current_execution(run_id)


def log_step(step_name, records, error=None):
    """Write one execution-log row for a group of QC results (failed if any failed or error)."""
    status = (C.Status.FAILED if error or any(r[C.QcColumn.CHECK_STATUS] == C.QcStatus.FAIL for r in records)
              else C.Status.COMPLETE)
    log_id = execution_log.create_new_log(run_id=run_id, pipeline_name=data_pipeline_identifier,
                                          step_name=step_name, status=C.Status.IN_PROGRESS)
    execution_log.update_log(id=log_id, status=status, output=json.dumps(records, default=str), error=error)


run_datetime = datetime.now()
results, errors = [], {}
for table in tables:
    step = f"{C.DQ_CHECK_STEP}_{table}"
    try:
        records = run_table(spark, table, checks_by_table.get(table, []), all_tables,
                            schemas, routing, logger.info)
    except Exception:
        errors[table] = traceback.format_exc()
        logger.error(f"[{table}] QC failed to run: {errors[table]}")
        log_step(step, [], error=errors[table])
        continue
    results.extend(records)
    for record in records:
        log_step(f"{step}_{record[C.QcColumn.CHECK_ID]}", [record])
execution_log.terminate_current_execution(run_id)

# Union of every result row, in the reference query layout (plus run_id, run_datetime, check_id)
result_types = {C.QcColumn.RUN_DATETIME: "timestamp", C.QcColumn.FAILED_RECORD_COUNT: "bigint"}
result_schema = ", ".join(f"{c} {result_types.get(c, 'string')}" for c in C.QC_RESULT_COLUMNS)
rows = [{**r, C.QcColumn.RUN_ID: str(run_id), C.QcColumn.RUN_DATETIME: run_datetime} for r in results]
results_df = spark.createDataFrame([tuple(r[c] for c in C.QC_RESULT_COLUMNS) for r in rows], result_schema)
result_table = f"{schemas[C.QC_SCHEMA]}.{C.QC_RESULT_TABLE}"
(results_df.write.format(C.VAR_OUTPUT_FORMAT).mode(C.QC_RESULT_WRITE_MODE)
    .saveAsTable(result_table))
logger.info(f"{len(rows)} result rows appended to {result_table}")
display(results_df)

# COMMAND ----------

# DBTITLE 1,Publish result
# Result: task value for downstream job tasks (dbutils.jobs.taskValues.get), then fail the task
# when any check failed (or a table could not be checked), else exit with the summary.
failed_checks = [r[C.QcColumn.CHECK_ID] for r in results if r[C.QcColumn.CHECK_STATUS] == C.QcStatus.FAIL]
summary = {t: {s: sum(1 for c in checks_by_table.get(t, []) for r in results
                   if r[C.QcColumn.CHECK_ID] == c[C.VAR_CHECK_ID] and r[C.QcColumn.CHECK_STATUS] == s)
               for s in (C.QcStatus.PASS, C.QcStatus.FAIL)} for t in tables}
status = C.Status.FAILED if failed_checks or errors else C.Status.COMPLETE
result = json.dumps({C.ResultKey.STATUS: status, C.ResultKey.PIPELINE: data_pipeline_identifier,
                     C.ResultKey.RUN_ID: run_id, C.ResultKey.SUMMARY: summary,
                     "failed_checks": failed_checks, "errors": list(errors)},
                    default=str)
try:
    dbutils.jobs.taskValues.set(key=C.TASK_VALUE_QC_SUMMARY, value=json.loads(result))
except Exception as exc:  # not running inside a job
    logger.warning(f"Task value not set: {type(exc).__name__}")
logger.info(f"QC result: {result}")
if status == C.Status.FAILED:
    raise RuntimeError(f"Data quality check failed: {len(failed_checks)} failed check(s) "
                       f"{failed_checks}; tables not checked: {list(errors)}")
dbutils.notebook.exit(result)