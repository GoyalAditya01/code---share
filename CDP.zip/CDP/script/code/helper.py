"""
helper.py
Generic CDP build engine. Reads mapping.yaml and builds each table with PySpark
Table logic uses DataFrame APIs only (no Spark SQL strings, no F.expr, no hardcoded tables or
schemas); only the schema-creation DDL in create_schema_if_not_exists uses Spark SQL.

mapping.yaml: tables -> list of {table_name, table_type, columns}
  table_type    target -> written to the qc schema | intermediate -> written to the int schema
                (dependent tables read it back from the same schema)
  columns       list of {column_name, source_list, transformation}; mapping_tables() turns
                each into the internal list [source items..., {transformation}] keyed by column
  source_list   list of
  source items  {source_table, source_column, type}. In a UNION column a branch may be
                source_column: null + transformation: {constant: X}  -> F.lit(X), or
                source_column: null alone (no value)                 -> F.lit(None)
  transformation  direct | {union: ..., join: [...], case: [...]}
                steps run in the order written, and must follow: union, join, case

Steps (PySpark)
  direct  transformation: direct -> value = the single source item     -> F.col
  union   {union_type: all}: UNION ALL. The branches (and their order) are the source
          tables of the table's first union column; every union column must list
          every branch, once, in that order                           -> unionByName
  join    [{join_type, left_table, left_column, right_table, right_column}], run in
          list order (a join may start from a table joined earlier in the list).
          left/right_column = lists of {join_key_id, column_name, function}; items with
          the same join_key_id are compared; function: none|upper|lower|trim -> df.join(on=...)
  case    evaluate: {source_table, source_column}   (the column every condition tests)
          conditions: list, checked in order; the first that holds gives its result
            - condition: equals (value) | in_list (values) | is_null | is_not_null
              result: <literal> | {source_table, source_column}
            - default: <literal> | {source_table, source_column}   (last entry, always)
                                                                       -> F.when/otherwise

Column value: the CASE result if case is the last step, the UNION value if union is the
last step, otherwise the last source item read through the joins. It is cast to the last
source item's type.

References (source_table, left_table, condition tables) resolve to, in order:
  1. a table joined earlier in the same column's join chain
  2. the CDP table itself (union tables): its own column = the value so far, another
     column = that column's value (built first)
  3. the main table (non-union tables: the only table never on the right of a join)
Each distinct join chain is run once per table, however many columns list it.

Derived table (script/code/derived_variable notebook; sections "DERIVED TABLE ...")
  Builds one long table from the static CDP tables for the domains selected in the product config
  Excel ([EXPORT_COLUMNS] Include = Y, read by product_config_reader).
  attribute_grouping.yaml   domain -> [column_name, cdp_source]
  derived_variable.yaml     dataset_lookup, derived_table, event_rules, derived_variables
  * Non-event domains (demographic, location, payer_plan_period): the domain's columns read from its
    cdp_source table, as they are (already unique at their grain).
  * Event domains (condition ... device): ONE scan of the event table, filtered on
    filter_column IN (event types of the selected domains), the union of their columns.
      - cost domain NOT selected -> dropDuplicates(event_key)          (event_id, event_type)
      - cost domain selected     -> + cost columns, key = event_key + cost_key, no dedupe
        (the event table has one row per event x cost record, so the key is already unique)
  * Cost selected without an event domain is an error (cost lives on event rows).
  Output: unionByName of the domain frames (missing columns -> NULL), columns ordered:
  domain column, lead columns (person_id), then the domains' columns in selection order.
"""
import json
import re
from datetime import datetime
from functools import reduce

from pyspark.sql import functions as F
from pyspark.sql import types as T

import common_constants as C
from common_constants import EVALUATE_KEYS, JOIN_REQUIRED, JOIN_TYPES, KEY_ITEM_KEYS, SOURCE_KEYS, STEPS

# join key functions allowed in mapping.yaml (function: <name> on every key item)
KEY_FUNCTIONS = {C.KEY_FUNCTION_NONE: lambda c: c, "upper": F.upper, "lower": F.lower, "trim": F.trim}
# case condition operators allowed in mapping.yaml
OPERATORS = {
    "equals": lambda c, v: c == F.lit(v),
    "in_list": lambda c, v: c.isin(list(v)),
    "is_null": lambda c, v: c.isNull(),
    "is_not_null": lambda c, v: c.isNotNull(),
}
# the argument key each operator needs (None = no argument)
OPERATOR_ARGS = {"equals": "value", "in_list": "values", "is_null": None, "is_not_null": None}

DTYPE_MAP = {
    "string": T.StringType(),
    "bigint": T.LongType(),
    "int": T.IntegerType(),
    "float": T.FloatType(),
    "double": T.DoubleType(),
    "date": T.DateType(),
    "boolean": T.BooleanType(),
}

# derived table: resolved schema key -> its managed-location key (resolve_schemas)
SCHEMA_LOCATION = {C.QC_SCHEMA: C.QC_LOCATION, C.TARGET_SCHEMA: C.TARGET_LOCATION,
                   C.INT_SCHEMA: C.INT_LOCATION}
# derived table: allowed characters of a table / schema / catalog name part
TABLE_IDENTIFIER = re.compile(r"^[A-Za-z0-9_]+$")
# derived table calculated fields: output_attribute_name -> builder(df, parameters, context) -> df.
# Empty until the derived-variable logic is delivered; requested variables are skipped and logged.
DERIVED_VARIABLE_BUILDERS = {}


# ─────────────────────────────────────────────
# CONFIG / SCHEMAS
# ─────────────────────────────────────────────

def dtype(name):
    """Map a mapping.yaml type name to a Spark type."""
    m = re.fullmatch(r"decimal\((\d+),\s*(\d+)\)", str(name).strip().lower())
    if m:
        return T.DecimalType(int(m.group(1)), int(m.group(2)))
    if name not in DTYPE_MAP:
        raise ValueError(f"Unknown type '{name}'. Allowed: {sorted(DTYPE_MAP)} or decimal(p,s)")
    return DTYPE_MAP[name]


def resolve_schemas(schema_config, source, dataset, refresh, athena_refresh, storage_account=None):
    """Fully qualified schemas (catalog.db) and managed locations for one source/dataset
    from schemas.yaml; storage_account (env_params.yaml) fills {storage_account}.

    Returns {SOURCE_SCHEMA, PREREQ_SCHEMA, QC_SCHEMA, TARGET_SCHEMA, INT_SCHEMA: "catalog.db",
             QC_LOCATION, TARGET_LOCATION, INT_LOCATION: "abfss://..." or None when not configured}."""
    if not refresh:
        raise ValueError("refresh is required (e.g. 26q1)")
    if not athena_refresh:
        raise ValueError("athena_refresh is required (e.g. 26q2)")
    try:
        ds = schema_config[C.VAR_SOURCES][source][dataset]
    except KeyError:
        raise ValueError(f"No schemas.yaml entry for source='{source}', dataset='{dataset}'")
    prereq = schema_config[C.VAR_PREREQUISITE]
    tokens = {C.SOURCE_TOKEN: source, C.DATASET_TOKEN: dataset,
              C.REFRESH_TOKEN: refresh, C.ATHENA_REFRESH_TOKEN: athena_refresh}

    def fill(text):
        """Replace the {source}/{dataset}/{refresh}/{athena_refresh} placeholders in text."""
        text = str(text)
        for token, value in tokens.items():
            text = text.replace(token, value)
        return text

    def qualify(cfg, catalog_key, db_key):
        """Return "<catalog>.<schema>" from two schemas.yaml keys, placeholders filled."""
        return f"{cfg[catalog_key]}.{fill(cfg[db_key])}"

    def location(key):
        """Return a filled managed location (with {storage_account}) for key, or None if not set."""
        template = ds.get(key)
        if not template:
            return None
        if C.STORAGE_ACCOUNT_TOKEN in template:
            if not storage_account:
                raise ValueError(f"{key} uses {C.STORAGE_ACCOUNT_TOKEN} but env_params.yaml has no "
                                 f"{C.VAR_STORAGE_ACCOUNT}")
            template = template.replace(C.STORAGE_ACCOUNT_TOKEN, storage_account)
        return fill(template)

    return {
        C.SOURCE_SCHEMA: qualify(ds, C.VAR_SRC_DATA_CATALOG, C.VAR_SRC_DATA_DB),
        C.PREREQ_SCHEMA: qualify(prereq, C.VAR_PREREQ_DATA_CATALOG, C.VAR_PREREQ_DATA_DB),
        C.QC_SCHEMA: qualify(ds, C.VAR_QC_TABLE_CATALOG, C.VAR_QC_OUTPUT_DB),
        C.TARGET_SCHEMA: qualify(ds, C.VAR_TARGET_DATA_CATALOG, C.VAR_TARGET_DATA_DB),
        C.INT_SCHEMA: qualify(ds, C.VAR_INT_DATA_CATALOG, C.VAR_INT_DATA_DB),
        C.QC_LOCATION: location(C.VAR_QC_OUTPUT_LOCATION),
        C.TARGET_LOCATION: location(C.VAR_TARGET_DATA_LOCATION),
        C.INT_LOCATION: location(C.VAR_INT_DATA_LOCATION),
    }


def prerequisite_routing(schema_config):
    """{table: PREREQ_SCHEMA} for every table in prerequisite.prerequisite_table_list (schemas.yaml)."""
    tables = schema_config[C.VAR_PREREQUISITE].get(C.VAR_PREREQ_TABLE_LIST) or []
    return {str(t).lower(): C.PREREQ_SCHEMA for t in tables}


def create_schema_if_not_exists(spark, schema, managed_location=None, log=print):
    """Create a Unity Catalog schema ("catalog.db") when missing, at managed_location if given.
    An existing schema is left as it is (its location is not changed).
    Setup DDL (not table logic), so Spark SQL is used here."""
    parts = schema.split(".")
    if len(parts) != 2 or not all(parts):
        raise ValueError(f"Schema must be 'catalog.schema', got '{schema}'")
    if any("`" in p for p in parts) or (managed_location and "'" in managed_location):
        raise ValueError(f"Invalid characters in schema '{schema}' or location '{managed_location}'")
    create_sql = f"CREATE SCHEMA IF NOT EXISTS `{parts[0]}`.`{parts[1]}`"
    if managed_location:
        create_sql += f" MANAGED LOCATION '{managed_location}'"
    log(f"Executing schema creation SQL: {create_sql}")
    spark.sql(create_sql)


def table_spec(table, spec):
    """Validate a mapping.yaml table entry: a table_type plus its columns."""
    if not isinstance(spec, dict) or C.VAR_TABLE_TYPE not in spec:
        raise ValueError(f"{table}: needs '{C.VAR_TABLE_TYPE}: "
                         f"{' | '.join(sorted(C.TABLE_TYPE_OUTPUT))}' above its columns")
    if spec[C.VAR_TABLE_TYPE] not in C.TABLE_TYPE_OUTPUT:
        raise ValueError(f"{table}: {C.VAR_TABLE_TYPE} '{spec[C.VAR_TABLE_TYPE]}' not in "
                         f"{sorted(C.TABLE_TYPE_OUTPUT)}")
    return spec


def mapping_tables(raw):
    """mapping.yaml `tables` list -> {table_name: {table_type, <column_name>: [source items..., {transformation}]}}.

    YAML layout:
      tables:
        - table_name: <name>
          table_type: intermediate | target
          columns:
            - column_name: <name>
              source_list: [source items...]
              transformation: direct | {union / join / case ...}"""
    table_keys = {C.VAR_TABLE_NAME, C.VAR_TABLE_TYPE, C.VAR_TABLE_COLUMNS}
    column_keys = {C.VAR_COLUMN_NAME, C.VAR_COLUMN_SOURCE_LIST, C.VAR_COLUMN_TRANSFORMATION}
    if not isinstance(raw, list) or not raw:
        raise ValueError(f"mapping.yaml '{C.VAR_MAPPING_TABLES}' must be a list of tables")
    tables = {}
    for i, t in enumerate(raw):
        if not isinstance(t, dict) or set(t) != table_keys:
            raise ValueError(f"mapping.yaml table #{i + 1}: needs exactly {sorted(table_keys)}; "
                             f"got {sorted(t) if isinstance(t, dict) else t!r}")
        name = t[C.VAR_TABLE_NAME]
        if name in tables:
            raise ValueError(f"mapping.yaml: table '{name}' is listed twice")
        cols = t[C.VAR_TABLE_COLUMNS]
        if not isinstance(cols, list) or not cols:
            raise ValueError(f"{name}: '{C.VAR_TABLE_COLUMNS}' must be a list of columns")
        spec = {C.VAR_TABLE_TYPE: t[C.VAR_TABLE_TYPE]}
        for j, c in enumerate(cols):
            if not isinstance(c, dict) or set(c) != column_keys:
                raise ValueError(f"{name} column #{j + 1}: needs exactly {sorted(column_keys)}; "
                                 f"got {sorted(c) if isinstance(c, dict) else c!r}")
            cname = c[C.VAR_COLUMN_NAME]
            if cname == C.VAR_TABLE_TYPE:
                raise ValueError(f"{name}: '{C.VAR_TABLE_TYPE}' is reserved and cannot be a column name")
            if cname in spec:
                raise ValueError(f"{name}: column '{cname}' is listed twice")
            sources = c[C.VAR_COLUMN_SOURCE_LIST]
            if not isinstance(sources, list) or not sources:
                raise ValueError(f"{name}.{cname}: '{C.VAR_COLUMN_SOURCE_LIST}' must be a non-empty list")
            spec[cname] = list(sources) + [{C.VAR_COLUMN_TRANSFORMATION: c[C.VAR_COLUMN_TRANSFORMATION]}]
        tables[name] = table_spec(name, spec)
    return tables


def table_columns(table, spec):
    """The column mappings of a table (every key except table_type)."""
    return {k: v for k, v in table_spec(table, spec).items() if k != C.VAR_TABLE_TYPE}


def output_schema_key(table, spec):
    """Schema key a CDP table is written to: qc (target) or int (intermediate)."""
    return C.TABLE_TYPE_OUTPUT[table_spec(table, spec)[C.VAR_TABLE_TYPE]][0]


def output_location_key(table, spec):
    """Managed-location key of the schema a CDP table is written to."""
    return C.TABLE_TYPE_OUTPUT[table_spec(table, spec)[C.VAR_TABLE_TYPE]][1]


def cdp_output_schemas(all_tables):
    """{cdp_table: schema key it is written to / read from}."""
    return {t: output_schema_key(t, s) for t, s in all_tables.items()}


def schema_for(table_name, schemas, routing, cdp_tables):
    """Where to read a physical table from (see schemas.yaml).
    cdp_tables: {cdp_table: schema key} from cdp_output_schemas."""
    key = routing.get(table_name)
    if key:
        return schemas[key]
    if table_name in cdp_tables:
        return schemas[cdp_tables[table_name]]
    return schemas[C.SOURCE_SCHEMA]


def as_list(x):
    """Return x as a list (wrap a single value)."""
    return x if isinstance(x, list) else [x]


# ─────────────────────────────────────────────
# MAPPING MODEL (parse + validate mapping.yaml)
# ─────────────────────────────────────────────

def key_name(k):
    """Column name of a join key (plain name or {column, function})."""
    return k["column"] if isinstance(k, dict) else k


def join_keys(items, where, side):
    """Validate one side of a join (left_column or right_column) and index it by join key id.

    Args:
        items: list of {join_key_id, column_name, function} from mapping.yaml.
        where: "<table>.<column>" used in error messages.
        side: "left_column" or "right_column", used in error messages.

    Returns:
        {join_key_id: key}; key is the column name (function: none) or {column, function}.
    """
    keys = f"{C.JOIN_KEY_ID}, column_name, function"
    if not isinstance(items, list) or not items:
        raise ValueError(f"{where}: {side} must be a list of {{{keys}}} items")
    out = {}
    for it in items:
        if not isinstance(it, dict) or set(it) != KEY_ITEM_KEYS:
            raise ValueError(f"{where}: {side} item needs exactly {keys}; got {it!r}")
        if it[C.JOIN_KEY_ID] in out:
            raise ValueError(f"{where}: {side} has {C.JOIN_KEY_ID} {it[C.JOIN_KEY_ID]} twice")
        f = it["function"]
        if f not in KEY_FUNCTIONS:
            raise ValueError(f"{where}: function '{f}' not in {sorted(KEY_FUNCTIONS)}")
        out[it[C.JOIN_KEY_ID]] = it["column_name"] if f == C.KEY_FUNCTION_NONE else {"column": it["column_name"], "function": f}
    return out


def check_join(j, where):
    """Validate one join step and pair its keys.

    Returns the join with left_column / right_column as two lists in the same order
    (sorted by join_key_id), so item i on the left is compared with item i on the right.
    """
    if not isinstance(j, dict):
        raise ValueError(f"{where}: each join must be a mapping, got {j!r}")
    missing, extra = JOIN_REQUIRED - set(j), set(j) - JOIN_REQUIRED
    if missing or extra:
        raise ValueError(f"{where}: join needs exactly {sorted(JOIN_REQUIRED)}; "
                         f"missing {sorted(missing)}, unknown {sorted(extra)}")
    if j["join_type"] not in JOIN_TYPES:
        raise ValueError(f"{where}: join_type '{j['join_type']}' not in {sorted(JOIN_TYPES)}")
    left = join_keys(j["left_column"], where, "left_column")
    right = join_keys(j["right_column"], where, "right_column")
    if set(left) != set(right):
        raise ValueError(f"{where}: left_column {C.JOIN_KEY_ID}s {sorted(left)} and right_column "
                         f"{C.JOIN_KEY_ID}s {sorted(right)} must match")
    ids = sorted(left)
    return {**j, "left_column": [left[i] for i in ids], "right_column": [right[i] for i in ids]}


def check_result(v, where):
    """A case result / default: a literal (-> {constant}) or {source_table, source_column}."""
    if isinstance(v, dict):
        if set(v) == EVALUATE_KEYS:
            return dict(v)
        raise ValueError(f"{where}: case result must be a literal or source_table + source_column; got {v!r}")
    if isinstance(v, list):
        raise ValueError(f"{where}: case result cannot be a list; got {v!r}")
    return {C.CONSTANT_KEY: v}


def check_case(spec, where):
    """case: {evaluate, conditions} -> internal {when: [{condition, then}], else}."""
    if not isinstance(spec, dict) or set(spec) != {C.CASE_EVALUATE, C.CASE_CONDITIONS}:
        raise ValueError(f"{where}: case needs exactly '{C.CASE_EVALUATE}' and '{C.CASE_CONDITIONS}'; got {spec!r}")
    evaluate = spec[C.CASE_EVALUATE]
    if not isinstance(evaluate, dict) or set(evaluate) != EVALUATE_KEYS:
        raise ValueError(f"{where}: case {C.CASE_EVALUATE} needs source_table + source_column; got {evaluate!r}")
    conditions = spec[C.CASE_CONDITIONS]
    if not isinstance(conditions, list) or len(conditions) < 2:
        raise ValueError(f"{where}: case {C.CASE_CONDITIONS} needs at least one condition and a last "
                         f"'{C.CASE_DEFAULT}' entry")
    whens = []
    for i, cond in enumerate(conditions):
        last = i == len(conditions) - 1
        if not isinstance(cond, dict):
            raise ValueError(f"{where}: case condition must be a mapping, got {cond!r}")
        if last:
            if set(cond) != {C.CASE_DEFAULT}:
                raise ValueError(f"{where}: the last case entry must be only '{C.CASE_DEFAULT}'; got {cond!r}")
            return {"when": whens, "else": check_result(cond[C.CASE_DEFAULT], where)}
        if C.CASE_DEFAULT in cond:
            raise ValueError(f"{where}: '{C.CASE_DEFAULT}' must be the last case entry")
        op = cond.get(C.CASE_CONDITION)
        if op not in OPERATORS:
            raise ValueError(f"{where}: case condition '{op}' not in {sorted(OPERATORS)}")
        arg = OPERATOR_ARGS[op]
        allowed = {C.CASE_CONDITION, C.CASE_RESULT} | ({arg} if arg else set())
        if set(cond) != allowed:
            raise ValueError(f"{where}: case condition '{op}' needs exactly {sorted(allowed)}; got {sorted(cond)}")
        if arg == "values" and (not isinstance(cond[arg], list) or not cond[arg]):
            raise ValueError(f"{where}: case condition '{op}' needs a non-empty values list")
        if arg == "value" and isinstance(cond[arg], (list, dict)):
            raise ValueError(f"{where}: case condition '{op}' needs a single value")
        whens.append({"condition": {**evaluate, "operator": op, "value": cond.get(arg) if arg else None},
                      "then": check_result(cond[C.CASE_RESULT], where)})


def parse_steps(where, transformation):
    """Normalise a transformation to an ordered list of (step, spec)."""
    if transformation == C.STEP_DIRECT:
        return [(C.STEP_DIRECT, None)]
    if not isinstance(transformation, dict) or not transformation:
        raise ValueError(f"{where}: transformation must be 'direct' or a mapping of steps "
                         f"(union | join | case)")
    out = []
    for kind, spec in transformation.items():
        if kind not in STEPS or kind == C.STEP_DIRECT:
            raise ValueError(f"{where}: unsupported step '{kind}' (allowed: union, join, case; "
                             f"plain copies use 'transformation: direct')")
        if kind == C.STEP_UNION and (spec or {}).get(C.UNION_TYPE_KEY) != C.UNION_TYPE_ALL:
            raise ValueError(f"{where}: union needs union_type: all")
        if kind == C.STEP_JOIN:
            spec = [check_join(j, where) for j in as_list(spec)]
        if kind == C.STEP_CASE:
            spec = check_case(spec, where)
        out.append((kind, spec))
    order = [STEPS.index(k) for k, _ in out]
    if order != sorted(order):
        raise ValueError(f"{where}: steps must be written in the order union, join, case; "
                         f"got {[k for k, _ in out]}")
    return out


def parse_column(table, name, spec):
    """Validate one column's internal spec and parse it into a column model.

    Args:
        table: CDP table name.
        name: output column name.
        spec: [source items..., {transformation: ...}] (built by mapping_tables).

    Returns:
        {name, sources, steps, type}; steps = [(kind, spec)] in run order; type = output type.

    Raises:
        ValueError: on a malformed source item or transformation.
    """
    where = f"{table}.{name}"
    if not isinstance(spec, list) or len(spec) < 2:
        raise ValueError(f"{where}: expected a list of source items followed by a transformation item")
    *sources, last = spec
    if not isinstance(last, dict) or set(last) != {"transformation"}:
        raise ValueError(f"{where}: the last item must be {{transformation: ...}}")
    for s in sources:
        if not isinstance(s, dict) or not {"source_table", "type"} <= set(s) or set(s) - SOURCE_KEYS:
            raise ValueError(f"{where}: source item needs source_table, source_column, type; got {s!r}")
        t = s.get("transformation")
        if t is not None and not (isinstance(t, dict) and set(t) == {C.CONSTANT_KEY}):
            raise ValueError(f"{where}: a source item may only carry transformation: {{constant: X}}")
        if "source_column" not in s:
            raise ValueError(f"{where}: source item {s['source_table']} needs source_column (null if none)")
        dtype(s["type"])
    steps = parse_steps(where, last["transformation"])
    if steps[0][0] != C.STEP_UNION and any(s["source_column"] is None for s in sources):
        raise ValueError(f"{where}: source_column: null is only allowed for UNION branches")
    return {"name": name, "sources": sources, "steps": steps, "type": sources[-1]["type"]}


def joins_of(col):
    """Return all join specs of a parsed column, in run order."""
    return [j for kind, spec in col["steps"] if kind == C.STEP_JOIN for j in spec]


def table_model(table, spec):
    """Parsed table: columns, union branches, main table."""
    spec = table_columns(table, spec)
    if not spec:
        raise ValueError(f"{table}: expected a mapping of columns")
    cols = [parse_column(table, n, s) for n, s in spec.items()]
    union_cols = [c for c in cols if c["steps"][0][0] == C.STEP_UNION]
    m = {"name": table, "columns": cols, "by_name": {c["name"]: c for c in cols},
         "union": bool(union_cols), "union_only": set()}
    if union_cols:
        branches = list(dict.fromkeys(s["source_table"] for s in union_cols[0]["sources"]))
        for c in union_cols:
            where = f"{table}.{c['name']}"
            rights = {j["right_table"] for j in joins_of(c)}
            items = [s for s in c["sources"] if s["source_table"] in branches]
            seen = [s["source_table"] for s in items]
            if seen != branches:
                raise ValueError(f"{where}: list every UNION branch once, in order {branches} "
                                 f"(no value -> source_column: null); got {seen}")
            if len({s["type"] for s in items}) != 1:
                raise ValueError(f"{where}: UNION branches need one common type")
            for s in c["sources"]:
                if s["source_table"] not in branches and s["source_column"] is None:
                    raise ValueError(f"{where}: source_column: null on '{s['source_table']}', "
                                     f"which is not a UNION branch")
                if s["source_table"] not in branches and s["source_table"] not in rights:
                    raise ValueError(f"{where}: '{s['source_table']}' is neither a UNION branch "
                                     f"{branches} nor a table joined in this column")
        m["branches"] = branches
        m["base"] = table
        m["union_only"] = {c["name"] for c in union_cols if len(c["steps"]) == 1}
    else:
        refs, rights = set(), set()
        for c in cols:
            refs |= {s["source_table"] for s in c["sources"]}
            for j in joins_of(c):
                refs.add(j["left_table"])
                rights.add(j["right_table"])
        candidates = sorted(refs - rights)
        if len(candidates) != 1:
            raise ValueError(f"{table}: expected exactly one main table, found {candidates}")
        m["base"] = candidates[0]
    return m


def condition_refs(cond):
    """Return the (table, column) a case condition reads."""
    return [(cond.get("source_table"), cond.get("source_column"))]


def value_refs(v):
    """Return the (table, column) a case result reads; [] for a constant."""
    return [] if C.CONSTANT_KEY in v else [(v.get("source_table"), v.get("source_column"))]


def column_refs(col):
    """(table, column) pairs a column reads through its steps."""
    out = []
    for kind, spec in col["steps"]:
        if kind == C.STEP_JOIN:
            for j in spec:
                out += [(j["left_table"], key_name(k)) for k in as_list(j["left_column"])]
        elif kind == C.STEP_CASE:
            for w in spec["when"]:
                out += condition_refs(w["condition"]) + value_refs(w["then"])
            if "else" in spec:
                out += value_refs(spec["else"])
    if col["steps"][-1][0] not in (C.STEP_UNION, C.STEP_CASE):
        s = col["sources"][-1]
        out.append((s["source_table"], s["source_column"]))
    return out


def refers_to(chain, table, column):
    """True if a join chain reads table.column (used to keep self-references apart)."""
    for j in chain:
        refs = [(j["left_table"], key_name(k)) for k in as_list(j["left_column"])]
        if (table, column) in refs:
            return True
    return False


def physical_tables(name, spec):
    """Every physical table a CDP table reads."""
    m = table_model(name, spec)
    names = set()
    for c in m["columns"]:
        names |= {s["source_table"] for s in c["sources"]}
        for j in joins_of(c):
            names |= {j["left_table"], j["right_table"]}
    if m["union"]:
        names.discard(name)
        names |= set(m["branches"])
    return names


def table_dependencies(name, all_tables):
    """CDP tables (keys in mapping.yaml) that this table reads."""
    return {t for t in physical_tables(name, all_tables[name]) if t in all_tables and t != name}


def build_order(all_tables, requested):
    """Requested tables plus their CDP dependencies, dependencies first."""
    order, done = [], set()

    def visit(t, stack):
        """Depth-first: add t after its dependencies; stack detects circular dependencies."""
        if t in stack:
            raise ValueError(f"Circular dependency: {' -> '.join(stack + (t,))}")
        if t in done:
            return
        for d in sorted(table_dependencies(t, all_tables)):
            visit(d, stack + (t,))
        done.add(t)
        order.append(t)

    for t in requested:
        visit(t, ())
    return order


# ─────────────────────────────────────────────
# EXPRESSIONS / UNION / COLUMN ORDER
# ─────────────────────────────────────────────

def key_expr(k, colfn, where):
    """Join key expression: a column, optionally wrapped in upper/lower/trim."""
    if isinstance(k, str):
        return colfn(k)
    if isinstance(k, dict) and set(k) == {"column", "function"} and k["function"] in KEY_FUNCTIONS:
        return KEY_FUNCTIONS[k["function"]](colfn(k["column"]))
    raise ValueError(f"{where}: bad join key {k!r} (use a name or {{column, function: "
                     f"{'|'.join(KEY_FUNCTIONS)}}})")


def condition_expr(cond, ref, where):
    """Build the PySpark boolean Column for one case condition.

    Args:
        cond: {operator, source_table, source_column, value?}; operator in OPERATORS.
        ref: function (table, column) -> Column.
        where: "<table>.<column>" used in error messages.
    """
    op = cond.get("operator")
    if op not in OPERATORS:
        raise ValueError(f"{where}: operator '{op}' not in {sorted(OPERATORS)}")
    return OPERATORS[op](ref(cond["source_table"], cond["source_column"]), cond.get("value"))


def value_expr(v, ref):
    """Build the Column for a case result: F.lit for a constant, else the referenced column."""
    if C.CONSTANT_KEY in v:
        return F.lit(v[C.CONSTANT_KEY])
    return ref(v["source_table"], v["source_column"])


def case_expr(case, ref, where):
    """Build the F.when(...).when(...).otherwise(...) Column for a parsed case step.

    Conditions are checked in order and the first match gives its result; `else` (the YAML
    `default`) is the fallback, NULL when absent.
    """
    out = None
    for w in case["when"]:
        c, v = condition_expr(w["condition"], ref, where), value_expr(w["then"], ref)
        out = F.when(c, v) if out is None else out.when(c, v)
    return out.otherwise(value_expr(case["else"], ref)) if "else" in case else out


def build_union(m, load, log=print):
    """UNION ALL: one select per branch, one column per union column (source_column: null = NULL)."""
    ucols = [c for c in m["columns"] if c["steps"][0][0] == C.STEP_UNION]
    parts = []
    for branch in m["branches"]:
        src = load(branch)
        select = []
        for c in ucols:
            items = [s for s in c["sources"] if s["source_table"] in m["branches"]]
            item = next((s for s in items if s["source_table"] == branch), None)
            if item is None:
                e = F.lit(None)
            elif item.get("transformation"):
                e = F.lit(item["transformation"][C.CONSTANT_KEY])
            elif item["source_column"] is None:
                e = F.lit(None)
            else:
                e = F.col(f"`{item['source_column']}`")
            select.append(e.cast(dtype(items[0]["type"])).alias(f"{C.SOURCE_PREFIX}{c['name']}"))
        parts.append(src.select(select))
        log(f"  Union branch: {branch}")
    return reduce(lambda a, b: a.unionByName(b), parts)


def column_order(m):
    """Columns in mapping order, moved after any column of the same table they read."""
    self_refs = m["union"] or m["base"] != m["name"]
    deps = {}
    for c in m["columns"]:
        d = set()
        for t, col in column_refs(c):
            if self_refs and t == m["name"] and col != c["name"] and col not in m["union_only"]:
                if col not in m["by_name"]:
                    raise ValueError(f"{m['name']}.{c['name']}: unknown column {t}.{col}")
                d.add(col)
        deps[c["name"]] = d
    order, done, pending = [], set(), list(m["columns"])
    while pending:
        ready = [c for c in pending if deps[c["name"]] <= done]
        if not ready:
            raise ValueError(f"{m['name']}: circular column references {[c['name'] for c in pending]}")
        for c in ready:
            order.append(c)
            done.add(c["name"])
            pending.remove(c)
    return order


# ─────────────────────────────────────────────
# BUILD ONE TABLE
# ─────────────────────────────────────────────

def run_join(j, ref, local, state, load, log, where):
    """Run one join on state['df']; the right table's columns get a private prefix."""
    alias = f"j{len(state['joins']) + 1}"
    right = load(j["right_table"])
    right = right.select([F.col(f"`{x}`").alias(f"{alias}__{x}") for x in right.columns])
    lcols, rcols = as_list(j["left_column"]), as_list(j["right_column"])
    cond = None
    for lc, rc in zip(lcols, rcols):
        e = (key_expr(lc, lambda col: ref(j["left_table"], col), where)
             == key_expr(rc, lambda col: F.col(f"`{alias}__{col}`"), where))
        cond = e if cond is None else (cond & e)
    local[j["right_table"]] = alias
    state["df"] = state["df"].join(right, on=cond, how=j["join_type"])
    log(f"  Joined ({j['join_type']}): {j['left_table']}.{lcols} -> {j['right_table']}.{rcols}")
    return alias


def column_value(c, m, state, load, log):
    """PySpark expression for one column (its joins are run on state['df'])."""
    where = f"{m['name']}.{c['name']}"
    self_refs = m["union"] or m["base"] != m["name"]
    local, chain, current = {}, [], {}

    def ref(table, column):
        """Return the Column for table.column inside this table's build.

        Resolves, in order: a joined table's prefixed column, this table's own (self-referenced)
        columns, the base table's columns, else raises ValueError.
        """
        if table in local:
            return F.col(f"`{local[table]}__{column}`")
        if self_refs and table == m["name"]:
            if column == c["name"]:
                if "value" not in current:
                    raise ValueError(f"{where}: reads itself before it has a value")
                return current["value"]
            if column in m["union_only"]:
                return F.col(f"`{C.SOURCE_PREFIX}{column}`")
            if column in state["done"]:
                return F.col(f"`{C.TARGET_PREFIX}{column}`")
            raise ValueError(f"{where}: unknown column {table}.{column}")
        if table == m["base"]:
            return F.col(f"`{C.SOURCE_PREFIX}{column}`")
        raise ValueError(f"{where}: '{table}' is not the main table, the table itself, "
                         f"or a table joined earlier in this column")

    for kind, spec in c["steps"]:
        if kind == C.STEP_UNION:
            current["value"] = F.col(f"`{C.SOURCE_PREFIX}{c['name']}`")
        elif kind == C.STEP_JOIN:
            for j in spec:
                chain.append(j)
                key = json.dumps(chain, sort_keys=True, default=str)
                if self_refs and refers_to(chain, m["name"], c["name"]):
                    key += f"@{c['name']}"
                if key not in state["joins"]:
                    state["joins"][key] = run_join(j, ref, local, state, load, log, where)
                local[j["right_table"]] = state["joins"][key]
        elif kind == C.STEP_CASE:
            current["value"] = case_expr(spec, ref, where)

    if c["steps"][-1][0] in (C.STEP_UNION, C.STEP_CASE):
        return current["value"]
    s = c["sources"][-1]
    return ref(s["source_table"], s["source_column"])


def build_table(spark, table_name, all_tables, schemas, routing, built=None, log=print):
    """Build one CDP table as a DataFrame (nothing is written here).

    built: optional {table: DataFrame} used instead of reading the stored table
           (lets tests check a chain of tables in memory)."""
    built = built or {}
    m = table_model(table_name, all_tables[table_name])
    # a CDP table never reads itself: a source table with the same name
    # (e.g. payer_plan_period) comes from the source schema
    cdp_tables = {t: k for t, k in cdp_output_schemas(all_tables).items() if t != table_name}

    def load(physical):
        """Return the DataFrame for a physical table: built in this run if available, else read from its schema."""
        if physical in built and physical != table_name:
            log(f"  Loaded: {physical} (built in this run)")
            return built[physical]
        full = f"{schema_for(physical, schemas, routing, cdp_tables)}.{physical}"
        log(f"  Loaded: {full}")
        return spark.table(full)

    # 1. main DataFrame: the UNION ALL, or the main table
    if m["union"]:
        df = build_union(m, load, log)
    else:
        log(f"  Main table: {m['base']}")
        src = load(m["base"])
        df = src.select([F.col(f"`{x}`").alias(f"{C.SOURCE_PREFIX}{x}") for x in src.columns])

    # 2. columns in dependency order; each runs its joins (shared chains run once)
    state = {"df": df, "joins": {}, "done": set()}
    for c in column_order(m):
        value = column_value(c, m, state, load, log)
        state["df"] = state["df"].withColumn(f"{C.TARGET_PREFIX}{c['name']}", value.cast(dtype(c["type"])))
        state["done"].add(c["name"])

    # 3. output columns in mapping order
    result = state["df"].select([F.col(f"`{C.TARGET_PREFIX}{c['name']}`").alias(c["name"]) for c in m["columns"]])
    log(f"  Joins: {len(state['joins'])}, columns: {len(m['columns'])}")
    return result


# ─────────────────────────────────────────────
# RUN (ORDER, BUILD, WRITE)
# ─────────────────────────────────────────────

def write_table(df, full_name):
    """Overwrite full_name (catalog.schema.table) with df using the write settings in common_constants."""
    (df.write.format(C.VAR_OUTPUT_FORMAT).mode(C.VAR_WRITE_MODE)
       .options(**C.VAR_WRITE_OPTIONS).saveAsTable(full_name))


def run(spark, all_tables, routing, schemas, table=C.ALL_TABLES, log=print):
    """Build and write the requested tables in dependency order.

    Requested table: always rebuilt and overwritten in its output schema
    (table_type target -> qc schema, intermediate -> int schema).
    CDP dependency that was not requested: read as is when it exists, otherwise built and written first.
    Returns the run summary (one record per table)."""
    requested = (list(all_tables) if table == C.ALL_TABLES
                 else [t.strip() for t in table.split(C.LIST_SEPARATOR) if t.strip()])
    unknown = [t for t in requested if t not in all_tables]
    if unknown:
        raise ValueError(f"Unknown table(s) {unknown}. Available: {list(all_tables)}")

    routing = dict(routing or {})
    order = build_order(all_tables, requested)
    log(f"Build order: {order}")
    for key, loc_key in dict.fromkeys((output_schema_key(t, all_tables[t]), output_location_key(t, all_tables[t]))
                                      for t in order):
        create_schema_if_not_exists(spark, schemas[key], schemas.get(loc_key), log)

    summary = []
    cdp_tables = cdp_output_schemas(all_tables)
    for t in order:
        if t not in requested:
            # dependency: reuse it where dependents will read it from
            read_from = f"{schema_for(t, schemas, routing, cdp_tables)}.{t}"
            if spark.catalog.tableExists(read_from):
                log(f"\n[{t}] dependency exists at {read_from}: reused")
                summary.append({C.SummaryKey.TABLE: t, C.SummaryKey.STATUS: C.TableStatus.DEPENDENCY_REUSED,
                                C.SummaryKey.TARGET: read_from})
                continue

        target = f"{schemas[cdp_tables[t]]}.{t}"
        log(f"\n{'=' * 60}\nBuilding {t}\n{'=' * 60}")
        df = build_table(spark, t, all_tables, schemas, routing, log=log)
        write_table(df, target)
        rows = spark.table(target).count()
        summary.append({C.SummaryKey.TABLE: t, C.SummaryKey.STATUS: C.TableStatus.WRITTEN, C.SummaryKey.TARGET: target,
                        C.SummaryKey.ROWS: rows})
        log(f"  Written: {target} ({rows:,} rows)")
    return summary


# ─────────────────────────────────────────────
# DERIVED TABLE: CONFIG (attribute_grouping.yaml / derived_variable.yaml)
# ─────────────────────────────────────────────

def require_keys(cfg, keys, where):
    """Raise when any of keys is missing / empty in dict cfg."""
    if not isinstance(cfg, dict):
        raise ValueError(f"{where} must be a mapping")
    missing = [k for k in keys if cfg.get(k) in (None, "", [], {})]
    if missing:
        raise ValueError(f"{where}: missing {missing}")
    return cfg


def attribute_domains(domain_list):
    """attribute_grouping.yaml domain.domain_list -> {domain: [(column_name, cdp_source)]} (order kept)."""
    if not isinstance(domain_list, list) or not domain_list:
        raise ValueError(f"attribute_grouping.yaml '{C.VAR_DOMAIN}.{C.VAR_DOMAIN_LIST}' must be a list")
    domains = {}
    for i, item in enumerate(domain_list):
        require_keys(item, (C.VAR_DOMAIN_NAME, C.VAR_COLUMN_LIST), f"attribute_grouping.yaml domain #{i + 1}")
        name = str(item[C.VAR_DOMAIN_NAME]).strip().lower()
        if name in domains:
            raise ValueError(f"attribute_grouping.yaml: domain '{name}' is listed twice")
        columns, seen = [], set()
        for j, col in enumerate(item[C.VAR_COLUMN_LIST]):
            require_keys(col, (C.VAR_COLUMN_NAME, C.VAR_CDP_SOURCE),
                         f"attribute_grouping.yaml {name} column #{j + 1}")
            column = str(col[C.VAR_COLUMN_NAME]).strip()
            if column.lower() in seen:
                raise ValueError(f"attribute_grouping.yaml {name}: column '{column}' is listed twice")
            seen.add(column.lower())
            columns.append((column, str(col[C.VAR_CDP_SOURCE]).strip()))
        domains[name] = columns
    return domains


def dataset_for(lookup, dataset_name):
    """Excel dataset_name -> (source, dataset) from derived_variable.yaml dataset_lookup."""
    for i, item in enumerate(lookup or []):
        require_keys(item, (C.VAR_LOOKUP_DATASET_NAME, C.VAR_LOOKUP_SOURCE, C.VAR_LOOKUP_DATASET),
                     f"derived_variable.yaml {C.VAR_DATASET_LOOKUP} #{i + 1}")
        if str(item[C.VAR_LOOKUP_DATASET_NAME]).strip().lower() == dataset_name.strip().lower():
            return str(item[C.VAR_LOOKUP_SOURCE]).strip(), str(item[C.VAR_LOOKUP_DATASET]).strip()
    known = [item.get(C.VAR_LOOKUP_DATASET_NAME) for item in lookup or []]
    raise ValueError(f"dataset_name '{dataset_name}' is not in derived_variable.yaml "
                     f"{C.VAR_DATASET_LOOKUP} {known}")


def table_settings(cfg):
    """derived_variable.yaml derived_table block, validated."""
    require_keys(cfg, (C.VAR_NAME_TEMPLATE, C.VAR_TIMESTAMP_FORMAT, C.VAR_READ_SCHEMA, C.VAR_WRITE_SCHEMA,
                       C.VAR_DOMAIN_COLUMN), f"derived_variable.yaml {C.VAR_DERIVED_TABLE}")
    for key in (C.VAR_READ_SCHEMA, C.VAR_WRITE_SCHEMA):
        if cfg[key] not in SCHEMA_LOCATION:
            raise ValueError(f"derived_variable.yaml {C.VAR_DERIVED_TABLE}.{key} '{cfg[key]}' "
                             f"must be one of {sorted(SCHEMA_LOCATION)}")
    return {**cfg, C.VAR_LEAD_COLUMNS: list(cfg.get(C.VAR_LEAD_COLUMNS) or [])}


def event_settings(cfg):
    """derived_variable.yaml event_rules block, validated; domain names lower-cased."""
    require_keys(cfg, (C.VAR_CDP_SOURCE, C.VAR_FILTER_COLUMN, C.VAR_EVENT_KEY, C.VAR_COST_DOMAIN,
                       C.VAR_COST_KEY, C.VAR_DOMAIN_EVENT_TYPE), f"derived_variable.yaml {C.VAR_EVENT_RULES}")
    return {
        **cfg,
        C.VAR_COST_DOMAIN: str(cfg[C.VAR_COST_DOMAIN]).strip().lower(),
        C.VAR_DOMAIN_EVENT_TYPE: {str(d).strip().lower(): str(t).strip()
                                  for d, t in cfg[C.VAR_DOMAIN_EVENT_TYPE].items()},
    }


# ─────────────────────────────────────────────
# DERIVED TABLE: DOMAIN SELECTION
# ─────────────────────────────────────────────

def ordered_union(*lists):
    """Concatenate column lists, keeping the first occurrence of each name (case-insensitive)."""
    out, seen = [], set()
    for names in lists:
        for name in names:
            if name.lower() not in seen:
                seen.add(name.lower())
                out.append(name)
    return out


def domain_column_names(domains, names):
    """Columns of the given domains, in order, without repeats."""
    return ordered_union(*[[c for c, _ in domains[d]] for d in names])


def selection_plan(selected, domains, rules):
    """Split the selected domains into event / cost / other and check them.

    Returns {event_domains, cost_selected, other_domains, event_columns, event_key}."""
    errors = []
    event_types = rules[C.VAR_DOMAIN_EVENT_TYPE]
    cost_domain = rules[C.VAR_COST_DOMAIN]
    event_source = rules[C.VAR_CDP_SOURCE]

    if not selected:
        errors.append("no domain selected (Include = Y)")
    unknown = [d for d in selected if d not in domains]
    if unknown:
        errors.append(f"domain(s) {unknown} not in attribute_grouping.yaml (known: {list(domains)})")
    known = [d for d in selected if d in domains]
    event_domains = [d for d in known if d in event_types]
    cost_selected = cost_domain in known
    other_domains = [d for d in known if d not in event_types and d != cost_domain]

    if cost_selected and not event_domains:
        errors.append(f"'{cost_domain}' is selected without an event domain "
                      f"({list(event_types)}); cost columns only exist on event rows")
    for d in event_domains + ([cost_domain] if cost_selected else []):
        sources = {s for _, s in domains[d]}
        if sources != {event_source}:
            errors.append(f"domain '{d}' must read every column from '{event_source}', got {sorted(sources)}")
    for d in other_domains:
        sources = {s for _, s in domains[d]}
        if len(sources) != 1:
            errors.append(f"domain '{d}' reads from several tables {sorted(sources)}; one cdp_source per "
                          f"domain is supported")
    if errors:
        raise ValueError("Domain selection problem(s):\n  - " + "\n  - ".join(errors))

    event_key = list(rules[C.VAR_EVENT_KEY])
    key = event_key + (list(rules[C.VAR_COST_KEY]) if cost_selected else [])
    columns = []
    if event_domains:
        columns = ordered_union(key, domain_column_names(domains, event_domains),
                                domain_column_names(domains, [cost_domain]) if cost_selected else [])
    return {"event_domains": event_domains, "cost_selected": cost_selected,
            "other_domains": other_domains, "event_columns": columns,
            "event_key": key if event_domains else []}


def required_tables(plan, domains, rules):
    """{cdp table: [columns read]} for the pre-check."""
    tables = {}
    for d in plan["other_domains"]:
        table = domains[d][0][1]
        tables[table] = ordered_union(tables.get(table, []), [c for c, _ in domains[d]])
    if plan["event_domains"]:
        table = rules[C.VAR_CDP_SOURCE]
        tables[table] = ordered_union(tables.get(table, []), [rules[C.VAR_FILTER_COLUMN]],
                                      plan["event_columns"])
    return tables


def check_tables(spark, schema, tables):
    """Raise unless every table exists in schema with every listed column (case-insensitive)."""
    errors = []
    for table, columns in tables.items():
        full = f"{schema}.{table}"
        if not spark.catalog.tableExists(full):
            errors.append(f"{full} does not exist (build the static tables first)")
            continue
        have = {c.lower() for c in spark.table(full).columns}
        missing = [c for c in columns if c.lower() not in have]
        if missing:
            errors.append(f"{full} is missing column(s) {missing}")
    if errors:
        raise ValueError("Static table check failed:\n  - " + "\n  - ".join(errors))


# ─────────────────────────────────────────────
# DERIVED TABLE: FRAMES / LONG TABLE
# ─────────────────────────────────────────────

def select_columns(columns):
    """F.col for each name, aliased to the attribute_grouping spelling (tables may differ in case)."""
    return [F.col(f"`{c}`").alias(c) for c in columns]


def domain_frame(df, domain, columns, domain_column):
    """A non-event domain: its columns as they are, plus the domain name."""
    return df.select(F.lit(domain).alias(domain_column), *select_columns(columns))


def event_frame(event_df, plan, rules, domain_column):
    """The selected event domains from the event table (one scan), with the cost rule applied.

    Returns (DataFrame, key columns)."""
    filter_column = rules[C.VAR_FILTER_COLUMN]
    types = {d: rules[C.VAR_DOMAIN_EVENT_TYPE][d] for d in plan["event_domains"]}
    # event_type value -> domain name
    domain_expr = reduce(lambda expr, d: expr.when(F.col(filter_column) == F.lit(types[d]), F.lit(d)),
                         list(types)[1:],
                         F.when(F.col(filter_column) == F.lit(types[plan["event_domains"][0]]),
                                F.lit(plan["event_domains"][0])))
    df = (event_df
          .filter(F.col(filter_column).isin(list(types.values())))
          .select(domain_expr.alias(domain_column), *select_columns(plan["event_columns"])))
    if not plan["cost_selected"]:
        # without cost columns the rows of one event are identical: keep one per event
        df = df.dropDuplicates(list(rules[C.VAR_EVENT_KEY]))
    return df, plan["event_key"]


def long_table(frames, domain_column, lead_columns):
    """unionByName of [(name, DataFrame)] (missing columns -> NULL), columns ordered:
    domain column, lead columns, then first appearance. Raises on a column with two types."""
    types, conflicts = {}, []
    for name, df in frames:
        for field in df.schema.fields:
            key, dtype_name = field.name.lower(), field.dataType.simpleString()
            if key in types and types[key][1] != dtype_name:
                conflicts.append(f"{field.name}: {types[key][0]}={types[key][1]} vs {name}={dtype_name}")
            types.setdefault(key, (name, dtype_name))
    if conflicts:
        raise ValueError("Same column with different types across domains:\n  - " + "\n  - ".join(conflicts))

    df = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), [f for _, f in frames])
    columns = ordered_union([domain_column], [c for c in lead_columns if c in df.columns], df.columns)
    return df.select([F.col(f"`{c}`") for c in columns])


# ─────────────────────────────────────────────
# DERIVED TABLE: CALCULATED FIELDS (placeholder)
# ─────────────────────────────────────────────

def apply_derived_variables(df, requested, context=None, log=print):
    """Add the requested calculated fields that have a builder. Returns (df, applied, skipped)."""
    applied, skipped = [], []
    for variable in requested:
        name = variable[C.HDR_OUTPUT_ATTRIBUTE_NAME]
        builder = DERIVED_VARIABLE_BUILDERS.get(name)
        if builder is None:
            skipped.append(name)
            continue
        df = builder(df, variable["parameters"], context)
        applied.append(name)
    if skipped:
        log(f"Derived variables not implemented yet, skipped: {skipped}")
    return df, applied, skipped


# ─────────────────────────────────────────────
# DERIVED TABLE: OUTPUT TABLE NAME
# ─────────────────────────────────────────────

def new_table_name(settings, source, dataset, refresh, now=None):
    """run_mode New: name_template filled ({source} {dataset} {refresh} {timestamp}), lower case."""
    timestamp = (now or datetime.now()).strftime(settings[C.VAR_TIMESTAMP_FORMAT])
    name = settings[C.VAR_NAME_TEMPLATE].format(source=source, dataset=dataset, refresh=refresh,
                                                 timestamp=timestamp).lower()
    if not TABLE_IDENTIFIER.match(name):
        raise ValueError(f"Derived table name '{name}' may only contain letters, digits and _")
    return name


def previous_table(previous, read_schema):
    """run_mode Update: previous_derived_table_name (table | schema.table | catalog.schema.table)
    -> (fully qualified name to check, table name). Missing parts come from read_schema."""
    parts = [p.strip().strip("`") for p in previous.split(".")]
    if not 1 <= len(parts) <= 3 or not all(TABLE_IDENTIFIER.match(p) for p in parts):
        raise ValueError(f"{C.RUN_SETTING_PREVIOUS_TABLE} '{previous}' must be table, schema.table "
                         f"or catalog.schema.table")
    catalog, schema = read_schema.split(".")
    full = {1: f"{read_schema}.{parts[0]}", 2: f"{catalog}.{parts[0]}.{parts[1]}",
            3: ".".join(parts)}[len(parts)]
    return full, parts[-1]


# ─────────────────────────────────────────────
# VALIDATION HELPERS (used by tests/validate_cdp_tables)
# ─────────────────────────────────────────────

def align_columns(left, right):
    """Select right's columns in left's order (case-insensitive). Returns (left, right, report)."""
    lmap = {c.lower(): c for c in left.columns}
    rmap = {c.lower(): c for c in right.columns}
    ltypes = {f.name.lower(): f.dataType.simpleString() for f in left.schema.fields}
    rtypes = {f.name.lower(): f.dataType.simpleString() for f in right.schema.fields}
    common = [c for c in lmap if c in rmap]
    report = {
        "only_in_generated": [lmap[c] for c in lmap if c not in rmap],
        "only_in_reference": [rmap[c] for c in rmap if c not in lmap],
        "type_differences": {lmap[c]: (ltypes[c], rtypes[c]) for c in common if ltypes[c] != rtypes[c]},
    }
    return (left.select([F.col(f"`{lmap[c]}`") for c in common]),
            right.select([F.col(f"`{rmap[c]}`").alias(lmap[c]) for c in common]),
            report)


def reconcile(left, right, name=""):
    """Schema check, row counts and EXCEPT ALL in both directions."""
    l, r, report = align_columns(left, right)
    report.update({"table": name, "generated_rows": l.count(), "reference_rows": r.count()})
    report["generated_minus_reference"] = l.exceptAll(r).count()
    report["reference_minus_generated"] = r.exceptAll(l).count()
    report["exact_match"] = (not report["only_in_generated"] and not report["only_in_reference"]
                             and not report["type_differences"]
                             and report["generated_rows"] == report["reference_rows"]
                             and report["generated_minus_reference"] == 0
                             and report["reference_minus_generated"] == 0)
    return report


def checksum(df, group_col=None):
    """Order-independent fingerprint: row count + sum of a 64-bit row hash
    (null positions included). One scan, no shuffle of rows, so it scales to very
    large tables. Equal counts and hash sums give very high confidence (not a
    proof) that the row multisets match; use reconcile() for an exact check."""
    cols = [F.col(f"`{c}`") for c in df.columns]
    h = F.xxhash64(*cols, *[c.isNull() for c in cols]).cast("decimal(38,0)")
    aggs = [F.count(F.lit(1)).alias("rows"), F.sum(h).alias("hash_sum")]
    out = df.groupBy(group_col).agg(*aggs) if group_col else df.agg(*aggs)
    return {(r[0] if group_col else "ALL"): (r["rows"], r["hash_sum"]) for r in out.collect()}
