# Databricks notebook source
# DBTITLE 1,CDP Transformation mapping
# MAGIC %md
# MAGIC # CDP – Transformation mapping
# MAGIC Builds the CDP tables defined in `configuration/global/mapping.yaml` (PySpark DataFrame API). Runs interactively (widgets) or as a job Notebook task (job parameters).
# MAGIC
# MAGIC All parameters are required.
# MAGIC
# MAGIC | Job parameter | Meaning | Example |
# MAGIC | --- | --- | --- |
# MAGIC | env | dev / uat / prod, selects `configuration/env/<env>/env_params.yaml` | dev |
# MAGIC | source | marketscan / optum | marketscan |
# MAGIC | dataset | commercial / medicare / ses / dod | commercial |
# MAGIC | refresh | data refresh | 26q1 |
# MAGIC | athena_refresh | Athena vocabulary refresh | 26q2 |
# MAGIC | cdp_table_name | a table, a comma list, or `all` (= every table in mapping.yaml) | patient |
# MAGIC
# MAGIC The execution-log run id is the job run id, read from the notebook context (`interactive_<time>` outside a job).
# MAGIC
# MAGIC **Config:** `env/<env>/env_params.yaml` (only values that differ per environment, e.g. storage account), `global/schemas.yaml` (schema names, same in every environment: source, Athena prerequisite, qc, target), `global/mapping.yaml` (tables and columns). Every fixed name: `script/utilities/common_constants.py`.
# MAGIC
# MAGIC **Flow:** parameters -> load config -> resolve schemas -> build tables in dependency order (`helper.run`, intd_concept first) -> overwrite them in the qc schema (a CDP table that was not requested but is needed is reused if it exists) -> `execution_log` row -> task value `cdp_summary` + notebook exit value. Any error marks the execution log failed and fails the task.

# COMMAND ----------

# DBTITLE 1,Setup and imports
"""
Module Name: Transformation Mapping

Overview:
    Builds the CDP tables of one source / dataset / refresh from mapping.yaml,
    writes them to the qc schema and records the run in the execution log.

Inputs (job parameters, all required): env, source, dataset, refresh, athena_refresh, cdp_table_name
Configuration files: env/<env>/env_params.yaml, global/schemas.yaml, global/mapping.yaml
"""
import importlib
import json
import os
import sys
import traceback
from datetime import datetime

# Project root from this notebook's path ("/script/" is the only literal needed before
# common_constants can be imported).
try:
    current_path = os.path.abspath(__file__)          # .py file
except NameError:                                     # Databricks notebook
    current_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
    if not current_path.startswith("/Workspace"):
        current_path = "/Workspace" + current_path

project_root = current_path.split("/script/")[0]
for path in (f"{project_root}/script/code", f"{project_root}/script/utilities"):
    if path not in sys.path:
        sys.path.insert(0, path)

import common_constants as C
import execution_logger
import helper
import logger_utility
import yaml_utility
for module in (C, yaml_utility, logger_utility, execution_logger, helper):
    importlib.reload(module)

from execution_logger import ExecutionLogger
from logger_utility import Logger
from yaml_utility import YamlUtility

# COMMAND ----------

# DBTITLE 1,Job parameters
# -----------------------------------------------------------------------------
# Job parameters (all required)
# -----------------------------------------------------------------------------
existing_widgets = dbutils.widgets.getAll()
for name in C.TRANSFORMATION_MAPPING_WIDGETS:
    if name not in existing_widgets:
        dbutils.widgets.text(name, "", name)
params = {name: dbutils.widgets.get(name).strip() if dbutils.widgets.get(name) is not None else '' for name in C.TRANSFORMATION_MAPPING_WIDGETS}

missing = [name for name in C.TRANSFORMATION_MAPPING_WIDGETS if not params[name]]
if missing:
    raise ValueError(f"Missing required job parameter(s): {missing}")

ENV = params[C.WIDGET_ENV]
source = params[C.WIDGET_SOURCE]
dataset = params[C.WIDGET_DATASET]
refresh = params[C.WIDGET_REFRESH]
athena_refresh = params[C.WIDGET_ATHENA_REFRESH]
cdp_table_name = params[C.WIDGET_CDP_TABLE_NAME]

# Run id for the execution log: the job run id, or interactive_<time> outside a job
context = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().safeToJson())
attributes = context.get(C.CONTEXT_ATTRIBUTES_KEY, {})
run_id = (next((attributes[key] for key in C.CONTEXT_RUN_ID_KEYS if attributes.get(key)), None)
          or datetime.now().strftime(C.INTERACTIVE_RUN_ID))

data_pipeline_identifier = f"{source}_{dataset}_{refresh}"

# -----------------------------------------------------------------------------
# Logger setup
# -----------------------------------------------------------------------------
logger = Logger(
    C.TRANSFORMATION_MAPPING_STEP,
    C.LOGGER_LOC.format(pipeline=data_pipeline_identifier, step=C.TRANSFORMATION_MAPPING_STEP),
)
logger.info(f"Parameters: {params} | run_id={run_id}")

# COMMAND ----------

# DBTITLE 1,TransformationMapping class
class TransformationMapping:
    """
    Build the CDP tables of one source / dataset / refresh from mapping.yaml.

    Responsibilities:
        * Load env_params.yaml (this environment), schemas.yaml and mapping.yaml.
        * Resolve the fully qualified read / write schemas.
        * Select the requested tables (`all` = every table in mapping.yaml).
        * Build them in dependency order and overwrite each in its output schema
          (target -> qc schema, intermediate -> int schema; helper.run).
    """

    def __init__(self, spark, env, source, dataset, refresh, athena_refresh, logger):
        """Load the configuration and resolve schemas for one source/dataset/refresh.

        Args:
            spark: active SparkSession.
            env: dev | uat | prod; selects configuration/env/<env>/env_params.yaml.
            source, dataset: e.g. marketscan, commercial; select the block in schemas.yaml.
            refresh: source data refresh (e.g. 26q1).
            athena_refresh: Athena vocabulary refresh (e.g. 26q2).
            logger: Logger used for progress messages.
        """
        self.spark = spark
        self.logger = logger
        try:
            self.logger.info(f"Loading configurations for pipeline={source}_{dataset}_{refresh}")

            env_params = YamlUtility(env=env, conf_file=C.ENV_PARAMS_YAML)
            self.env_config = env_params.yaml_configuration
            self.schema_config = YamlUtility(conf_file=C.SCHEMAS_YAML).yaml_configuration
            self.tables = helper.mapping_tables(
                YamlUtility(conf_file=C.MAPPING_YAML).get_configuration([C.VAR_MAPPING_TABLES]))

            storage_account = env_params.get_configuration([C.VAR_STORAGE_ACCOUNT])
            self.schemas = helper.resolve_schemas(self.schema_config, source, dataset, refresh,
                                                  athena_refresh, storage_account)
            self.routing = helper.prerequisite_routing(self.schema_config)

            for key, schema in self.schemas.items():
                self.logger.info(f"{key:<20}= {schema}")
            self.logger.info("All configurations loaded successfully.")
        except Exception:
            self.logger.error(f"Failed to initialize TransformationMapping: {traceback.format_exc()}")
            raise

    def get_requested_tables(self, cdp_table_name):
        """Tables to build: `all` (every table in mapping.yaml) or a comma list."""
        if cdp_table_name == C.ALL_TABLES:
            return list(self.tables)
        requested = [t.strip() for t in cdp_table_name.split(C.LIST_SEPARATOR) if t.strip()]
        unknown = [t for t in requested if t not in self.tables]
        if unknown:
            raise ValueError(f"Unknown cdp_table_name {unknown}. Available: {list(self.tables)}")
        return requested

    def perform_transformation(self, requested_tables):
        """Build and overwrite the requested tables. Returns the run summary."""
        self.logger.info(f"Tables selected: {requested_tables}")
        return helper.run(self.spark, self.tables, self.routing, self.schemas,
                          table=C.LIST_SEPARATOR.join(requested_tables), log=self.logger.info)

# COMMAND ----------

# DBTITLE 1,Run (entry point)
# -----------------------------------------------------------------------------
# Entry point
# -----------------------------------------------------------------------------
step_name = f"{C.TRANSFORMATION_MAPPING_STEP}_{cdp_table_name}"
transformation = TransformationMapping(spark, ENV, source, dataset, refresh, athena_refresh, logger)
requested_tables = transformation.get_requested_tables(cdp_table_name)

# execution log lives in the intermediate schema
int_schema = transformation.schemas[C.INT_SCHEMA]
helper.create_schema_if_not_exists(spark, int_schema, transformation.schemas[C.INT_LOCATION], logger.info)
execution_log = ExecutionLogger(database=int_schema, table=C.VAR_LOG_TABLE_NAME, spark=spark)
execution_log.terminate_current_execution(run_id)
execution_log_id = execution_log.create_new_log(
    run_id=run_id, pipeline_name=data_pipeline_identifier,
    step_name=step_name, status=C.Status.IN_PROGRESS)
logger.info(f"Execution log created: id={execution_log_id} | step={step_name}")

try:
    logger.info(f"Starting transformation mapping pipeline={data_pipeline_identifier} | "
                f"cdp_table_name={cdp_table_name}")
    summary = transformation.perform_transformation(requested_tables)
    execution_log.update_log(id=execution_log_id, status=C.Status.COMPLETE,
                             output=json.dumps(summary, default=str))
    execution_log.terminate_current_execution(run_id)
    logger.info(f"Transformation mapping completed: {summary}")
except Exception as exc:
    logger.error(f"Transformation mapping failed: {traceback.format_exc()}")
    execution_log.update_log(id=execution_log_id, status=C.Status.FAILED, error=str(exc))
    execution_log.terminate_current_execution(run_id)
    raise

# COMMAND ----------

# DBTITLE 1,Publish result
# Result: task value for downstream job tasks (dbutils.jobs.taskValues.get) and notebook exit value
result = json.dumps({C.ResultKey.STATUS: C.Status.COMPLETE, C.ResultKey.PIPELINE: data_pipeline_identifier,
                     C.ResultKey.RUN_ID: run_id, C.ResultKey.SUMMARY: summary}, default=str)
try:
    dbutils.jobs.taskValues.set(key=C.TASK_VALUE_SUMMARY, value=json.loads(result))
except Exception as exc:  # not running inside a job
    logger.warning(f"Task value not set: {type(exc).__name__}")
dbutils.notebook.exit(result)