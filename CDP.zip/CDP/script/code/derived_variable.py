# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# DBTITLE 1,CDP Derived variable
# MAGIC %md
# MAGIC # CDP – Derived table
# MAGIC Builds one derived table from the static CDP tables, driven by the business user's product config Excel (PySpark DataFrame API). Runs interactively (widgets) or as a job Notebook task (job parameters).
# MAGIC
# MAGIC All parameters are required.
# MAGIC
# MAGIC | Job parameter | Meaning | Example |
# MAGIC | --- | --- | --- |
# MAGIC | env | dev / uat / prod, selects `configuration/env/<env>/env_params.yaml` | dev |
# MAGIC | config_file_path | product config Excel (Volume or Workspace path) | /Volumes/.../product1_config.xlsx |
# MAGIC
# MAGIC Dataset, refresh and run mode come from the Excel `[RUN_SETTINGS]`; the domains from `[EXPORT_COLUMNS]` (Include = Y).
# MAGIC `[DERIVED_VARIABLES]` is read and logged; its calculations are not built yet (skipped).
# MAGIC
# MAGIC **Rules:** event domains are filtered from the event table on `event_type`; cost not selected → one row per (event_id, event_type); cost selected → one row per (event_id, event_type, cost_id). Demographic / location / payer_plan_period are taken as they are.
# MAGIC
# MAGIC **Output:** one long table (`domain` column + the selected domains' columns), written to the qc schema: run mode New → `{source}_{dataset}_{refresh}_derived_<timestamp>`, Update → the table in `previous_derived_table_name` (overwritten).
# MAGIC
# MAGIC **Config:** `env/<env>/env_params.yaml`, `global/schemas.yaml`, `global/attribute_grouping.yaml`, `global/derived_variable.yaml`. Every fixed name: `script/utilities/common_constants.py`.

# COMMAND ----------

# DBTITLE 1,Install dependencies
# MAGIC %pip install openpyxl

# COMMAND ----------

# DBTITLE 1,Setup and imports
"""
Module Name: Derived Variable

Overview:
    Reads the product config Excel, picks the selected domains' columns (attribute_grouping.yaml)
    from the static CDP tables, applies the event / cost rule, writes one long derived table to
    the qc schema and records the run in the execution log.

Inputs (job parameters, all required): env, config_file_path
Configuration files: env/<env>/env_params.yaml, global/schemas.yaml,
                     global/attribute_grouping.yaml, global/derived_variable.yaml
"""
import importlib
import json
import os
import sys
import traceback
from datetime import datetime

# Project root from this notebook's path ("/script/" is the only literal needed before
# common_constants can be imported).
try:
    current_path = os.path.abspath(__file__)          # .py file
except NameError:                                     # Databricks notebook
    current_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
    if not current_path.startswith("/Workspace"):
        current_path = "/Workspace" + current_path

project_root = current_path.split("/script/")[0]
for path in (f"{project_root}/script/code", f"{project_root}/script/utilities"):
    if path not in sys.path:
        sys.path.insert(0, path)

import common_constants as C
import derived_helper
import execution_logger
import helper
import logger_utility
import product_config_reader
import yaml_utility
for module in (C, yaml_utility, logger_utility, execution_logger, product_config_reader, helper, derived_helper):
    importlib.reload(module)

from execution_logger import ExecutionLogger
from logger_utility import Logger
from product_config_reader import read_product_config
from yaml_utility import YamlUtility

# COMMAND ----------

# DBTITLE 1,Parameter widgets
# Create the parameter widgets (empty) so they appear at the top of the notebook.
# Fill them in, then run the remaining cells. In a job, job parameters populate them.
existing_widgets = dbutils.widgets.getAll()
for name in C.DERIVED_VARIABLE_WIDGETS:
    if name not in existing_widgets:
        dbutils.widgets.text(name, "", name)
print(f"Widgets ready: {list(C.DERIVED_VARIABLE_WIDGETS)}")

# COMMAND ----------

# DBTITLE 1,Job parameters and product config
# -----------------------------------------------------------------------------
# Job parameters (all required)
# -----------------------------------------------------------------------------
existing_widgets = dbutils.widgets.getAll()
for name in C.DERIVED_VARIABLE_WIDGETS:
    if name not in existing_widgets:
        dbutils.widgets.text(name, "", name)
params = {name: (dbutils.widgets.get(name) or "").strip() for name in C.DERIVED_VARIABLE_WIDGETS}

missing = [name for name in C.DERIVED_VARIABLE_WIDGETS if not params[name]]
if missing:
    raise ValueError(f"Missing required job parameter(s): {missing}")

ENV = params[C.WIDGET_ENV]
config_file_path = params[C.WIDGET_CONFIG_FILE_PATH]

# Run id for the execution log: the job run id, or interactive_<time> outside a job
context = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().safeToJson())
attributes = context.get(C.CONTEXT_ATTRIBUTES_KEY, {})
run_id = (next((attributes[key] for key in C.CONTEXT_RUN_ID_KEYS if attributes.get(key)), None)
          or datetime.now().strftime(C.INTERACTIVE_RUN_ID))

# -----------------------------------------------------------------------------
# Product config Excel (raises listing every problem) -> dataset / refresh
# -----------------------------------------------------------------------------
product_config = read_product_config(config_file_path)
derived_config = YamlUtility(conf_file=C.DERIVED_VARIABLE_YAML).yaml_configuration
source, dataset = derived_helper.dataset_for(derived_config.get(C.VAR_DATASET_LOOKUP),
                                             product_config.dataset_name)
refresh = product_config.refresh
data_pipeline_identifier = f"{source}_{dataset}_{refresh}"

# -----------------------------------------------------------------------------
# Logger setup
# -----------------------------------------------------------------------------
logger = Logger(
    C.DERIVED_VARIABLE_STEP,
    C.LOGGER_LOC.format(pipeline=data_pipeline_identifier, step=C.DERIVED_VARIABLE_STEP),
)
logger.info(f"Parameters: {params} | run_id={run_id}")
logger.info(f"Product config: {product_config.describe()}")

# COMMAND ----------

# DBTITLE 1,DerivedVariable class
class DerivedVariable:
    """
    Build the derived table of one product config from the static CDP tables.

    Responsibilities:
        * Load env_params.yaml, schemas.yaml, attribute_grouping.yaml and derived_variable.yaml.
        * Resolve the read (static tables) and write (derived table) schemas.
        * Check the selection and the static tables, build the long table, write it.
    """

    def __init__(self, spark, env, product_config, derived_config, source, dataset, logger):
        """Load the configuration and resolve schemas.

        Args:
            spark: active SparkSession.
            env: dev | uat | prod; selects configuration/env/<env>/env_params.yaml.
            product_config: ProductConfig read from the Excel.
            derived_config: derived_variable.yaml content.
            source, dataset: schemas.yaml block (from dataset_lookup).
            logger: Logger used for progress messages.
        """
        self.spark = spark
        self.logger = logger
        self.config = product_config
        try:
            env_params = YamlUtility(env=env, conf_file=C.ENV_PARAMS_YAML)
            schema_config = YamlUtility(conf_file=C.SCHEMAS_YAML).yaml_configuration
            self.domains = derived_helper.attribute_domains(
                YamlUtility(conf_file=C.ATTRIBUTE_GROUPING_YAML).get_configuration([C.VAR_DOMAIN, C.VAR_DOMAIN_LIST]))
            self.settings = derived_helper.table_settings(derived_config.get(C.VAR_DERIVED_TABLE))
            self.rules = derived_helper.event_settings(derived_config.get(C.VAR_EVENT_RULES))

            self.source, self.dataset, self.refresh = source, dataset, product_config.refresh
            storage_account = env_params.get_configuration([C.VAR_STORAGE_ACCOUNT])
            self.schemas = helper.resolve_schemas(schema_config, source, dataset, self.refresh,
                                                  C.ATHENA_REFRESH_NOT_USED, storage_account)
            self.read_schema = self.schemas[self.settings[C.VAR_READ_SCHEMA]]
            self.write_key = self.settings[C.VAR_WRITE_SCHEMA]
            self.write_schema = self.schemas[self.write_key]
            self.logger.info(f"read schema  = {self.read_schema}")
            self.logger.info(f"write schema = {self.write_schema}")
            self.logger.info("All configurations loaded successfully.")
        except Exception:
            self.logger.error(f"Failed to initialize DerivedVariable: {traceback.format_exc()}")
            raise

    def output_table(self):
        """Fully qualified derived table: New -> new timestamped name, Update -> the existing table's name."""
        if self.config.run_mode == C.RUN_MODE_UPDATE:
            # The existing derived table is the promoted one (read schema = target). The new version
            # goes to the write schema (qc) under the same name; promote then replaces the target copy.
            existing, table = derived_helper.previous_table(self.config.previous_derived_table_name,
                                                            self.read_schema)
            if not self.spark.catalog.tableExists(existing):
                raise ValueError(f"run_mode Update: {existing} does not exist")
            self.logger.info(f"run_mode Update: {existing} will be replaced")
        else:
            table = derived_helper.new_table_name(self.settings, self.source, self.dataset, self.refresh)
        return f"{self.write_schema}.{table}"

    def build(self):
        """Build the derived table as a DataFrame. Returns (DataFrame, plan, applied, skipped)."""
        domain_column = self.settings[C.VAR_DOMAIN_COLUMN]
        plan = derived_helper.selection_plan(self.config.selected_domains, self.domains, self.rules)
        self.logger.info(f"Selection: {plan}")
        derived_helper.check_tables(self.spark, self.read_schema,
                                    derived_helper.required_tables(plan, self.domains, self.rules))

        frames = []
        for d in self.config.selected_domains:
            if d in plan["other_domains"]:
                columns = [c for c, _ in self.domains[d]]
                table = self.domains[d][0][1]
                self.logger.info(f"[{d}] {self.read_schema}.{table}: {len(columns)} columns")
                frames.append((d, derived_helper.domain_frame(self.spark.table(f"{self.read_schema}.{table}"),
                                                              d, columns, domain_column)))
        if plan["event_domains"]:
            event_table = f"{self.read_schema}.{self.rules[C.VAR_CDP_SOURCE]}"
            df, key = derived_helper.event_frame(self.spark.table(event_table), plan, self.rules, domain_column)
            self.logger.info(f"[event] {event_table}: domains {plan['event_domains']}, "
                             f"cost {'selected' if plan['cost_selected'] else 'not selected (deduplicated)'}, "
                             f"key {key}, {len(plan['event_columns'])} columns")
            frames.append(("event", df))

        result = derived_helper.long_table(frames, domain_column, self.settings[C.VAR_LEAD_COLUMNS])
        result, applied, skipped = derived_helper.apply_derived_variables(
            result, self.config.requested_derived_variables, context=self, log=self.logger.warning)
        return result, plan, applied, skipped

    def run(self):
        """Build and overwrite the derived table. Returns the run summary."""
        target = self.output_table()
        helper.create_schema_if_not_exists(self.spark, self.write_schema,
                                           self.schemas.get(derived_helper.SCHEMA_LOCATION[self.write_key]),
                                           self.logger.info)
        df, plan, applied, skipped = self.build()
        self.logger.info(f"Writing {target}")
        helper.write_table(df, target)
        rows = self.spark.table(target).count()
        self.logger.info(f"Written: {target} ({rows:,} rows)")
        K = C.DerivedSummaryKey
        return {
            K.CONFIG_FILE: self.config.path,
            K.DATASET_NAME: self.config.dataset_name,
            K.RUN_MODE: self.config.run_mode,
            K.TABLE: target,
            K.ROWS: rows,
            K.DOMAINS: self.config.selected_domains,
            K.COST_SELECTED: plan["cost_selected"],
            K.EVENT_KEY: plan["event_key"],
            K.DERIVED_APPLIED: applied,
            K.DERIVED_SKIPPED: skipped,
        }

# COMMAND ----------

# DBTITLE 1,Run (entry point)
# -----------------------------------------------------------------------------
# Entry point
# -----------------------------------------------------------------------------
step_name = C.DERIVED_VARIABLE_STEP
derived = DerivedVariable(spark, ENV, product_config, derived_config, source, dataset, logger)

# execution log lives in the intermediate schema
int_schema = derived.schemas[C.INT_SCHEMA]
helper.create_schema_if_not_exists(spark, int_schema, derived.schemas[C.INT_LOCATION], logger.info)
execution_log = ExecutionLogger(database=int_schema, table=C.VAR_LOG_TABLE_NAME, spark=spark)
execution_log.terminate_current_execution(run_id)
execution_log_id = execution_log.create_new_log(
    run_id=run_id, pipeline_name=data_pipeline_identifier,
    step_name=step_name, status=C.Status.IN_PROGRESS)
logger.info(f"Execution log created: id={execution_log_id} | step={step_name}")

try:
    logger.info(f"Starting derived table build pipeline={data_pipeline_identifier}")
    summary = derived.run()
    execution_log.update_log(id=execution_log_id, status=C.Status.COMPLETE,
                             output=json.dumps(summary, default=str))
    execution_log.terminate_current_execution(run_id)
    logger.info(f"Derived table completed: {summary}")
except Exception as exc:
    logger.error(f"Derived table failed: {traceback.format_exc()}")
    execution_log.update_log(id=execution_log_id, status=C.Status.FAILED, error=str(exc))
    execution_log.terminate_current_execution(run_id)
    raise

# COMMAND ----------

# DBTITLE 1,Publish result
# Result: task value for downstream job tasks (dbutils.jobs.taskValues.get) and notebook exit value
result = json.dumps({C.ResultKey.STATUS: C.Status.COMPLETE, C.ResultKey.PIPELINE: data_pipeline_identifier,
                     C.ResultKey.RUN_ID: run_id, C.ResultKey.SUMMARY: summary}, default=str)
try:
    dbutils.jobs.taskValues.set(key=C.TASK_VALUE_SUMMARY, value=json.loads(result))
except Exception as exc:  # not running inside a job
    logger.warning(f"Task value not set: {type(exc).__name__}")
dbutils.notebook.exit(result)