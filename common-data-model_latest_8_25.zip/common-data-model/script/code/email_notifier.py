# Databricks notebook source
# DBTITLE 1,Cell 1

"""
Module Name: Email Notifier

Overview:
    This module collects pipeline execution logs and QC results, builds CSV
    attachments, and sends an email notification for the current pipeline run.

Inputs:
    Databricks widgets:
        * pipeline_status
        * env
        * source_name
        * dataset_name
        * refresh
        * pipeline_name
        * run_id
        * trigger_time
        * sender_email
        * receiver_email

Outputs:
    * Email notification with optional CSV attachments:
        1. execution_log_<pipeline>.csv
        2. achilles_result_<pipeline>.csv
        3. achilles_result_dist_<pipeline>.csv
        4. dqd_qc_results_<pipeline>.csv
        5. custom_qc_results_<pipeline>.csv
"""

import os
import sys
from datetime import datetime, timezone

try:
    current_path = os.path.abspath(__file__)
except NameError:
    current_path = (
        dbutils.notebook.entry_point
        .getDbutils()
        .notebook()
        .getContext()
        .notebookPath()
        .get()
    )

    if not current_path.startswith("/Workspace"):
        current_path = "/Workspace" + current_path

project_root = current_path.split("/script/")[0]

code_path = project_root + "/script/code"
utilities_path = project_root + "/script/utilities"

if code_path not in sys.path:
    sys.path.append(code_path)

if utilities_path not in sys.path:
    sys.path.append(utilities_path)

from databricks.sdk.runtime import dbutils

from common_constants import *
from email_utility import (
    get_achilles_result_dist_csv,
    get_custom_csv,
    get_dqd_csv,
    get_log_csv,
    send_email,
)
from yaml_utility import YamlUtility


def main():
    """Collect run details and send the pipeline completion email."""

    pipeline_status = dbutils.widgets.get(WIDGET_PIPELINE_STATUS)
    env = dbutils.widgets.get(WIDGET_ENV)
    source_name = dbutils.widgets.get(WIDGET_SOURCE_NAME)
    dataset_name = dbutils.widgets.get(WIDGET_DATASET_NAME)
    refresh = dbutils.widgets.get(WIDGET_REFRESH)
    pipeline_name = dbutils.widgets.get(WIDGET_PIPELINE_NAME)
    run_id = dbutils.widgets.get(WIDGET_RUN_ID)
    trigger_time = dbutils.widgets.get(WIDGET_TRIGGER_TIME)
    sender_email = dbutils.widgets.get(WIDGET_SENDER_EMAIL)
    receiver_email = dbutils.widgets.get(WIDGET_RECEIVER_EMAIL)
    qc_passed = dbutils.widgets.get(WIDGET_QC_PASSED)

    promotion_done = qc_passed.strip().lower() == BOOLEAN_TRUE

    data_pipeline_identifier = (
        f"{source_name}_{dataset_name}_{refresh}"
    )

    target_yaml = YamlUtility(
        conf_file=TARGET_SCHEMA_YAML,
    ).yaml_configuration

    target_data = target_yaml[source_name][dataset_name]

    intermediate_data_catalog = target_data.get(
        VAR_INTERMEDIATE_DATA_CATALOG
    )

    intermediate_data_db = (
        target_data[VAR_INTERMEDIATE_DATA_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
        .replace(REFRESH_TOKEN, refresh)
    )

    qc_data_catalog = target_data.get(
        VAR_QC_TABLE_CATALOG
    )

    output_qc_db = (
        target_data[VAR_QC_OUTPUT_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
        .replace(REFRESH_TOKEN, refresh)
    )

    target_data_catalog = target_data.get(
        VAR_TARGET_DATA_CATALOG
    )

    target_data_db = (
        target_data[VAR_TARGET_DATA_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
        .replace(REFRESH_TOKEN, refresh)
    )

    # Refresh-less "latest" view schema. The promotion step creates views
    # here (mirroring the promoted tables) so downstream users can query
    # the latest data without knowing the refresh. Built by dropping the
    # "_{refresh}" suffix from the target schema template.
    target_view_db = (
        target_data[VAR_TARGET_DATA_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
        .replace(f"_{REFRESH_TOKEN}", "")
    )

    # When promotion has run (qc_passed=true), the QC result tables have
    # been moved to the target schema and dropped from the QC schema. We
    # surface the refresh-less view schema (latest views) so recipients get
    # a stable, refresh-agnostic location. Otherwise (QC failed, promotion
    # skipped) the tables are still in the QC schema.
    if promotion_done:
        qc_read_catalog = target_data_catalog
        qc_read_db = target_view_db
    else:
        qc_read_catalog = qc_data_catalog
        qc_read_db = output_qc_db

    # The full achilles_results table (referenced by URL in the email body)
    # follows the same rule as the CSVs above.
    achilles_result_table = (
        f"{qc_read_catalog}."
        f"{qc_read_db}."
        f"{VAR_QC_ACHILLES_RESULT}"
    )

    log_csv = get_log_csv(
        spark=spark,
        catalog=intermediate_data_catalog,
        intermediate_data_db=intermediate_data_db,
        run_id=run_id,
    )

    achilles_result_dist_csv = get_achilles_result_dist_csv(
        spark=spark,
        catalog=qc_read_catalog,
        output_qc_db=qc_read_db,
    )

    dqd_csv = get_dqd_csv(
        spark=spark,
        catalog=qc_read_catalog,
        output_qc_db=qc_read_db,
    )

    custom_csv = get_custom_csv(
        spark=spark,
        catalog=qc_read_catalog,
        output_qc_db=qc_read_db,
    )

    completion_time = datetime.now(
        timezone.utc
    ).strftime(DATETIME_FORMAT)

    send_email(
        status=pipeline_status,
        data_pipeline_identifier=data_pipeline_identifier,
        env=env,
        pipeline_name=pipeline_name,
        run_id=run_id,
        trigger_time=trigger_time,
        completion_time=completion_time,
        sender_email=sender_email,
        receiver_email=receiver_email,
        log_csv=log_csv,
        achilles_result_dist_csv=achilles_result_dist_csv,
        achilles_result_table=achilles_result_table,
        dqd_csv=dqd_csv,
        custom_csv=custom_csv,
    )


main()
