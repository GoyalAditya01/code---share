"""
File Name: Helper

Overview:
    Shared helper functions for the common data model pipeline.

Responsibilities:
    * Map YAML data types to PySpark data types.
    * Build `StructType` definitions from YAML column metadata.
    * Serialize schema and execution errors for logging.
    * Replace source, prerequisite, reference, target, and prior-check-output
      table aliases in SQL (unified resolver + backward-compatible wrappers).
    * Create and populate the QC result table.
    * Promote QC tables to the final target schema.
    * Parse transformation ID widget input.
"""

import json
import re
import sys
import traceback
from datetime import datetime, timezone
from databricks.sdk.runtime import dbutils
from pyspark.sql.types import (
    BooleanType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    ShortType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

import os

try:
    # For .py files
    current_path = os.path.abspath(__file__)
except NameError:
    # For Databricks notebooks
    current_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

    if not current_path.startswith("/Workspace"):
        current_path = "/Workspace" + current_path

project_root = current_path.split("/script/")[0]

code_path = project_root + "/script/code"
utilities_path = project_root + "/script/utilities"

if code_path not in sys.path:
    sys.path.append(code_path)

if utilities_path not in sys.path:
    sys.path.append(utilities_path)

from common_constants import *
from execution_logger import ExecutionLogger
from logger_utility import Logger
from yaml_utility import YamlUtility

# -----------------------------------------------------------------------------
# Schema helpers
# -----------------------------------------------------------------------------
def map_yaml_type_to_spark(type_str):
    """
    Map a YAML column type string to a PySpark data type.

    Args:
        type_str: Column type string from YAML configuration.

    Returns:
        pyspark.sql.types.DataType: Matching PySpark data type. Defaults to
        `StringType()` when the input type is unknown.
    """
    type_str = type_str.lower().strip()

    if type_str.startswith("decimal"):
        try:
            parts = type_str.replace("decimal(", "").replace(")", "").split(",")
            precision = int(parts[0].strip())
            scale = int(parts[1].strip()) if len(parts) > 1 else 0
            return DecimalType(precision, scale)
        except Exception:
            return DecimalType(18, 2)

    type_map = {
        "string": StringType(),
        "varchar": StringType(),
        "char": StringType(),
        "text": StringType(),
        "int": IntegerType(),
        "integer": IntegerType(),
        "bigint": LongType(),
        "long": LongType(),
        "smallint": ShortType(),
        "short": ShortType(),
        "float": FloatType(),
        "double": DoubleType(),
        "date": DateType(),
        "timestamp": TimestampType(),
        "datetime": TimestampType(),
        "boolean": BooleanType(),
        "bool": BooleanType(),
    }
    return type_map.get(type_str, StringType())


def build_structtype_from_yaml(columns):
    """
    Convert YAML column metadata into a PySpark `StructType`.

    Args:
        columns: List of column dictionaries from YAML.

    Returns:
        StructType: Spark schema built from the provided column metadata.
    """
    fields = []
    for col in columns:
        spark_type = map_yaml_type_to_spark(col["type"])
        nullable = col.get("nullable", True)
        fields.append(StructField(col["name"].lower(), spark_type, nullable))
    return StructType(fields)


# -----------------------------------------------------------------------------
# Log helpers
# -----------------------------------------------------------------------------
def serialize_log_error(error_details):
    """
    Serialize structured error details for execution-log storage.

    Args:
        error_details: Error structure to serialize.

    Returns:
        str | None: JSON string when error details are present, otherwise None.
    """
    if not error_details:
        return None
    return json.dumps(error_details, default=str)


def extract_schema_error_details(table_name, full_table_name, result_dict):
    """
    Extract only the failed schema validation details for logging.

    Args:
        table_name: Logical table name.
        full_table_name: Fully qualified table name.
        result_dict: Full schema validation result dictionary.

    Returns:
        dict | None: Filtered error details when any validation failed,
        otherwise None.
    """
    error_details = {
        SchemaErrorKey.TABLE_NAME: table_name,
        SchemaErrorKey.FULL_TABLE_NAME: full_table_name,
    }

    if result_dict.get(SCHEMA_RESULT_TABLE_EXISTS) == Status.FAILED:
        error_details[SchemaErrorKey.TABLE_EXISTS] = "Table not found"

    for key in [
        SCHEMA_RESULT_MISSING_COLUMNS,
        SCHEMA_RESULT_EXTRA_COLUMNS,
        SCHEMA_RESULT_TYPE_MISMATCH,
        SCHEMA_RESULT_NOT_NULL_CHECK,
    ]:
        value = result_dict.get(key)
        if value not in (None, [], {}):
            error_details[key] = value

    return error_details if len(error_details) > 2 else None


# -----------------------------------------------------------------------------
# Query helpers
# -----------------------------------------------------------------------------
def replace_aliases(
    query,
    target_table_list=None,
    qc_data_catalog=None,
    qc_data_db=None,
    source_table_list=None,
    source_data_catalog=None,
    source_data_db=None,
    prereq_table_list=None,
    prereq_data_catalog=None,
    prereq_data_db=None,

    prereq_lookup_table_list=None,
    prereq_lookup_data_catalog=None,
    prereq_lookup_data_db=None,

    reference_data_list=None,
    intermediate_data_catalog=None,
    intermediate_data_db=None,
    check_id_to_table=None,
    logger=None,
):
    """
    Unified alias resolver for DQ (dqd/custom) and transformation SQL.

    Resolves the following alias families. Each is entirely optional and is
    simply skipped when its corresponding table list is not supplied, so
    callers only need to pass what they actually use:

        * tgt_tbl_N  -> target_table_list    (target/final tables)
        * src_tbl_N  -> source_table_list    (source tables)
        * pre_req_tbl_N  -> prereq_table_list    (prerequisite / vocabulary tables)
        * ref_ctl_C_sch_S_tbl_T  -> reference_data_list (reference tables)
        * chk_tbl_N  -> check_id_to_table    (a prior QC check's output table)

    Intermediate-table handling for tgt_tbl_N:
        A tgt_tbl_N alias that resolves to an INTERMEDIATE-type table is
        handled based on whether `intermediate_data_catalog` was supplied:
            * NOT supplied (target QC callers: dqd/custom) -> raises
              ValueError. Intermediate tables must never be referenced from
              a target QC check - this matches the same boundary already
              enforced in target schema-check and promotion (both skip
              intermediate tables entirely).
            * Supplied (transformation callers) -> the alias is resolved
              against the intermediate catalog/db instead of the qc
              catalog/db, since transformation SQL legitimately reads and
              writes intermediate tables.

    Args:
        query: SQL text containing alias placeholders.
        target_table_list: Target table metadata (list of dicts), or None.
        qc_data_catalog: Catalog for resolved non-intermediate target aliases.
        qc_data_db: Database for resolved non-intermediate target aliases.
        source_table_list: Source table metadata, or None.
        source_data_catalog: Catalog for resolved source aliases.
        source_data_db: Database for resolved source aliases.
        prereq_table_list: Prerequisite table metadata, or None.
        prereq_data_catalog: Catalog for resolved prerequisite aliases.
        prereq_data_db: Database for resolved prerequisite aliases.
        reference_data_list: Grouped reference metadata (list of dicts, each
            with reference_data_id, reference_data_catalog, reference_data_db
            and reference_table_list). Resolves
            ref_ctl_<C>_sch_<S>_tbl_<T> composite aliases.
        intermediate_data_catalog: Catalog for intermediate-type target
            tables. See "Intermediate-table handling" above.
        intermediate_data_db: Database for intermediate-type target tables.
        check_id_to_table: Optional dict of check_id -> fully qualified
            table name, used to resolve chk_tbl_N references to a prior
            check's output table.
        logger: Optional logger for alias replacement messages.

    Returns:
        str: Query with all applicable aliases replaced by fully qualified
        table names.

    Raises:
        ValueError: If a tgt_tbl_N alias resolves to an INTERMEDIATE-type
            table and no intermediate catalog/db was supplied.
    """

    def _resolve(table_list, prefix, id_key, name_key, catalog, database):
        nonlocal query
        for item in table_list or []:
            alias = prefix + str(item[id_key])
            pattern = fr"\b{re.escape(alias)}\b"

            if not re.search(pattern, query):
                continue

            if not catalog or not database:
                raise ValueError(
                    f"Unable to resolve alias '{alias}' for table "
                    f"'{item[name_key]}'. Catalog and schema are required. "
                    f"catalog={catalog}, schema={database}"
                )

            full_name = f"{catalog}.{database}.{item[name_key]}"
            query = re.sub(pattern, lambda _: full_name, query)

            if logger:
                logger.info(f"Replaced {alias} -> {full_name}")

    # --- Target aliases (tgt_tbl_N) - special-cased for intermediate tables.
    for item in target_table_list or []:
        alias = VAR_PREFIX_TGT_TBL_ALIAS + str(item[VAR_TARGET_TABLE_ID])
        pattern = fr"\b{re.escape(alias)}\b"

        if not re.search(pattern, query):
            continue

        if item[VAR_TARGET_TABLE_TYPE] == INTERMEDIATE_TABLE_TYPE:
            catalog = intermediate_data_catalog
            database = intermediate_data_db
            location_type = "intermediate"
        else:
            catalog = qc_data_catalog
            database = qc_data_db
            location_type = "QC target"

        if not catalog or not database:
            raise ValueError(
                f"Unable to resolve alias '{alias}' for table "
                f"'{item[VAR_TARGET_TABLE_NAME]}'. "
                f"The {location_type} catalog and schema are required. "
                f"catalog={catalog}, schema={database}"
            )

        full_name = f"{catalog}.{database}.{item[VAR_TARGET_TABLE_NAME]}"
        query = re.sub(pattern, lambda _: full_name, query)

        if logger:
            logger.info(f"Replaced {alias} -> {full_name}")

    # --- Source aliases (src_tbl_N).
    _resolve(
        source_table_list, VAR_PREFIX_SRC_TBL_ALIAS,
        VAR_SRC_TABLE_ID, VAR_SRC_TABLE_NAME,
        source_data_catalog, source_data_db,
    )

    # --- Prerequisite aliases (pre_req_tbl_N).
    _resolve(
        prereq_table_list, VAR_PREFIX_PREREQ_TBL_ALIAS,
        VAR_PREREQ_TABLE_ID, VAR_PREREQ_TABLE_NAME,
        prereq_data_catalog, prereq_data_db,
    )

    # --- Prerequisite lookup aliases (pre_lkp_tbl_N).
    _resolve(
        prereq_lookup_table_list,
        VAR_PREFIX_PREREQ_LOOKUP_TBL_ALIAS,
        VAR_PREREQ_LOOKUP_TABLE_ID,
        VAR_PREREQ_LOOKUP_TABLE_NAME,
        prereq_lookup_data_catalog,
        prereq_lookup_data_db,
    )

    # --- Reference aliases.
    if reference_data_list:
        # New multi-group style. A single composite token carries the full
        # coordinates of a reference table and resolves to one fully qualified
        # catalog.database.table name:
        #
        #     ref_ctl_<ctl_group>_sch_<sch_group>_tbl_<ref_table_id>
        #
        # where:
        #   * <ctl_group> = reference_data_id whose reference_data_catalog is used
        #   * <sch_group> = reference_data_id whose reference_data_db is used
        #   * <ref_table_id> = ref_table_id within the schema group
        #
        # Example: ref_ctl_2_sch_2_tbl_1 ->
        #          dvmt_rwem.rwd_marketscan_commercial_claims_ref.redbook
        groups_by_id = {
            group[VAR_REFERENCE_DATA_ID]: group
            for group in reference_data_list
        }

        composite_pattern = re.compile(
            fr"\b{VAR_PREFIX_REFERENCE_CTL_ALIAS}(\d+)"
            fr"_sch_(\d+)"
            fr"_tbl_(\d+)\b"
        )

        def _resolve_reference_token(match):
            ctl_group_id = int(match.group(1))
            sch_group_id = int(match.group(2))
            table_id = int(match.group(3))

            ctl_group = groups_by_id.get(ctl_group_id)
            sch_group = groups_by_id.get(sch_group_id)

            if ctl_group is None or sch_group is None:
                raise ValueError(
                    f"Unable to resolve reference alias '{match.group(0)}'. "
                    f"reference_data_id not found. "
                    f"ctl_group={ctl_group_id}, sch_group={sch_group_id}. "
                    f"Available groups: {sorted(groups_by_id)}"
                )

            catalog = ctl_group.get(VAR_REFERENCE_DATA_CATALOG)
            database = sch_group.get(VAR_REFERENCE_DATA_DB)

            table_name = next(
                (
                    item[VAR_REFERENCE_TABLE_NAME]
                    for item in sch_group.get(VAR_REFERENCE_TABLE_LIST, []) or []
                    if item[VAR_REFERENCE_TABLE_ID] == table_id
                ),
                None,
            )

            if not catalog or not database or not table_name:
                raise ValueError(
                    f"Unable to resolve reference alias '{match.group(0)}'. "
                    f"catalog={catalog}, database={database}, "
                    f"table_name={table_name} (ref_table_id={table_id} in "
                    f"reference_data_id={sch_group_id})."
                )

            full_name = f"{catalog}.{database}.{table_name}"

            if logger:
                logger.info(f"Replaced {match.group(0)} -> {full_name}")

            return full_name

        query = composite_pattern.sub(_resolve_reference_token, query)

    # --- Prior-check output aliases (chk_tbl_N) - QC only.
    if check_id_to_table:
        for cid, tname in check_id_to_table.items():
            pattern = fr"\bchk_tbl_{cid}\b"

            if not re.search(pattern, query):
                continue

            query = re.sub(pattern, tname, query)

            if logger:
                logger.info(f"Replaced chk_tbl_{cid} -> {tname}")

    return query


# NOTE: There are exactly two callers of replace_aliases() in this codebase -
# the DQ driver (dqd/custom/achilles checks) and the transformation module.
# Both are confirmed, so each calls this function directly with its own
# subset of arguments rather than going through a separate per-caller
# wrapper function. If a third, genuinely different caller shows up later,
# consider adding a thin wrapper for it rather than growing this signature
# further.


# -----------------------------------------------------------------------------
# Promotion helpers
# -----------------------------------------------------------------------------
def promote_table(
    spark,
    execution_logger,
    run_id,
    data_pipeline_identifier,
    table_name,
    qc_full_table,
    target_data_catalog,
    target_data_db,
    logger,
):
    """
    Promote a QC table into the final target schema.

    Args:
        spark: Active Spark session.
        execution_logger: Execution logger instance.
        run_id: Pipeline run identifier for the execution log.
        data_pipeline_identifier: Unique pipeline execution identifier.
        table_name: Logical target table name.
        qc_full_table: Fully qualified QC table name.
        target_data_catalog: Final target catalog.
        target_data_db: Final target database.
        logger: Logger instance.

    Raises:
        Exception: Re-raises any failure encountered during promotion.
    """
    final_table = f"{target_data_catalog}.{target_data_db}.{table_name}"
    step_name = f"promote_{table_name}"

    log_id = execution_logger.create_new_log(
        run_id=run_id,
        pipeline_name=data_pipeline_identifier,
        step_name=step_name,
        status=Status.IN_PROGRESS,
    )

    try:
        logger.info(f"Promoting: {qc_full_table} -> {final_table}")

        df = spark.table(qc_full_table)
        row_count = df.count()

        (
            df.write.format(VAR_OUTPUT_FORMAT)
            .mode(VAR_WRITE_MODE)
            .option("overwriteSchema", "true")
            .saveAsTable(final_table)
        )

        execution_logger.update_log(
            id=log_id,
            status=Status.COMPLETE,
            output=f"Table: {final_table} | Rows: {row_count}",
            error=None,
        )
        logger.info(f"Promoted: {table_name} | Rows: {row_count}")

    except Exception:
        execution_logger.update_log(
            id=log_id,
            status=Status.FAILED,
            error=traceback.format_exc(),
        )
        logger.error(f"Promotion failed: {table_name}")
        raise


def save_transformation_table(
    df,
    table_name,
    table_type,
    intermediate_data_catalog,
    intermediate_data_db,
    qc_data_catalog,
    qc_data_db,
    logger,
    spark
):
    """
    Save a transformation output table to the correct destination schema.

    Args:
        df: DataFrame to save.
        table_name: Target table name.
        table_type: Table classification used to choose the destination schema.
        intermediate_data_catalog: Intermediate catalog name.
        intermediate_data_db: Intermediate database name.
        qc_data_catalog: qc target catalog name.
        qc_data_db: qc target database name.
        logger: Logger instance.

    Returns:
        tuple[str, int]: Fully qualified table name and written row count.
    """
    if table_type == INTERMEDIATE_TABLE_TYPE:
        catalog = intermediate_data_catalog
        database = intermediate_data_db
    else:
        catalog = qc_data_catalog
        database = qc_data_db

    full_table_name = f"{catalog}.{database}.{table_name}"
    logger.info(f"Saving {table_type} table: {full_table_name}")

    (
        df.write.format(VAR_OUTPUT_FORMAT)
        .mode(VAR_WRITE_MODE)
        .option("overwriteSchema", "true")
        .saveAsTable(full_table_name)
    )

    row_count = spark.table(full_table_name).count()
    logger.info(f"Table saved: {full_table_name} | Rows: {row_count}")

    return full_table_name, row_count


def parse_transformation_ids(transformation_id_param):
    """
    Parse transformation IDs from a widget or pipeline parameter.

    Supported examples:
        "1" -> [1]
        "1,2,3" -> [1, 2, 3]

    Args:
        transformation_id_param: Raw widget value.

    Returns:
        list[int] | None: Parsed transformation IDs, or None when all
        transformations should run.

    Raises:
        ValueError: If the input is not a comma-separated list of integers.
    """
    if transformation_id_param is None:
        return None

    transformation_id_param = transformation_id_param.strip()

    if transformation_id_param == "" or transformation_id_param.lower() == "all":
        return None

    try:
        return [
            int(value.strip())
            for value in transformation_id_param.split(",")
            if value.strip()
        ]
    except ValueError as exc:
        raise ValueError(
            f"Invalid transformation_id value: {transformation_id_param}. "
            "Expected comma-separated integers like '1,2,3' "
        ) from exc

def create_schema_if_not_exists(
    spark,
    catalog,
    schema_name,
    managed_location=None,
    logger=None,
):
    """
    Create Unity Catalog schema if it does not exist.
    Uses YAML values only.
    """
    if not catalog or not schema_name:
        raise ValueError(
            f"Catalog and schema are required. catalog={catalog}, schema={schema_name}"
        )

    full_schema_name = f"`{catalog}`.`{schema_name}`"

    managed_location_clause = ""
    if managed_location:
        managed_location_clause = f" MANAGED LOCATION '{managed_location}'"

    create_sql = (
        f"CREATE SCHEMA IF NOT EXISTS {full_schema_name}"
        f"{managed_location_clause}"
    )

    if logger:
        logger.info(f"Executing schema creation SQL: {create_sql}")

    spark.sql(create_sql)
