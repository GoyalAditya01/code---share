# Databricks notebook source
# DBTITLE 1,Data Quality Check

"""
Module Name: Data Quality Check

Overview:
    This module runs source- and target-level data quality validations for a
    configured pipeline. It validates schemas, executes YAML-driven DQ checks
    (achilles, dqd, custom), and records execution details.

Supported combinations:
    * source + schema_check
    * target + schema_check
    * target + achilles
    * target + dqd
    * target + custom

Inputs:
    Databricks widgets:
        * env
        * source_name
        * dataset_name
        * refresh
        * athena_refresh
        * qc_type
        * qc_check_type
        * run_id

Outputs:
    * Pipeline and step-level results in the execution log table.
    * Created DQ check tables in the QC schema.
    * Boolean QC result returned to ADF.
"""

import json
import os
import sys
import traceback

try:
    current_path = os.path.abspath(__file__)
except NameError:
    current_path = (
        dbutils.notebook.entry_point
        .getDbutils()
        .notebook()
        .getContext()
        .notebookPath()
        .get()
    )

    if not current_path.startswith("/Workspace"):
        current_path = "/Workspace" + current_path

project_root = current_path.split("/script/")[0]
code_path = project_root + "/script/code"
utilities_path = project_root + "/script/utilities"

if code_path not in sys.path:
    sys.path.append(code_path)

if utilities_path not in sys.path:
    sys.path.append(utilities_path)

from pyspark.sql.functions import col, sum as spark_sum

from common_constants import *
from execution_logger import ExecutionLogger
from helper import (
    build_structtype_from_yaml,
    create_schema_if_not_exists,
    extract_schema_error_details,
    replace_aliases,
    serialize_log_error,
)
from logger_utility import Logger
from yaml_utility import YamlUtility


# -----------------------------------------------------------------------------
# Databricks widgets
# -----------------------------------------------------------------------------
ENV = dbutils.widgets.get(WIDGET_ENV)
source_name = dbutils.widgets.get(WIDGET_SOURCE_NAME)
dataset_name = dbutils.widgets.get(WIDGET_DATASET_NAME)
refresh = dbutils.widgets.get(WIDGET_REFRESH)
athena_refresh = dbutils.widgets.get(WIDGET_ATHENA_REFRESH)
qc_type = dbutils.widgets.get(WIDGET_QC_TYPE)
qc_check_type = dbutils.widgets.get(WIDGET_QC_CHECK_TYPE)
run_id = dbutils.widgets.get(WIDGET_RUN_ID)

# ENV = "dev"
# source_name = "marketscan"
# dataset_name = "medicare"
# refresh = "26q1"
# athena_refresh = "26q2"
# qc_type = "target"
# qc_check_type = "schema_check"
# run_id = "t_id_11"

data_pipeline_identifier = f"{source_name}_{dataset_name}_{refresh}"

logger = Logger(
    __name__,
    LOGGER_LOC.format(
        pipeline=data_pipeline_identifier,
        step=DQ_CHECK_STEP,
    ),
)


class DataQualityCheck:
    """
    Orchestrate schema validations and YAML-driven data quality checks.

    The class loads source, target, and environment configuration for the
    requested pipeline run, then executes the QC workflow selected through the
    Databricks widget inputs. Supported workflows include source schema
    validation, target schema validation, and target-level Achilles, DQD, and
    custom checks.
    """

    def __init__(
        self,
        data_pipeline_identifier,
        source_name,
        dataset_name,
        refresh,
        athena_refresh,
        qc_type,
        qc_check_type,
        run_id,
    ):
        """
        Initialize runtime state and load all pipeline configuration.

        Parameters:
            data_pipeline_identifier: Unique identifier for the pipeline run.
            source_name: Source system name used to resolve YAML config.
            dataset_name: Dataset name used to resolve YAML config.
            refresh: Source refresh/version token.
            athena_refresh: Prerequisite refresh/version token.
            qc_type: QC scope to execute, such as source or target.
            qc_check_type: Specific QC workflow to run.
            run_id: Unique execution identifier for logging.
        """
        self.spark = spark
        self.data_pipeline_identifier = data_pipeline_identifier
        self.source_name = source_name
        self.dataset_name = dataset_name
        self.refresh = refresh
        self.athena_refresh = athena_refresh
        self.qc_type = qc_type
        self.qc_check_type = qc_check_type
        self.run_id = run_id
        self.logger = logger
        self.dq_data = None

        self.logger.info(
            f"Loading configurations for {qc_type}/{qc_check_type} QC: "
            f"{data_pipeline_identifier}"
        )

        self.env_config = YamlUtility(
            env=ENV,
            conf_file=ENV_PARAMS_YAML,
        ).yaml_configuration

        source_yaml = YamlUtility(
            conf_file=SOURCE_SCHEMA_YAML,
        ).yaml_configuration

        self.source_config = source_yaml[self.source_name][self.dataset_name]

        self.source_data_catalog = self.source_config.get(
            VAR_SRC_DATA_CATALOG
        )
        self.source_data_db = self.source_config[
            VAR_SRC_DATA_DB
        ].replace(
            REFRESH_TOKEN,
            self.refresh,
        )

        self.source_table_list = self.source_config.get(
            VAR_SRC_TABLE_LIST,
            DEFAULT_EMPTY_LIST,
        )

        self.prereq_data_catalog = self.source_config.get(
            VAR_PREREQ_DATA_CATALOG
        )
        self.prereq_data_db = self.source_config[
            VAR_PREREQ_DATA_DB
        ].replace(
            ATHENA_REFRESH_TOKEN,
            self.athena_refresh,
        )
        self.prereq_table_list = self.source_config.get(
            VAR_PREREQ_TABLE_LIST,
            DEFAULT_EMPTY_LIST,
        )

        self.prereq_lookup_data_catalog = self.source_config.get(
            VAR_PREREQ_LOOKUP_DATA_CATALOG
        )
        prereq_lookup_data_db_raw = self.source_config.get(
            VAR_PREREQ_LOOKUP_DATA_DB
        )
        self.prereq_lookup_data_db = (
            prereq_lookup_data_db_raw
            .replace(SOURCE_TOKEN, self.source_name)
            .replace(DATASET_TOKEN, self.dataset_name)
            .replace(REFRESH_TOKEN, self.refresh)
            if prereq_lookup_data_db_raw
            else None
        )
        self.prereq_lookup_table_list = self.source_config.get(
            VAR_PREREQ_LOOKUP_TABLE_LIST,
            DEFAULT_EMPTY_LIST,
        )

        self.reference_data_catalog = self.source_config.get(
            VAR_REFERENCE_DATA_CATALOG
        )
        self.reference_data_db = self.source_config.get(
            VAR_REFERENCE_DATA_DB
        )
        self.reference_table_list = self.source_config.get(
            VAR_REFERENCE_TABLE_LIST,
            DEFAULT_EMPTY_LIST,
        )

        target_yaml = YamlUtility(
            conf_file=TARGET_SCHEMA_YAML,
        ).yaml_configuration

        target_data = target_yaml[self.source_name][self.dataset_name]

        self.intermediate_data_catalog = target_data.get(
            VAR_INTERMEDIATE_DATA_CATALOG
        )
        self.intermediate_data_db = (
            target_data[VAR_INTERMEDIATE_DATA_DB]
            .replace(SOURCE_TOKEN, self.source_name)
            .replace(DATASET_TOKEN, self.dataset_name)
            .replace(REFRESH_TOKEN, self.refresh)
        )

        self.qc_data_catalog = target_data.get(
            VAR_QC_TABLE_CATALOG
        )
        self.output_qc_db = (
            target_data[VAR_QC_OUTPUT_DB]
            .replace(SOURCE_TOKEN, self.source_name)
            .replace(DATASET_TOKEN, self.dataset_name)
            .replace(REFRESH_TOKEN, self.refresh)
        )

        self.target_table_list = target_data.get(
            VAR_TARGET_TABLE_LIST,
            DEFAULT_EMPTY_LIST,
        )

        if (
            self.qc_type == QC_TYPE_TARGET
            and self.qc_check_type in QC_YAML_CHECK_TYPES
        ):
            qc_conf_file = TARGET_DATA_QC_YAML_BY_SOURCE.get(
                self.source_name
            )

            if not qc_conf_file:
                raise ValueError(
                    f"No QC config file mapped for source: "
                    f"{self.source_name}"
                )

            self.dq_data = YamlUtility(
                conf_file=qc_conf_file,
            ).yaml_configuration

        self.logger.info("All configurations loaded successfully.")

    def run_schema_check(self, table_name, full_table_name, yaml_columns):
        """
        Compare a physical table schema with the YAML-defined schema contract.

        Parameters:
            table_name: Logical table name used for logging.
            full_table_name: Fully qualified table name to validate.
            yaml_columns: Column definitions loaded from YAML.

        Returns:
            A tuple containing the detailed result dictionary and a boolean
            indicating whether the schema validation passed.
        """

        result_dict = {
            SCHEMA_RESULT_TABLE_EXISTS: None,
            SCHEMA_RESULT_MISSING_COLUMNS: None,
            SCHEMA_RESULT_EXTRA_COLUMNS: None,
            SCHEMA_RESULT_TYPE_MISMATCH: None,
            SCHEMA_RESULT_NOT_NULL_CHECK: None,
        }

        passed = True

        try:
            actual_columns = self.spark.catalog.listColumns(full_table_name)
            result_dict[SCHEMA_RESULT_TABLE_EXISTS] = Status.COMPLETE
            self.logger.info(f"Table exists: {full_table_name}")
        except Exception:
            result_dict[SCHEMA_RESULT_TABLE_EXISTS] = Status.FAILED
            self.logger.error(f"Table not found: {full_table_name}")
            return result_dict, False

        if not yaml_columns:
            self.logger.warning(
                f"No columns in YAML for {table_name}; skipping column checks"
            )
            return result_dict, passed

        expected_struct = build_structtype_from_yaml(yaml_columns)
        expected_fields = {
            field.name.lower(): field
            for field in expected_struct.fields
        }
        actual_fields = {
            actual_column.name.lower(): actual_column
            for actual_column in actual_columns
        }

        missing_columns = [
            name
            for name in expected_fields
            if name not in actual_fields
        ]
        extra_columns = [
            name
            for name in actual_fields
            if name not in expected_fields
        ]

        result_dict[SCHEMA_RESULT_MISSING_COLUMNS] = missing_columns
        result_dict[SCHEMA_RESULT_EXTRA_COLUMNS] = extra_columns

        if missing_columns:
            passed = False
            self.logger.error(
                f"Missing columns in {table_name}: {missing_columns}"
            )
        
        if extra_columns:
            passed = False
            self.logger.error(
                f"Extra columns in {table_name}: {extra_columns}"
            )

        type_mismatches = []

        for column_name, expected_field in expected_fields.items():
            if column_name not in actual_fields:
                continue

            actual_type = str(
                actual_fields[column_name].dataType
            ).lower()
            expected_type = expected_field.dataType.simpleString().lower()

            if actual_type != expected_type:
                type_mismatches.append(
                    {
                        "column": column_name,
                        "expected": expected_type,
                        "actual": actual_type,
                    }
                )

        result_dict[SCHEMA_RESULT_TYPE_MISMATCH] = type_mismatches

        if type_mismatches:
            passed = False
            self.logger.error(
                f"Type mismatches in {table_name}: {type_mismatches}"
            )

        not_null_columns = [
            column_name
            for column_name, expected_field in expected_fields.items()
            if not expected_field.nullable
            and column_name in actual_fields
        ]

        if not_null_columns:
            null_checks = ", ".join(
                f"COALESCE(SUM(CASE WHEN `{column_name}` IS NULL "
                f"THEN 1 ELSE 0 END), 0) AS null_{column_name}"
                for column_name in not_null_columns
            )

            null_result = self.spark.sql(
                f"SELECT {null_checks} FROM {full_table_name}"
            ).first().asDict()

            null_failures = {
                key: int(value or 0)
                for key, value in null_result.items()
                if int(value or 0) > 0
            }

            result_dict[
                SCHEMA_RESULT_NOT_NULL_CHECK
            ] = null_failures

            if null_failures:
                passed = False
                self.logger.error(
                    f"Null violations in {table_name}: {null_failures}"
                )
        else:
            result_dict[SCHEMA_RESULT_NOT_NULL_CHECK] = {}

        self.logger.info(
            f"Schema check complete for {table_name} | passed={passed}"
        )

        return result_dict, passed

    def run_source_qc(self, execution_logger):
        """
        Execute schema validation across all configured source tables.

        Parameters:
            execution_logger: Logger used to create and update execution log
                records for each source table check.

        Returns:
            True when all source schema checks pass, otherwise False.
        """

        self.logger.info("Starting SOURCE QC schema validation")
        self.logger.info(
            f"Total source tables: {len(self.source_table_list)}"
        )

        all_passed = True

        for table_entry in self.source_table_list:
            table_name = table_entry[VAR_SRC_TABLE_NAME]
            yaml_columns = table_entry.get(VAR_COLUMNS, DEFAULT_EMPTY_LIST)
            full_table_name = (
                f"{self.source_data_catalog}."
                f"{self.source_data_db}."
                f"{table_name}"
            )
            step_name = f"source_schema_check_{table_name}"

            log_id = execution_logger.create_new_log(
                run_id=self.run_id,
                pipeline_name=self.data_pipeline_identifier,
                step_name=step_name,
                status=Status.IN_PROGRESS,
            )

            try:
                result_dict, passed = self.run_schema_check(
                    table_name=table_name,
                    full_table_name=full_table_name,
                    yaml_columns=yaml_columns,
                )

                if not passed:
                    all_passed = False

                final_status = (
                    Status.COMPLETE
                    if passed
                    else Status.FAILED
                )

                schema_error = None

                if not passed:
                    schema_error = serialize_log_error(
                        extract_schema_error_details(
                            table_name,
                            full_table_name,
                            result_dict,
                        )
                    )

                execution_logger.update_log(
                    id=log_id,
                    status=final_status,
                    output=json.dumps(result_dict),
                    error=schema_error,
                )

            except Exception:
                all_passed = False
                execution_logger.update_log(
                    id=log_id,
                    status=Status.FAILED,
                    error=traceback.format_exc(),
                )
                self.logger.error(
                    f"Source schema check failed: {table_name}"
                )

        self.logger.info(
            f"SOURCE QC complete | all_passed={all_passed}"
        )

        return all_passed

    def _run_target_schema_check(
        self,
        execution_logger,
        table_name,
        qc_full_table,
        yaml_columns,
    ):
        """
        Validate and log schema results for a single target QC table.

        Parameters:
            execution_logger: Logger used to persist execution metadata.
            table_name: Logical target table name.
            qc_full_table: Fully qualified QC table name to validate.
            yaml_columns: Expected YAML column definitions.

        Returns:
            True when the target table schema passes validation, otherwise
            False.
        """

        step_name = f"target_schema_check_{table_name}"

        log_id = execution_logger.create_new_log(
            run_id=self.run_id,
            pipeline_name=self.data_pipeline_identifier,
            step_name=step_name,
            status=Status.IN_PROGRESS,
        )

        try:
            result_dict, passed = self.run_schema_check(
                table_name=table_name,
                full_table_name=qc_full_table,
                yaml_columns=yaml_columns,
            )

            final_status = (
                Status.COMPLETE
                if passed
                else Status.FAILED
            )

            schema_error = None

            if not passed:
                schema_error = serialize_log_error(
                    extract_schema_error_details(
                        table_name,
                        qc_full_table,
                        result_dict,
                    )
                )

            execution_logger.update_log(
                id=log_id,
                status=final_status,
                output=json.dumps(result_dict),
                error=schema_error,
            )

            return passed

        except Exception:
            execution_logger.update_log(
                id=log_id,
                status=Status.FAILED,
                error=traceback.format_exc(),
            )
            self.logger.error(
                f"Target schema check failed: {table_name}"
            )
            return False

    def run_target_schema_qc(self, execution_logger):
        """
        Validate required non-intermediate target tables in the QC schema.

        Parameters:
            execution_logger: Logger used to record per-table execution status.

        Returns:
            True when all required target schema checks pass, otherwise False.
        """

        self.logger.info("Starting TARGET schema validation")

        all_passed = True

        for table_entry in self.target_table_list:
            table_name = table_entry[VAR_TARGET_TABLE_NAME]
            table_type = table_entry[VAR_TARGET_TABLE_TYPE]
            is_required = table_entry.get(VAR_IS_REQUIRED, DEFAULT_FALSE)

            if table_type == INTERMEDIATE_TABLE_TYPE:
                self.logger.info(
                    f"Skipping intermediate table: {table_name}"
                )
                continue

            if is_required is not True:
                self.logger.info(
                    f"Skipping non-required target table: "
                    f"table={table_name} | is_required={is_required}"
                )
                continue

            yaml_columns = table_entry.get(VAR_COLUMNS, DEFAULT_EMPTY_LIST)
            qc_full_table = (
                f"{self.qc_data_catalog}."
                f"{self.output_qc_db}."
                f"{table_name}"
            )

            passed = self._run_target_schema_check(
                execution_logger=execution_logger,
                table_name=table_name,
                qc_full_table=qc_full_table,
                yaml_columns=yaml_columns,
            )

            if not passed:
                all_passed = False

        self.logger.info(
            f"TARGET schema validation complete | "
            f"all_passed={all_passed}"
        )

        return all_passed

    def resolve_query_aliases(self, query, check_id_to_table):
        """
        Replace table aliases and cross-check references in a QC SQL query.

        Parameters:
            query: Raw QC SQL statement from YAML.
            check_id_to_table: Mapping of check identifiers to output tables
                created earlier in the same run.

        Returns:
            The SQL query with all configured aliases expanded to fully
            qualified table references.
        """

        return replace_aliases(
            query=query,
            target_table_list=self.target_table_list,
            qc_data_catalog=self.qc_data_catalog,
            qc_data_db=self.output_qc_db,
            intermediate_data_catalog=self.intermediate_data_catalog,
            intermediate_data_db=self.intermediate_data_db,
            source_table_list=self.source_table_list,
            source_data_catalog=self.source_data_catalog,
            source_data_db=self.source_data_db,
            prereq_table_list=self.prereq_table_list,
            prereq_data_catalog=self.prereq_data_catalog,
            prereq_data_db=self.prereq_data_db,
            prereq_lookup_table_list=self.prereq_lookup_table_list,
            prereq_lookup_data_catalog=self.prereq_lookup_data_catalog,
            prereq_lookup_data_db=self.prereq_lookup_data_db,
            reference_table_list=self.reference_table_list,
            reference_data_catalog=self.reference_data_catalog,
            reference_data_db=self.reference_data_db,
            check_id_to_table=check_id_to_table,
            logger=self.logger,
        )

    def run_qc_checks(self, execution_logger, check_type):
        """
        Execute YAML-defined QC checks and materialize their result tables.

        Parameters:
            execution_logger: Logger used to track status for each QC check.
            check_type: QC section to execute, such as achilles, dqd, or
                custom.

        Returns:
            True when all checks execute successfully, otherwise False.
        """

        check_section = self.dq_data.get(check_type)

        if not check_section:
            self.logger.info(
                f"No section found in YAML for: {check_type}"
            )
            return True

        check_list = check_section.get(VAR_QC_CHECK_LIST, DEFAULT_EMPTY_LIST)

        if not check_list:
            self.logger.info(
                f"No checks defined for: {check_type}"
            )
            return True

        self.logger.info(
            f"Running {len(check_list)} {check_type} checks"
        )

        check_id_to_table = {}

        for check in check_list:
            check_id = check[VAR_QC_CHECK_ID]
            check_name = check[VAR_QC_CHECK_NAME]
            check_id_to_table[check_id] = (
                f"{self.qc_data_catalog}."
                f"{self.output_qc_db}."
                f"{check_name}"
            )

        all_success = True

        for check in check_list:
            check_id = check[VAR_QC_CHECK_ID]

            # TEMP: only run these check_ids. Delete this block when done.
            # if check_id not in {8,10,25}:
            #     continue

            check_name = check[VAR_QC_CHECK_NAME]
            check_query = check[VAR_QC_CHECK_QUERY]
            optimize_query = check.get(
                VAR_QC_OPTIMIZE_QUERY,
                DEFAULT_EMPTY_STRING,
            )

            full_table_name = check_id_to_table[check_id]
            step_name = f"{check_type}_check_{check_id}"

            log_id = execution_logger.create_new_log(
                run_id=self.run_id,
                pipeline_name=self.data_pipeline_identifier,
                step_name=step_name,
                status=Status.IN_PROGRESS,
            )

            try:
                self.spark.sql(
                    f"DROP TABLE IF EXISTS {full_table_name}"
                )

                resolved_query = self.resolve_query_aliases(
                    query=check_query,
                    check_id_to_table=check_id_to_table,
                )

                create_sql = (
                    f"CREATE OR REPLACE TABLE {full_table_name} "
                    f"USING {VAR_OUTPUT_FORMAT} AS {resolved_query}"
                )

                self.spark.sql(create_sql)
                self.logger.info(f"Created: {full_table_name}")

                if optimize_query and optimize_query.strip():
                    resolved_optimize = self.resolve_query_aliases(
                        query=optimize_query,
                        check_id_to_table=check_id_to_table,
                    )
                    self.spark.sql(resolved_optimize)
                    self.logger.info(
                        f"Optimized: {full_table_name}"
                    )

                execution_logger.update_log(
                    id=log_id,
                    status=Status.COMPLETE,
                    output=(
                        f"{check_type} check {check_id} "
                        f"({check_name}) completed"
                    ),
                )

            except Exception:
                all_success = False
                error_message = traceback.format_exc()

                execution_logger.update_log(
                    id=log_id,
                    status=Status.FAILED,
                    error=error_message,
                )

                self.logger.error(
                    f"{check_type} check failed | "
                    f"check_id={check_id} | error={error_message}"
                )

        self.logger.info(
            f"{check_type} checks done | all_success={all_success}"
        )

        return all_success


    def validate_qc_result_tables(
        self,
        check_type,
        execution_logger,
    ):
        """
        Validate the final DQD or custom result table using criticality.

        Behavior (same for DQD and CUSTOM):
            * Failed HIGH criticality checks fail the pipeline.
            * Failed MEDIUM/LOW criticality checks are logged as warnings.
            * Missing criticality defaults to HIGH.
        """

        result_table_map = {
            QC_CHECK_TYPE_DQD: VAR_QC_TBL_DQD,
            QC_CHECK_TYPE_CUSTOM: VAR_QC_TBL_CUSTOM,
        }

        result_table = result_table_map.get(check_type)

        if not result_table:
            return True

        full_table_name = (
            f"{self.qc_data_catalog}."
            f"{self.output_qc_db}."
            f"{result_table}"
        )

        result_df = self.spark.table(full_table_name)

        # ------------------------------------------------------------------
        # Build criticality lookup from this check_type's YAML section
        # ------------------------------------------------------------------
        yaml_section = self.dq_data.get(check_type, {})
        yaml_check_list = yaml_section.get(
            VAR_QC_CHECK_LIST,
            DEFAULT_EMPTY_LIST,
        )

        criticality_by_check_name = {}

        for check in yaml_check_list:
            check_name = str(
                check[VAR_QC_CHECK_NAME]
            ).strip().lower()

            criticality = str(
                check.get(
                    VAR_QC_CRITICALITY,
                    DEFAULT_DQD_CRITICALITY,
                )
            ).strip().lower()

            if criticality not in VALID_DQD_CRITICALITIES:
                raise ValueError(
                    f"Invalid {check_type} criticality '{criticality}' for "
                    f"check_name={check_name}. Allowed values are: "
                    f"{sorted(VALID_DQD_CRITICALITIES)}"
                )

            criticality_by_check_name[check_name] = criticality

        failed_rows = (
            result_df
            .filter(col(VAR_FAILED_COLUMN) == 1)
            .groupBy(VAR_QC_CHECK_NAME)
            .agg(
                spark_sum(
                    col(VAR_FAILED_COLUMN)
                ).alias(VAR_FAIL_COUNT_ALIAS)
            )
            .collect()
        )

        blocking_failures = []
        warning_failures = []

        for row in failed_rows:
            result_check_name = row[VAR_QC_CHECK_NAME]
            fail_count = int(
                row[VAR_FAIL_COUNT_ALIAS] or DEFAULT_ZERO
            )

            normalized_check_name = str(
                result_check_name
            ).strip().lower()

            criticality = criticality_by_check_name.get(
                normalized_check_name,
                DEFAULT_DQD_CRITICALITY,
            )

            failure_detail = {
                "check_name": result_check_name,
                "criticality": criticality,
                "failed_result_count": fail_count,
            }

            if criticality == CRITICALITY_HIGH:
                blocking_failures.append(failure_detail)

                self.logger.error(
                    f"{check_type.upper()} HIGH criticality check failed | "
                    f"check_name={result_check_name} | "
                    f"failed_result_count={fail_count}"
                )
            else:
                warning_failures.append(failure_detail)

                self.logger.warning(
                    f"{check_type.upper()} {criticality.upper()} "
                    f"criticality check failed; pipeline will continue | "
                    f"check_name={result_check_name} | "
                    f"failed_result_count={fail_count}"
                )

        qc_passed = len(blocking_failures) == DEFAULT_ZERO

        # Write one execution_log row per failed check so each blocking /
        # warning failure is individually queryable, not buried inside the
        # summary JSON. Blocking (HIGH) -> status FAILED, warning
        # (MEDIUM/LOW) -> status WARNING.
        for failure_detail in blocking_failures + warning_failures:
            failure_check_name = failure_detail["check_name"]
            failure_criticality = failure_detail["criticality"]
            failure_count = failure_detail["failed_result_count"]
            is_blocking = failure_criticality == CRITICALITY_HIGH

            per_check_log_id = execution_logger.create_new_log(
                run_id=self.run_id,
                pipeline_name=self.data_pipeline_identifier,
                step_name=f"{check_type}_check_result_{failure_check_name}",
                status=Status.IN_PROGRESS,
            )

            if is_blocking:
                output_message = (
                    f"{check_type.upper()} HIGH criticality check failed "
                    f"- pipeline blocked | "
                    f"check_name={failure_check_name} | "
                    f"failed_result_count={failure_count}"
                )
                error_payload = json.dumps(failure_detail)
                per_check_status = Status.FAILED
            else:
                output_message = (
                    f"{check_type.upper()} {failure_criticality.upper()} "
                    f"criticality check failed - warning only, "
                    f"pipeline continues | "
                    f"check_name={failure_check_name} | "
                    f"failed_result_count={failure_count}"
                )
                error_payload = None
                per_check_status = Status.WARNING

            execution_logger.update_log(
                id=per_check_log_id,
                status=per_check_status,
                output=output_message,
                error=error_payload,
            )

        validation_summary = {
            "qc_passed": qc_passed,
            "blocking_failure_count": len(blocking_failures),
            "warning_failure_count": len(warning_failures),
            "blocking_failures": blocking_failures,
            "warning_failures": warning_failures,
        }

        validation_log_id = execution_logger.create_new_log(
            run_id=self.run_id,
            pipeline_name=self.data_pipeline_identifier,
            step_name=f"{check_type}_criticality_validation",
            status=Status.IN_PROGRESS,
        )

        if not qc_passed:
            summary_status = Status.FAILED
        elif warning_failures:
            summary_status = Status.WARNING
        else:
            summary_status = Status.COMPLETE

        execution_logger.update_log(
            id=validation_log_id,
            status=summary_status,
            output=json.dumps(validation_summary),
            error=(
                json.dumps(blocking_failures)
                if blocking_failures
                else None
            ),
        )

        if warning_failures and qc_passed:
            self.logger.warning(
                f"{check_type.upper()} completed with warnings | "
                f"warning_failure_count={len(warning_failures)}"
            )

        return qc_passed

    def trigger_qc_checks(self, execution_logger):
        """
        Dispatch execution to the QC workflow requested by widget inputs.

        Parameters:
            execution_logger: Logger used to record workflow and check status.

        Returns:
            True when the selected QC workflow succeeds, otherwise False.

        Raises:
            ValueError: If the qc_type and qc_check_type combination is not
                supported.
        """

        if self.qc_check_type == QC_CHECK_TYPE_SCHEMA:
            if self.qc_type == QC_TYPE_SOURCE:
                return self.run_source_qc(execution_logger)

            if self.qc_type == QC_TYPE_TARGET:
                return self.run_target_schema_qc(execution_logger)

        if (
            self.qc_type == QC_TYPE_TARGET
            and self.qc_check_type in QC_YAML_CHECK_TYPES
        ):
            execution_success = self.run_qc_checks(
                execution_logger=execution_logger,
                check_type=self.qc_check_type,
            )

            if not execution_success:
                return False

            if self.qc_check_type == QC_CHECK_TYPE_ACHILLES:
                return True

            try:
                return self.validate_qc_result_tables(
                check_type=self.qc_check_type,
                execution_logger=execution_logger,
            )
            except Exception:
                self.logger.error(
                    f"validate_qc_result_tables failed | "
                    f"check_type={self.qc_check_type} | "
                    f"error={traceback.format_exc()}"
                )
                return False

        raise ValueError(
            f"Invalid qc_type/qc_check_type: "
            f"{self.qc_type}/{self.qc_check_type}"
        )


if __name__ == "__main__":
    step_name = f"{DQ_CHECK_STEP}_{qc_type}_{qc_check_type}"

    target_config = YamlUtility(
        conf_file=TARGET_SCHEMA_YAML,
    ).yaml_configuration

    target_data = target_config[source_name][dataset_name]

    qc_catalog = target_data.get(VAR_QC_TABLE_CATALOG)
    output_qc_db = (
        target_data[VAR_QC_OUTPUT_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
        .replace(REFRESH_TOKEN, refresh)
    )

    qc_location = target_data.get(VAR_QC_OUTPUT_LOCATION)

    if qc_location:
        qc_location = (
            qc_location
            .replace(SOURCE_TOKEN, source_name)
            .replace(DATASET_TOKEN, dataset_name)
            .replace(REFRESH_TOKEN, refresh)
        )

    create_schema_if_not_exists(
        spark=spark,
        catalog=qc_catalog,
        schema_name=output_qc_db,
        managed_location=qc_location,
        logger=logger,
    )

    # The execution log is a single, cross-step Delta table shared by
    # transformation / DQ / promotion / notifier. It lives in the
    # intermediate schema (where the transformation step created it).
    intermediate_catalog = target_data.get(VAR_INTERMEDIATE_DATA_CATALOG)
    intermediate_db = (
        target_data[VAR_INTERMEDIATE_DATA_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
        .replace(REFRESH_TOKEN, refresh)
    )

    execution_logger = ExecutionLogger(
        database=f"{intermediate_catalog}.{intermediate_db}",
        table=VAR_LOG_TABLE_NAME,
        spark=spark,
    )

    execution_logger.terminate_current_execution(run_id)

    execution_log_id = execution_logger.create_new_log(
        run_id=run_id,
        pipeline_name=data_pipeline_identifier,
        step_name=step_name,
        status=Status.IN_PROGRESS,
    )

    try:
        logger.info(
            f"Starting {qc_type}/{qc_check_type} QC: "
            f"{data_pipeline_identifier}"
        )

        qc_passed = DataQualityCheck(
            data_pipeline_identifier=data_pipeline_identifier,
            source_name=source_name,
            dataset_name=dataset_name,
            refresh=refresh,
            athena_refresh=athena_refresh,
            qc_type=qc_type,
            qc_check_type=qc_check_type,
            run_id=run_id,
        ).trigger_qc_checks(execution_logger)

        final_log_status = (
            Status.COMPLETE
            if qc_passed
            else Status.FAILED
        )

        execution_logger.update_log(
            id=execution_log_id,
            status=final_log_status,
        )

        execution_logger.terminate_current_execution(run_id)
        dbutils.notebook.exit(str(qc_passed).lower())

    except BaseException as exc:

        if exc.__class__.__name__ == "NotebookExit":
            raise

        error_message = traceback.format_exc()

        logger.error(
            f"{qc_type}/{qc_check_type} QC failed: {error_message}"
        )

        execution_logger.update_log(
            id=execution_log_id,
            status=Status.FAILED,
            error=error_message,
        )

        execution_logger.terminate_current_execution(run_id)
        logger.info("QC pipeline terminated.")
        raise