# Databricks notebook source

"""
Module Name: Promote Target Tables

Overview:
    This module promotes QC-passed tables from the QC schema to the final
    target schema. It also creates latest views without refresh in the schema
    name, so downstream users can query the latest promoted data.

Inputs:
    Databricks widgets:
        * env
        * source_name
        * dataset_name
        * refresh
        * qc_passed
        * run_id

Outputs:
    * Promoted target tables in refresh-specific target schema.
    * Latest views in refreshless target schema.
    * Execution log entries for each promoted table.
"""

import os
import sys

try:
    current_path = os.path.abspath(__file__)
except NameError:
    current_path = (
        dbutils.notebook.entry_point
        .getDbutils()
        .notebook()
        .getContext()
        .notebookPath()
        .get()
    )

    if not current_path.startswith("/Workspace"):
        current_path = "/Workspace" + current_path

project_root = current_path.split("/script/")[0]

code_path = project_root + "/script/code"
utilities_path = project_root + "/script/utilities"

if code_path not in sys.path:
    sys.path.append(code_path)

if utilities_path not in sys.path:
    sys.path.append(utilities_path)

from databricks.sdk.runtime import dbutils

from common_constants import *
from execution_logger import ExecutionLogger
from helper import create_schema_if_not_exists, promote_table
from logger_utility import Logger
from yaml_utility import YamlUtility


def get_view_db(target_data_db_template):
    """Remove the refresh placeholder from the target schema name."""

    return (
        target_data_db_template
        .replace(f"_{REFRESH_TOKEN}", "")
        .replace(f"{REFRESH_TOKEN}_", "")
        .replace(REFRESH_TOKEN, "")
        .replace("__", "_")
        .strip("_")
    )


def drop_all_views(spark, catalog, schema_name, logger):
    """Drop all views from the given schema."""

    views = spark.sql(
        f"""
        SELECT table_name
        FROM `{catalog}`.information_schema.views
        WHERE table_schema = '{schema_name}'
        """
    ).collect()

    for view in views:
        view_name = view["table_name"]

        spark.sql(
            f"""
            DROP VIEW IF EXISTS
            `{catalog}`.`{schema_name}`.`{view_name}`
            """
        )

        logger.info(
            f"Dropped view: {catalog}.{schema_name}.{view_name}"
        )


def main():
    """Promote required target tables and recreate latest views."""

    env = dbutils.widgets.get(WIDGET_ENV)
    source_name = dbutils.widgets.get(WIDGET_SOURCE_NAME)
    dataset_name = dbutils.widgets.get(WIDGET_DATASET_NAME)
    refresh = dbutils.widgets.get(WIDGET_REFRESH)
    qc_passed = dbutils.widgets.get(WIDGET_QC_PASSED)
    run_id = dbutils.widgets.get(WIDGET_RUN_ID)

    
    # env = "dev"
    # source_name = "marketscan"
    # dataset_name = "medicare"
    # refresh = "26q1"
    # qc_passed = "true"
    # run_id = "t_id_1"

    data_pipeline_identifier = (
        f"{source_name}_{dataset_name}_{refresh}"
    )

    logger = Logger(
        __name__,
        LOGGER_LOC.format(
            pipeline=data_pipeline_identifier,
            step=PROMOTE_TARGET_TABLES_STEP,
        ),
    )

    logger.info(
        f"Starting target table promotion | "
        f"pipeline={data_pipeline_identifier} | "
        f"env={env} | run_id={run_id}"
    )

    if qc_passed.strip().lower() != BOOLEAN_TRUE:
        logger.info(
            f"QC did not pass. Skipping target table promotion. "
            f"qc_passed={qc_passed}"
        )
        return

    target_config = YamlUtility(
        conf_file=TARGET_SCHEMA_YAML,
    ).yaml_configuration

    target_source_config = target_config[source_name]
    target_data = target_source_config[dataset_name]

    qc_data_catalog = (
        target_data.get(VAR_QC_TABLE_CATALOG)
        or target_source_config.get(VAR_QC_TABLE_CATALOG)
    )

    target_data_catalog = (
        target_data.get(VAR_TARGET_DATA_CATALOG)
        or target_source_config.get(VAR_TARGET_DATA_CATALOG)
    )

    if not qc_data_catalog:
        raise ValueError(
            "QC data catalog is missing in target schema YAML."
        )

    if not target_data_catalog:
        raise ValueError(
            "Target data catalog is missing in target schema YAML."
        )

    output_qc_db = (
        target_data[VAR_QC_OUTPUT_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
        .replace(REFRESH_TOKEN, refresh)
    )

    qc_data_loc = target_data.get(VAR_QC_OUTPUT_LOCATION)
    if qc_data_loc:
        qc_data_loc = (
            qc_data_loc
            .replace(SOURCE_TOKEN, source_name)
            .replace(DATASET_TOKEN, dataset_name)
            .replace(REFRESH_TOKEN, refresh)
        )

    target_data_db_template = (
        target_data[VAR_TARGET_DATA_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
    )

    target_data_db = target_data_db_template.replace(
        REFRESH_TOKEN,
        refresh,
    )

    target_view_db = get_view_db(
        target_data_db_template
    )

    target_data_loc = target_data.get(
        VAR_TARGET_DATA_LOCATION
    )

    if target_data_loc:
        target_data_loc = (
            target_data_loc
            .replace(SOURCE_TOKEN, source_name)
            .replace(DATASET_TOKEN, dataset_name)
            .replace(REFRESH_TOKEN, refresh)
        )

    target_table_list = target_data[
        VAR_TARGET_TABLE_LIST
    ]

    create_schema_if_not_exists(
        spark=spark,
        catalog=target_data_catalog,
        schema_name=target_data_db,
        managed_location=target_data_loc,
        logger=logger,
    )

    create_schema_if_not_exists(
        spark=spark,
        catalog=target_data_catalog,
        schema_name=target_view_db,
        managed_location=None,
        logger=logger,
    )

    # Tag the view schema with the current refresh so it can be
    # tracked/queried alongside the tagged views and tables.
    spark.sql(
        f"ALTER SCHEMA `{target_data_catalog}`.`{target_view_db}` "
        f"SET TAGS ('refresh' = '{refresh}')"
    )

    drop_all_views(
        spark=spark,
        catalog=target_data_catalog,
        schema_name=target_view_db,
        logger=logger,
    )

    # The execution log is a single, cross-step Delta table shared by
    # transformation / DQ / promotion / notifier. It lives in the
    # intermediate schema (where the transformation step created it).
    intermediate_data_catalog = (
        target_data.get(VAR_INTERMEDIATE_DATA_CATALOG)
        or target_source_config.get(VAR_INTERMEDIATE_DATA_CATALOG)
    )
    intermediate_data_db = (
        target_data[VAR_INTERMEDIATE_DATA_DB]
        .replace(SOURCE_TOKEN, source_name)
        .replace(DATASET_TOKEN, dataset_name)
        .replace(REFRESH_TOKEN, refresh)
    )

    execution_logger = ExecutionLogger(
        database=f"{intermediate_data_catalog}.{intermediate_data_db}",
        table=VAR_LOG_TABLE_NAME,
        spark=spark,
    )

    for table_entry in target_table_list:
        table_name = table_entry[
            VAR_TARGET_TABLE_NAME
        ]

        table_type = table_entry[
            VAR_TARGET_TABLE_TYPE
        ]

        is_required = table_entry.get(
            VAR_IS_REQUIRED,
            DEFAULT_FALSE,
        )

        if table_type == INTERMEDIATE_TABLE_TYPE:
            logger.info(
                f"Skipping intermediate table: {table_name}"
            )
            continue

        if is_required is not True:
            logger.info(
                f"Skipping non-required target table: "
                f"table={table_name} | "
                f"is_required={is_required}"
            )
            continue

        qc_full_table = (
            f"{qc_data_catalog}."
            f"{output_qc_db}."
            f"{table_name}"
        )

        logger.info(
            f"Promoting table: {qc_full_table} to "
            f"{target_data_catalog}."
            f"{target_data_db}."
            f"{table_name}"
        )

        promote_table(
            spark=spark,
            execution_logger=execution_logger,
            run_id=run_id,
            data_pipeline_identifier=data_pipeline_identifier,
            table_name=table_name,
            qc_full_table=qc_full_table,
            target_data_catalog=target_data_catalog,
            target_data_db=target_data_db,
            logger=logger,
        )

        spark.sql(
            f"""
            CREATE OR REPLACE VIEW
                `{target_data_catalog}`.
                `{target_view_db}`.
                `{table_name}`
            AS
            SELECT *
            FROM
                `{target_data_catalog}`.
                `{target_data_db}`.
                `{table_name}`
            """
        )

        spark.sql(
            f"ALTER VIEW `{target_data_catalog}`.`{target_view_db}`.`{table_name}` "
            f"SET TAGS ('refresh' = '{refresh}')"
        )

        logger.info(
            f"Latest view created: "
            f"{target_data_catalog}."
            f"{target_view_db}."
            f"{table_name} -> "
            f"{target_data_catalog}."
            f"{target_data_db}."
            f"{table_name}"
        )


    # Promote QC result tables and create latest views (mirroring the
    # target tables) so downstream users can query the latest QC results.
    for table_name in QC_PROMOTION_TABLE_LIST:
        qc_full_table = (
            f"{qc_data_catalog}."
            f"{output_qc_db}."
            f"{table_name}"
        )

        # QC result tables may not exist if QC checks were skipped.
        if not spark.catalog.tableExists(qc_full_table):
            logger.info(
                f"Skipping QC result promotion - table not found: "
                f"{qc_full_table}"
            )
            continue

        logger.info(
            f"Promoting QC result table: {qc_full_table} to "
            f"{target_data_catalog}."
            f"{target_data_db}."
            f"{table_name}"
        )

        promote_table(
            spark=spark,
            execution_logger=execution_logger,
            run_id=run_id,
            data_pipeline_identifier=data_pipeline_identifier,
            table_name=table_name,
            qc_full_table=qc_full_table,
            target_data_catalog=target_data_catalog,
            target_data_db=target_data_db,
            logger=logger,
        )

        spark.sql(
            f"""
            CREATE OR REPLACE VIEW
                `{target_data_catalog}`.
                `{target_view_db}`.
                `{table_name}`
            AS
            SELECT *
            FROM
                `{target_data_catalog}`.
                `{target_data_db}`.
                `{table_name}`
            """
        )

        spark.sql(
            f"ALTER VIEW `{target_data_catalog}`.`{target_view_db}`.`{table_name}` "
            f"SET TAGS ('refresh' = '{refresh}')"
        )

        logger.info(
            f"Latest QC view created: "
            f"{target_data_catalog}."
            f"{target_view_db}."
            f"{table_name} -> "
            f"{target_data_catalog}."
            f"{target_data_db}."
            f"{table_name}"
        )

    # All target + QC result tables have been promoted successfully. Drop
    # the entire QC schema (CASCADE removes all remaining tables) so no
    # stale QC artifacts linger. The next run will recreate the schema.
    spark.sql(
        f"DROP SCHEMA IF EXISTS "
        f"`{qc_data_catalog}`.`{output_qc_db}` CASCADE"
    )
    logger.info(
        f"Dropped QC schema: {qc_data_catalog}.{output_qc_db}"
    )

    logger.info(
        "Target table promotion completed successfully."
    )


main()