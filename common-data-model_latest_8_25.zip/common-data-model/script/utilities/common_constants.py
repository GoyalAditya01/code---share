"""
Module Name : Common Constants
Purpose     : Central definition of all pipeline-wide constants
"""

import sys
import os

# -- Workspace Paths ------------------------------------------
# Resolve project root dynamically relative to this file's location:
# common_constants.py lives at: <project_root>/script/utilities/
UTILITIES_PATH = os.path.dirname(os.path.abspath(__file__))
SCRIPT_PATH = os.path.dirname(UTILITIES_PATH)
REPO_BASE_PATH = os.path.dirname(SCRIPT_PATH)
CONFIG_GLOBAL_PATH = os.path.join(REPO_BASE_PATH, "configuration", "global")
CONFIG_ENV_PATH = os.path.join(REPO_BASE_PATH, "configuration", "env")

# sys.path.append(UTILITIES_PATH)

# -- YAML Config File Names -----------------------------------
SOURCE_SCHEMA_YAML = "source_schema.yaml"
TARGET_SCHEMA_YAML = "target_schema.yaml"
TRANSFORMATION_YAML = "transformation.yaml"
TARGET_DATA_QC_YAML = "target_data_qc.yaml"
ENV_PARAMS_YAML = "env_params.yaml"

# Source-specific QC config files. Each source has its own data QC YAML so
# that check definitions can diverge per source.
TARGET_DATA_QC_YAML_BY_SOURCE = {
    "marketscan": "target_data_qc.yaml",
    "optum": "target_data_qc_optum.yaml",
}

# -- Env Params Keys ------------------------------------------
VAR_OUTPUT_DATABASE = "output_database"
VAR_STORAGE_ACCOUNT = "storage_account"

# -- Source Schema Keys ----------------------------------------
VAR_SRC_DATA_DB = "source_data_db"
VAR_SRC_DATA_CATALOG = "source_data_catalog"           
VAR_SRC_TABLE_LIST = "source_table_list"
VAR_SRC_TABLE_ID = "source_table_id"
VAR_SRC_TABLE_NAME = "table_name"

# -- Prerequisite Keys -----------------------------------------
VAR_PREREQ_DATA_CATALOG = "prerequisite_data_catalog"  
VAR_PREREQ_DATA_DB = "prerequisite_data_db"            
VAR_PREREQ_TABLE_LIST = "prerequisite_table_list"      
VAR_PREREQ_TABLE_ID = "pre_req_table_id"               
VAR_PREREQ_TABLE_NAME = "table_name"       

# -- reference Keys -----------------------------------------
VAR_REFERENCE_DATA_LIST = "reference_data_list"
VAR_REFERENCE_DATA_ID = "reference_data_id"
VAR_REFERENCE_DATA_CATALOG = "reference_data_catalog"  
VAR_REFERENCE_DATA_DB = "reference_data_db"            
VAR_REFERENCE_TABLE_LIST = "reference_table_list"      
VAR_REFERENCE_TABLE_ID = "ref_table_id"               
VAR_REFERENCE_TABLE_NAME = "table_name"  

# -- Target Schema Keys ---------------------------------------
VAR_TARGET_DATA_DB = "target_data_db"
VAR_TARGET_DATA_CATALOG = "target_data_catalog"    
VAR_INTERMEDIATE_DATA_CATALOG = "intermediate_data_catalog"     
VAR_INTERMEDIATE_DATA_DB = "intermediate_data_db"      
VAR_TARGET_TABLE_LIST = "target_table_list"
VAR_TARGET_TABLE_ID = "target_table_id"
VAR_TARGET_TABLE_NAME = "table_name"
VAR_TARGET_TABLE_TYPE = "table_type"
VAR_INTERMEDIATE_DATA_LOCATION = "intermediate_data_loc"
VAR_TARGET_DATA_LOCATION = "target_data_loc"

# -- Table Type Constants --------------------------------------
INTERMEDIATE_TABLE_TYPE = "intermediate"               
TARGET_TABLE_TYPE = "target"                       

# -- Transformation Keys --------------------------------------
VAR_TRANSFORMATION_LIST = "transformation_list"
VAR_TRANSFORMATION_ID = "transformation_id"
VAR_MAPPING_TARGET_TABLE_ID = "target_table_id"
VAR_TRANSFORMATION_QUERY = "transformation_query"

# -- Transformation Log Config ---------------------------------
VAR_LOG_TABLE_NAME = "execution_log"
VAR_LOG_OUTPUT_FORMAT = "delta"

# -- Table Alias Prefixes (used in SQL placeholder replacement) -
VAR_PREFIX_SRC_TBL_ALIAS = "src_tbl_"
VAR_PREFIX_TGT_TBL_ALIAS = "tgt_tbl_"
VAR_PREFIX_PREREQ_TBL_ALIAS = "pre_req_tbl_"   
VAR_PREFIX_REFERENCE_CTL_ALIAS = "ref_ctl_"


# -- Spark / Table Save Config ---------------------------------
VAR_OUTPUT_FORMAT = "delta" 
VAR_WRITE_MODE = "overwrite"

# -- Logger Config ---------------------------------------------
LOGGER_LOC = os.path.join(
    REPO_BASE_PATH,
    "logs",
    "{pipeline}_{step}__%Y-%m-%d_%H-%M-%S.log"
)
TRANSFORMATION_STEP = "transformation"
DQ_CHECK_STEP = "data_quality_check"
EMAIL_NOTIFIER_STEP = "email_notifier"

# -- Target DQ Config Keys -------------------------------------
VAR_QC_TABLE_CATALOG      = "qc_data_catalog"
VAR_QC_OUTPUT_DB          = "qc_data_db"
VAR_QC_CHECK_RESULT       = "qc_check_result"
VAR_QC_CHECK_LIST         = "qc_check_list"
VAR_QC_CHECK_ID           = "check_id"
VAR_QC_TARGET_TABLE_ID    = "target_table_id"
VAR_QC_CHECK_QUERY        = "check_query"
VAR_QC_CHECK_NAME = "check_name"       # used to build full table name from YAML
VAR_QC_OPTIMIZE_QUERY = "optimize_query"  # used to fetch optimize query from YAML
VAR_QC_TBL_CUSTOM= "custom_check_result"
VAR_QC_TBL_DQD= "ddlDqdResults"
VAR_QC_ACHILLES_RESULT_DIST= "achilles_results_dist"
VAR_QC_ACHILLES_RESULT= "achilles_results"
VAR_QC_OUTPUT_LOCATION = "qc_data_loc"

VAR_PREREQ_LOOKUP_DATA_CATALOG = "prerequisite_lookup_data_catalog"
VAR_PREREQ_LOOKUP_DATA_DB = "prerequisite_lookup_data_db"
VAR_PREREQ_LOOKUP_TABLE_LIST = "prerequisite_lookup_table_list"

VAR_PREREQ_LOOKUP_TABLE_ID = "pre_req_lookup_table_id"
VAR_PREREQ_LOOKUP_TABLE_NAME = "table_name"

VAR_PREFIX_PREREQ_LOOKUP_TBL_ALIAS = "pre_req_lkp_tbl_"

# -- Pipeline Name ---------------------------------------------
CDM_PIPELINE_NAME = "RWD OMOP Pipeline"


# -- Execution status values (OOP) -----------------------------
class Status:
    """
    Canonical set of execution-log status values.

    Using a class instead of a dict prevents typos at import time
    (unknown attribute raises AttributeError immediately) and gives
    IDEs / linters visibility into the allowed values.
    """
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    FAILED = "failed"
    SKIPPED = "skipped"
    WARNING = "warning"


# -- Transformation result dict keys ---------------------------
class TransformationResultKey:
    """Keys used in the transformation results summary dict."""
    TRANSFORMATION_ID = "transformation_id"
    TARGET_TABLE_ID = "target_table_id"
    TARGET_TABLE_NAME = "target_table_name"
    FULL_TABLE_NAME = "full_table_name"
    ROW_COUNT = "row_count"
    STATUS = "status"
    REASON = "reason"
    IS_REQUIRED = "is_required"


# -- Schema-error dict keys ------------------------------------
class SchemaErrorKey:
    """Keys used in the schema validation error payload dict."""
    TABLE_NAME = "table_name"
    FULL_TABLE_NAME = "full_table_name"
    TABLE_EXISTS = "table_exists"


# Reason strings for transformation skip decisions
REASON_TABLE_NOT_REQUIRED = "Target table is not required"

# Databricks widget names
WIDGET_ENV = "env"
WIDGET_SOURCE_NAME = "source_name"
WIDGET_DATASET_NAME = "dataset_name"
WIDGET_REFRESH = "refresh"
WIDGET_ATHENA_REFRESH = "athena_refresh"
WIDGET_QC_TYPE = "qc_type"
WIDGET_QC_CHECK_TYPE = "qc_check_type"
WIDGET_RUN_ID = "run_id"
WIDGET_TRANSFORMATION_ID = "transformation_id"
WIDGET_PIPELINE_STATUS = "pipeline_status"
WIDGET_PIPELINE_NAME = "pipeline_name"
WIDGET_TRIGGER_TIME = "trigger_time"
WIDGET_SENDER_EMAIL = "sender_email"
WIDGET_RECEIVER_EMAIL = "receiver_email"
WIDGET_QC_PASSED = "qc_passed"

# Datetime format for email/log timestamps
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S UTC"

# Schema placeholders
SOURCE_TOKEN = "{source}"
DATASET_TOKEN = "{dataset}"
REFRESH_TOKEN = "{refresh}"
ATHENA_REFRESH_TOKEN = "{athena_refresh}"


# QC types
QC_TYPE_SOURCE = "source"
QC_TYPE_TARGET = "target"

# QC check types
QC_CHECK_TYPE_SCHEMA = "schema_check"
QC_CHECK_TYPE_ACHILLES = "achilles"
QC_CHECK_TYPE_DQD = "dqd"
QC_CHECK_TYPE_CUSTOM = "custom"

QC_YAML_CHECK_TYPES = (
    QC_CHECK_TYPE_ACHILLES,
    QC_CHECK_TYPE_DQD,
    QC_CHECK_TYPE_CUSTOM,
)

# Common YAML keys
VAR_COLUMNS = "columns"
VAR_IS_REQUIRED = "is_required"

# Schema validation result keys
SCHEMA_RESULT_TABLE_EXISTS = "table_exists"
SCHEMA_RESULT_MISSING_COLUMNS = "missing_columns"
SCHEMA_RESULT_EXTRA_COLUMNS = "extra_columns"
SCHEMA_RESULT_TYPE_MISMATCH = "type_mismatch"
SCHEMA_RESULT_NOT_NULL_CHECK = "not_null_check"

# QC result columns
VAR_FAILED_COLUMN = "failed"
VAR_FAIL_COUNT_ALIAS = "fail_count"


# Defaults
DEFAULT_EMPTY_LIST = []
DEFAULT_EMPTY_STRING = ""
DEFAULT_FALSE = False
DEFAULT_ZERO = 0

PROMOTE_TARGET_TABLES_STEP = "promote_target_tables"

BOOLEAN_TRUE = "true"

QC_PROMOTION_TABLE_LIST = (
    VAR_QC_ACHILLES_RESULT,
    VAR_QC_ACHILLES_RESULT_DIST,
    VAR_QC_TBL_DQD,
    VAR_QC_TBL_CUSTOM,
)
VAR_QC_CRITICALITY = "criticality"

CRITICALITY_HIGH = "high"
CRITICALITY_MEDIUM = "medium"
CRITICALITY_LOW = "low"

VALID_DQD_CRITICALITIES = {
    CRITICALITY_HIGH,
    CRITICALITY_MEDIUM,
    CRITICALITY_LOW,
}

DEFAULT_DQD_CRITICALITY = CRITICALITY_HIGH